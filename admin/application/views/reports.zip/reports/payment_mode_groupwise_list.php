<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
          Scheme Wise Mode Wise Report
          <span id="total_accounts" class="badge bg-aqua"></span>
           
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Reports</a></li>
            <li class="active">Scheme Wise Mode Wise Report</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
           
              <div class="box">
                <div class="box-header">
                      <div class="box-header">
                   <!-- <div class="col-xs-4">
                   <h3 class="box-title">Payment Mode And Group wise Chit Collection Report</h3>  
                   </div> -->
                  
                                    <div class="col-md-3">
                                    <span id="mode_wise_daterange" style="font-weight:bold;"></span>
									
											<div class="form-group">	
                                                										
                                                    <button class="btn btn-default btn_date_range" id="payment_group_modewise_date">
                                                    <span  style="display:none;" id="rpts_payments1"></span>
                                                    <span  style="display:none;" id="rpts_payments2"></span>
                                                    <i class="fa fa-calendar"></i> Date range picker
                                                    <i class="fa fa-caret-down"></i>
                                                    </button>	
											</div>
										 				
									</div>	
									<?php if($this->session->userdata('branch_settings')==1){?>
            							<div class="col-md-2">
            									<div class="form-group" >
            									<label>Select Branch </label>
            									<select id="branch_select" class="form-control" ></select>
            									<input id="id_branch" name="scheme[id_branch]" type="hidden" value=""/>
            								</div>
            							</div>
            						<?php }?>
                            	<input type="hidden" id="branch_filter"  value="<?php echo $this->session->userdata('id_branch') ?>"> 
								<input type="hidden" id="login_branch_name"  value="<?php echo $this->session->userdata('branch_name') ?>"> 
                
                </div><!-- /.box-header -->
                </div>
                <div class="box-body">
                <!-- Alert -->
                <?php 
                	if($this->session->flashdata('chit_alert'))
                	 {
                		$message = $this->session->flashdata('chit_alert');
                ?>
                       <div class="alert alert-<?php echo $message['class']; ?> alert-dismissable">
	                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	                    <h4><i class="icon fa fa-check"></i> <?php echo $message['title']; ?>!</h4>
	                    <?php echo $message['message']; ?>
	                  </div>
	                  
	            <?php } ?>      
            <!-- <table id="payment_mode_group_wise_list" class="table table-bordered table-striped dataTable text-center grid" > -->
            <table id="payment_mode_group_wise_list" class="table table-bordered table-striped" >
                    <thead>
                     <tr>
                        <th>DATE</th>
                        <th>SOURCE</th>
                        <th>CASH</th>							
                        <th>CARD</th> 
                        <th>NET BANKING</th> 
                        <th>UPI</th> 
                        <th>CHEQUE</th> 
                        <th>WALLET</th> 
                        <th>TOTAL</th> 
                      </tr>
                      
                    
                    </thead>
                    <tbody></tbody>
               
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
