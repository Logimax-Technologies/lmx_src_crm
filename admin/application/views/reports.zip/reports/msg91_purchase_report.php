<style type="text/css">
.DTTT_container{
margin-bottom:0 !important;
}
</style>
  <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Msg91 
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Reports</a></li>
            <li class="active">Msg91 Transaction Log</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
           
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Msg91 Transaction Log</h3> <span id="total_trans" class="badge bg-green"></span>   
                </div><!-- /.box-header -->
                <div class="box-body"> 
                <div class="table-responsive">
                  <table  id="msg_trans_list" class="table table-bordered table-striped text-center cus_refferal" >
                    <thead>
                      <tr>
                        <th>Time</th>
                        <th>Type</th>
                        <th>Credit</th>  
                        <th>Amount</th>  
                        <th>Type</th>                   
                        <th>Description </th> 
                      </tr>
                    </thead> 
                     <tfoot>
                 <th></th> <th></th> <th></th> <th></th><th></th><th></th>
                    </tfoot>
                  </table>
                 </div>
                </div><!-- /.box-body -->
                <div class="overlay" style="display:none">
				  <i class="fa fa-refresh fa-spin"></i>
				</div>
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      


<!-- modal -->      

