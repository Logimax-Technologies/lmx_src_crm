  <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">

      <!-- Content Header (Page header) -->

      <section class="content-header">

          <h1>

              Old Metal Sales

              <small></small>

          </h1>

          <ol class="breadcrumb">

              <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>

              <li><a href="#">Reports</a></li>

              <li class="active">Old Metal</li>

          </ol>

      </section>

      <!-- Main content -->

      <section class="content">

          <div class="row">

              <div class="col-xs-12">

                  <div class="box box-primary">

                      <div class="box-header">

                          <h3 class="box-title">Old metal Sales List</h3>

                      </div><!-- /.box-header -->

                      <div class="box-body">

                          <div class="table-responsive">

                              <table id="dash_sales_list" class="table table-bordered table-striped text-center">

                                  <thead>

                                      <tr>

                                          <th>S.No</th>

                                          <th>Name</th>

                                          <th>Date</th>

                                          <th>Metal Name</th>

                                          <th>Amount</th>

                                          <th>Net Weight</th>


                                      </tr>

                                  </thead>
                                  <tbody>
                                      <?php 
                                        if(isset($oldmetal_list)) {  
                                            $i=0;
                                        foreach($oldmetal_list as $old)
                                        {
                                            
                                        ?>
                                      <tr>
                                          <td><?php echo ++$i;?></td>
                                          <td><?php echo $old['firstname'];?></td>
                                          <td><?php echo $old['bill_date'];?></td>
                                          <td><?php echo $old['metal_type'];?></td>
                                          <td><?php echo $old['amount'];?></td>
                                          <td><?php echo $old['weight'];?></td>
                                      </tr>
                                      <?php }  } ?>
                                  </tbody>
                              </table>

                          </div>

                      </div><!-- /.box-body -->

                      <div class="overlay" style="display:none">
                          <i class="fa fa-refresh fa-spin"></i>
                      </div>

                  </div><!-- /.box -->

              </div><!-- /.col -->

          </div><!-- /.row -->

      </section><!-- /.content -->

  </div><!-- /.content-wrapper -->