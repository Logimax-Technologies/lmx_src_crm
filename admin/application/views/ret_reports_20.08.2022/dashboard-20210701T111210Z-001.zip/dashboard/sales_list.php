  <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">

      <!-- Content Header (Page header) -->

      <section class="content-header">

          <h1>

              Sales List

              <small></small>

          </h1>

          <ol class="breadcrumb">

              <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>

              <li><a href="#">Reports</a></li>

              <li class="active">Sales</li>

          </ol>

      </section>

      <!-- Main content -->

      <section class="content">

          <div class="row">

              <div class="col-xs-12">

                  <div class="box box-primary">

                      <div class="box-header">

                          <h3 class="box-title">Sales</h3>

                      </div><!-- /.box-header -->

                      <div class="box-body">

                          <div class="table-responsive">

                              <table id="dash_sales_list" class="table table-bordered table-striped text-center">

                                  <thead>

                                      <tr>

                                          <th>S.No</th>

                                          <th>Bill No</th>

                                          <th>Name</th>

                                          <th>Date</th>

                                          <th>Product Name</th>

                                          <th>Amount</th>

                                          <th>Net Weight</th>

                                          <th>Piece</th>

                                      </tr>

                                  </thead>
                                  <tbody>
                                      <?php 
                                        if(isset($sales_list)) {  
                                            $i=0;
                                        foreach($sales_list as $sale)
                                        {
                                        ?>
                                      <tr>
                                          <td><?php echo ++$i;?></td>
                                          <td><?php echo $sale['bill_no'];?></td>
                                          <td><?php echo $sale['firstname'];?></td>
                                          <td><?php echo $sale['bill_date'];?></td>
                                          <td><?php echo $sale['product_name'];?></td>
                                          <td><?php echo $sale['tot_bill_amount'];?></td>
                                          <td><?php echo $sale['net_wt'];?></td>
                                          <td><?php echo $sale['piece'];?></td>
                                      </tr>
                                      <?php }  } ?>
                                  </tbody>
                              </table>

                          </div>

                      </div><!-- /.box-body -->

                      <div class="overlay" style="display:none">
                          <i class="fa fa-refresh fa-spin"></i>
                      </div>

                  </div><!-- /.box -->

              </div><!-- /.col -->

          </div><!-- /.row -->

      </section><!-- /.content -->

  </div><!-- /.content-wrapper -->