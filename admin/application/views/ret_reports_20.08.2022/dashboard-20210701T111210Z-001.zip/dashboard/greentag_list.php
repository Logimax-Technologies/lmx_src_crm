  <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">

      <!-- Content Header (Page header) -->

      <section class="content-header">

          <h1>

              Green Tag Sales

              <small></small>

          </h1>

          <ol class="breadcrumb">

              <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>

              <li><a href="#">Reports</a></li>

              <li class="active">Green Tag</li>

          </ol>

      </section>

      <!-- Main content -->

      <section class="content">

          <div class="row">

              <div class="col-xs-12">

                  <div class="box box-primary">

                      <div class="box-header">

                          <h3 class="box-title">Green Tag Sales List</h3>

                      </div><!-- /.box-header -->

                      <div class="box-body">

                          <div class="table-responsive">

                              <table id="dash_sales_list" class="table table-bordered table-striped text-center">

                                  <thead>

                                      <tr>

                                          <th>S.No</th>

                                          <th>Bill No</th>

                                          <th>Name</th>

                                          <th>Date</th>

                                          <th>Product Name</th>

                                          <th>Amount</th>

                                          <th>Gross Weight</th>

                                          <th>Piece</th>

                                      </tr>

                                  </thead>
                                  <tbody>
                                      <?php 
                                        if(isset($greentag_list)) {  
                                            $i=0;
                                        foreach($greentag_list as $green)
                                        {
                                        ?>
                                      <tr>
                                          <td><?php echo ++$i;?></td>
                                          <td><?php echo $green['bill_no'];?></td>
                                          <td><?php echo $green['firstname'];?></td>
                                          <td><?php echo $green['bill_date'];?></td>
                                          <td><?php echo $green['product_name'];?></td>
                                          <td><?php echo $green['tot_bill_amount'];?></td>
                                          <td><?php echo $green['gross_wt'];?></td>
                                          <td><?php echo $green['piece'];?></td>
                                      </tr>
                                      <?php }  } ?>
                                  </tbody>
                              </table>

                          </div>

                      </div><!-- /.box-body -->

                      <div class="overlay" style="display:none">
                          <i class="fa fa-refresh fa-spin"></i>
                      </div>

                  </div><!-- /.box -->

              </div><!-- /.col -->

          </div><!-- /.row -->

      </section><!-- /.content -->

  </div><!-- /.content-wrapper -->