<?php

if( ! defined('BASEPATH')) exit('No direct script access allowed');

class Khimji_services extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model("integration_model");
		ini_set('date.timezone', 'Asia/Calcutta');
		
        if (!file_exists('log/khimji')) {
            mkdir('log/khimji', 0777, true);
        }
	}
	
	function findArrayIndex($array, $searchKey, $searchVal) {
        foreach ($array as $k => $val) { 
            if ($val[$searchKey] == $searchVal) {
               return $k;
            }
        }
        return -1;
    }
	
	function generateAcNoOrReceiptNo(){	
        $log_path = '../log/khimji/'.date("Y-m-d").'.txt'; 
	    $payData = $this->integration_model->getPayData();
		if(sizeof($payData) > 0)
		{
			foreach ($payData as $pay)
			{
               $postData = array(
    					    "transactionType"=> 2,
    					    "tranUniqueId"	=> $pay['offline_tran_uniqueid'],
    					    "branchCode"	=> $pay['warehouse'],
    					    "paymentDetail"	=> array(
    											"paymentType" 		=> 9,
    											"paymentTypeName" 	=> "Online",
    											"amount" 			=> $pay['payment_amount'],
    											"authorizationNo" 	=> $pay['payment_amount'],
    											"narration" 		=> $pay['payment_type']."-".$pay['payment_mode'],
    											"originalAmt" 		=> $pay['payment_amount'],
    											"transationAmt" 	=> $pay['payment_amount'],
    											"marchantCharges" 	=> 0.00,
    											"cardChargesAmount" => 0.00,
    											"cardChargesPercentage" => 0
    											)
    					);
    						
                $is_new_ac = ($pay['scheme_acc_number'] != "" && $pay['scheme_acc_number'] != NULL ? FALSE : TRUE);
                if(!$is_new_ac){ // Account number already generated
                    $postData["orderNo"] = $pay['scheme_acc_number'];
    		    }
    		   
               $response = $this->integration_model->khimji_curl('app/v1/saveSchemeOrInstallmentDetails',$postData);
               if($response['status'] == TRUE){
                   	$resData = $response['data']->data; 
                   	if($resData->errorCode == 0){ // $resData->status == TRUE && 
                   		if(isset($resData->result->orderNo)){
    						$acData = array(
    									 'scheme_acc_number'=> $resData->result->orderNo,
    									 'date_upd'			=> date("Y-m-d H:i:s")
    									 );
    						$this->integration_model->updateData($acData,'id_scheme_account',$pay['id_scheme_account'],'scheme_account');
    						$payData = array(
    									 'receipt_no'	=> $resData->result->orderNo,
    									 'date_upd'		=> date("Y-m-d H:i:s")
    									 );
    						$this->integration_model->updateData($payData,'id_payment',$pay['id_payment'],'payment');
    						echo "Updated A/C Number and Receipt Number as ".$resData->result->orderNo;
    		    			return true;						
    					}
    					if(isset($resData->result->installmentNo)){
    						$payData = array(
    									 'receipt_no'	=> $resData->result->installmentNo,
    									 'date_upd'		=> date("Y-m-d H:i:s")
    									 );
    						$this->integration_model->updateData($payData,'id_payment',$pay['id_payment'],'payment');
    						echo "Receipt Number as ".$resData->result->installmentNo;
    						return true;
    					}
                    }
               }
                // Write log in case of API call failure 
                $logData = "\n".date('d-m-Y H:i:s')."\n API : app/v1/saveSchemeOrInstallmentDetails \n Post Data : ".$postData." \n Response : ".json_encode($response,true);
        	    file_put_contents($log_path,$logData,FILE_APPEND | LOCK_EX);
        	    echo "<pre>";print_r($response);
			}
		}else{
		   // Write log in case of API call failure 
            $logData = "\n".date('d-m-Y H:i:s')."\n API : app/v1/saveSchemeOrInstallmentDetails - No Pending data available !!";
    	    file_put_contents($log_path,$logData,FILE_APPEND | LOCK_EX);
    	    echo "No Pending data available !!";
    	    return true; 
		}
	}
	
	
	function khimji_curl($api,$postData)
    {
    	$curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $this->config->item('khimji-baseURL')."".$api,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($postData),
            // Getting  server response parameters //
            CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "Content-Type: application/json",
                "X-Key: ".$this->config->item('khimji-X-Key'),
                "Authorization: ".$this->config->item('khimji-Authorization')
            ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
            $log_path = 'log/khimji/generate_'.date("Y-m-d").'.txt';  
            $logData = "\n".date('d-m-Y H:i:s')."\n API : ".$api." \n POST : ".json_encode($postData,true)."\n Error : ".json_encode($err,true);
		    file_put_contents($log_path,$logData,FILE_APPEND | LOCK_EX);
            return array('status' => FALSE, 'data' => $err);
        } 
        else {
            return array('status' => TRUE, 'data' => json_decode($response));
        }
    }

    function getMetalRate(){
        $date1 = DateTime::createFromFormat('h:i a', date("h:i a"));
        $date2 = DateTime::createFromFormat('h:i a', "08:00 am");
        $date3 = DateTime::createFromFormat('h:i a', "08:00 pm");
        if ($date1 > $date2 && $date1 < $date3)
        {
            $memcache = new Memcache();
            $memcache->connect("127.0.0.1", 11211);
            $log_path = 'log/khimji/rate_'.date("Y-m-d").'.txt';      
            $this->load->model("integration_model");
            $postData = array(
                            "branchName"	=> "BHOPAL"
                        );
            $response = $this->integration_model->khimji_curl('user/getLatestMetalRate',$postData);
            if($response['status']){
               	$resData = $response['data'];
               	if($resData->status == 1 && $resData->errorCode == 0){
                    $rates = $resData->metalRateDetails;
                    foreach($rates as $rate){
                        $insertData['updatetime'] = date('Y-m-d H:i:s',strtotime(str_replace('/','-',$rate->LastUpdatedDateTime)));
                        
                        if($rate->Purity == 75 && $rate->itemType == "Gold")
                        $insertData['goldrate_18ct'] = $rate->SaleRate;
                        
                        if($rate->Purity == 91.6 && $rate->itemType == "Gold")
                        $insertData['goldrate_22ct'] = $rate->SaleRate;
                        
                        if($rate->Purity == 99.9 && $rate->itemType == "Gold")
                        $insertData['goldrate_24ct'] = $rate->SaleRate;
                        
                        if($rate->itemType == "Silver")
                        $insertData['silverrate_1gm'] = $rate->SaleRate;
                        
                        if($rate->itemType == "Platinum")
                        $insertData['platinum_1g'] = $rate->SaleRate;
                    }
                    $insertData['add_date'] 		= date("Y-m-d H:i:s");
                    $insertData['id_employee'] 		= 0;
                    //echo "<pre>";print_r($insertData);
                    
                    $lastRate = json_decode($memcache->get('lastMetalRates'));
                    $lastUpdDate = date('Y-m-d',strtotime($lastRate->updatetime));
                    echo "Cache lastMetalRates : <pre>";print_r($lastRate);
                    echo "SIZE : ".sizeof($lastRate)."\n";
                    echo "Rate : ".$lastRate->goldrate_22ct ." == ". $insertData['goldrate_22ct']."\n";
                    echo "lastUpdDate : ".$lastUpdDate."\n";
                    if($lastRate->goldrate_22ct != $insertData['goldrate_22ct'] || sizeof($lastRate) == 0 || $lastUpdDate != date('Y-m-d')){
                        $rateTxt_data = array(
                                            'goldrate_22ct'     => number_format($insertData['goldrate_22ct'],'2','.',''),
                                            'silverrate_1kg'	=> $insertData['silverrate_1kg'],
                                            'silverrate_1gm'	=> $insertData['silverrate_1gm'],
                                            'mjdmagoldrate_22ct'=> number_format($insertData['mjdmagoldrate_22ct'],'2','.',''),
                                            'mjdmasilverrate_1gm'=>$insertData['mjdmasilverrate_1gm'], 
                                            'market_gold_18ct'  => $insertData['market_gold_18ct'], 
                                            'goldrate_18ct'     => $insertData['goldrate_18ct'], 
                                            'updatetime'	    => $metal['updatetime']
                                        );
                        file_put_contents('../api/rate.txt',json_encode($rateTxt_data));
                        $this->db->trans_begin();				 	
                        //inserting rates in DB 
                        if($rate_settings['is_branchwise_rate']==0)
                        {
                            $this->load->model("admin_settings_model");
                            $status = $this->admin_settings_model->metal_ratesDB("insert","",$insertData);
                            if($this->db->trans_status() == TRUE){
                                $memcache->set('lastMetalRates', json_encode($insertData), 0, 0);
                                $this->admin_settings_model->settingsDB("update",1,array('is_ratenoti_sent'=>2));
                                $this->db->trans_commit();	
                                echo "Rate added Successfully";
                            }
                        }
                    }else{
                        echo "No change in rate.. ".$lastRate->goldrate_22ct ." == ". $insertData['goldrate_22ct'];
                    }
               	}
            }
        }else{
            echo "Time :".date("h:i a");
        }
    }
    
    
	function sendEmail($subject,$message){
		$this->load->model('email_model');
		$bcc = "pavithra@vikashinfosolutions.com";
		$sendEmail = $this->php_mail('support@logimaxindia.com',$subject,$message,'',$bcc);
		//echo 1;exit;
		return true;
	}
	
	public function php_mail($email_to,$email_subject,$email_message,$email_cc,$email_bcc,$attachment="") 		{ 
		 $config = array();
                $config['useragent']     = "CodeIgniter";
                $config['mailpath']      = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"
                $config['protocol']      = "smtp";
                $config['smtp_host']     = "localhost";
                $config['smtp_port']     = "25";
                $config['mailtype']		 = 'html';
                $config['charset'] 		 = 'utf-8';
                $config['newline'] 		 = "\r\n";
                $config['wordwrap']		 = TRUE;
                $this->load->library('email');
                $this->email->initialize($config);
                $this->email->from('noreply@logimax.co.in', 'Emerald');
                $this->email->to($email_to); 
				if($email_cc!="")
				{
					$this->email->cc($email_cc); 
				}
             
     			if($email_bcc!="")
				{
                   $this->email->bcc($email_bcc); 
			    }
                $this->email->subject($email_subject);       
            	$this->email->message($email_message);
            	   
           return $this->email->send();           
			 
	}
	
	

}