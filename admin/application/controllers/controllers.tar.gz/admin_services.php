<?php

if( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_services extends CI_Controller

{

	

	const MODEL	="admin_usersms_model";

	const CUS_MODEL	="customer_model";

	const VIEW ='sms/';

	const GRP ='sms/group/';

	const SMS_VIEW ='sms/smsService/';
	
	const NOTI_VIEW ='notification/';

	const SET_MODEL = 'admin_settings_model';

	const EMAIL_MODEL = 'email_model';

	const ADM_MODEL = 'chitadmin_model';
	
	const PAY_MODEL = 'payment_model';

	const PAY_VIEW  = "payment/";

	const SET_VIEW  = "scheme/settlement/";

	const API_MODEL = 'chitapi_model';

	const ACC_MODEL = 'account_model';

	const SMS_MODEL = 'admin_usersms_model';

	const LOG_MODEL = "log_model";

	const MAIL_MODEL = "email_model";
	
	const SERV_MODEL = 'services_model';
	
	const TEST_VIEW = "settings/";
	
	const SYN_MODEL = "syncapi_model";
	
	const OFF_DATA_FILE_PATH= "assets/offline_data/2021-03-08/cus-reg/";

		function __construct()

	{

		parent::__construct();

		ini_set('date.timezone', 'Asia/Calcutta');

		$this->load->model(self::MODEL);
		
		$this->load->model(self::SERV_MODEL);

		$this->load->model(self::SET_MODEL);

		$this->load->model(self::CUS_MODEL);

		$this->load->model(self::EMAIL_MODEL);

		$this->load->model(self::ADM_MODEL);

		$this->load->model(self::PAY_MODEL);

		$this->load->model(self::ACC_MODEL);

		$this->load->model(self::SMS_MODEL);

		$this->load->model(self::LOG_MODEL);

		$this->load->model(self::MAIL_MODEL);		
		$this->load->model("sms_model");	
		$this->load->model("sktm_syncapi_model");
		
		$this->load->model(self::SYN_MODEL);

		$this->employee =  $this->session->userdata('uid');

		$this->company = $this->admin_settings_model->get_company();

	}

		
 function check_expiry()
  {
	  $model = self::SET_MODEL;
	  $this->db->trans_begin();	
	  $expired_date_data = $this->$model->getExpiredData();
	/*  echo "<pre>";print_r($expired_date_data);echo "</pre>";exit;*/
		foreach($expired_date_data as $expired_data)
		{			
		  if($expired_data['active'] == 1)
			 {
				$data=array('active' => 0);
				$data=$this->$model->update_new_arrivals($data,$expired_data['id_new_arrivals']);
				
				if($this->db->trans_status()===TRUE)
				 {
			 		$this->db->trans_commit();							
				}
				else{
					$this->db->trans_rollback();
					echo 'Something went wrong';		
				}
			}	
		 } 
  }
	
	 
function set_image($filename)
 {
 	$data=array();
    $model=self::SET_MODEL;
	 if($_FILES['notification_img']['name'])
   	 { 
   	 	$path='assets/img/notification/';
	    if (!is_dir($path)) {
		  mkdir($path, 0777, TRUE);
		}
		/*else{
			$file = $path.$id.".jpg" ;
			chmod($path,0777);
	        unlink($file);
		}*/

   	 	$img=$_FILES['notification_img']['tmp_name'];
   	 	$imgpath='assets/img/notification/'.$filename;
	 	$upload=$this->upload_img('noti_img',$imgpath,$img);
	 } 
 }

  function upload_img( $outputImage,$dst, $img)
	{	
	if (($img_info = getimagesize($img)) === FALSE)
	{
		// die("Image not found or not an image");
		return false;
	}

	$width = $img_info[0];
	$height = $img_info[1];
	switch ($img_info[2]) {
	  case IMAGETYPE_GIF  : $src = imagecreatefromgif($img);
	  						$tmp = imagecreatetruecolor($width, $height);
	  						$kek=imagecolorallocate($tmp, 255, 255, 255);
				      		imagefill($tmp,0,0,$kek);
	  						break;

	  case IMAGETYPE_JPEG : $src = imagecreatefromjpeg($img); 
	  						$tmp = imagecreatetruecolor($width, $height);
	 						break;

	  case IMAGETYPE_PNG  : $src = imagecreatefrompng($img);
						    $tmp = imagecreatetruecolor($width, $height);
	  						$kek=imagecolorallocate($tmp, 255, 255, 255);
				     		imagefill($tmp,0,0,$kek);
				     		break;

	  default : //die("Unknown filetype");	

	  return false;

	  }		
	  imagecopyresampled($tmp, $src, 0, 0, 0, 0, $width, $height, $width, $height);
	  imagejpeg($tmp, $dst, 60);
	}
	
	// to send lowest rate notification 
	function send_lowestrate_noti(){
		$model = self::MODEL;
		$result =array();
		$send_notif =$this->$model->check_noti_settings();
		
		if($send_notif == 1 ){
			//send lowest rate notification
					$data = $this->$model->getnotiData('9');
					//print_r($data);exit;
					$a=0;
					foreach ($data['data']  as $r){
						if(sizeof($r['token'])>0){
							$arraycontent=array('token'=>$r['token'],
												'notification_service'=>9,
												'header'=>$data['header'],
												'message'=>$r['message'],
												'mobile'=>$r['mobile'],
												'footer'=>$data['footer']						
							);
							$rate = $this->send_singlealert_notification($arraycontent);
							$result['rate'][$a]=$rate;
							$a++;							
						}
					}
				
		}	
		return $result;			
	}
	
	// to send rate notification 
	function send_rate_noti(){
		$model = self::MODEL;
		$result =array();
		$send_notif =$this->$model->check_noti_settings();
		if($send_notif == 1 ){
			//send rate notification
					$data = $this->$model->get_cusnotiData('1');
					$a=0;
					foreach ($data['data']  as $r){
						if(sizeof($r['token'])>0){
							$arraycontent=array('token'=>$r['token'],
												'notification_service'=>1,
												'header'=>$data['header'],
												'message'=>$r['message'],
												'mobile'=>$r['mobile'],
												'footer'=>$data['footer']						
							);
							$rate = $this->send_singlealert_notification($arraycontent);
							
							$result['rate'][$a]=$rate;
							$a++;							
						}
					}
				
		}	
		return $result;			
	}
	
	// send due,bday,wday notification by service call //
	function send_notification(){
		$model = self::MODEL;
		$result =array();
		$send_notif = $this->$model->check_noti_settings();
		if($send_notif == 1 ){
            //send today due notification
            $noti_settings = $this->$model->get_noti_settings(4); 
            $sendDueAlert = 0;
            if(date('d') >= $noti_settings['send_daily_from'] && $noti_settings['send_daily_from'] != 0){ 
                // Ex: send_daily_from = 25 , then notification will be sent daily from 25 th //HH
                $sendDueAlert = 1;
            }else{ 
                // Send Due alert Multiple Dates//HH
                $dates = explode(',',$noti_settings['send_notif_on']);
                foreach ($dates as $date) {
    			    if($date == date('d')){
    			        $sendDueAlert = 1;
    				}
                }
            }
            
            if($sendDueAlert == 1){ 
                $data = $this->$model->get_cusnotiData('4');
		   	//	echo "<pre>";print_r($data);echo "</pre>";exit;
				$i=0;
				$arraycontent=array();
				$targetUrl='#/app/paydues';
				foreach ($data['data']  as $row){
					if(((sizeof($row['token'])>0) || sizeof($row['mobile']>0)))
					{
						$arraycontent=array('token'=>$row['token'],
											'notification_service'=>4,
											'header'=>$data['header'],
											'message'=>$row['message'],
											'mobile'=>$row['mobile'],
											'footer'=>$data['footer'],
											'id_customer'=>$row['id_customer'],					
											'targetUrl'=>$targetUrl,
											'currentpaycount' =>$row['currentpaycount']
						);								
						//echo "<pre>";print_r($arraycontent);echo "</pre>";
						
					if($row['currentpaycount'] == 0)
					{
						
						if($this->config->item('sms_gateway') == '1'){
			    		    $this->sms_model->sendSMS_MSG91($row['mobile'],$row['message']);		
			    		}
			    		elseif($this->config->item('sms_gateway') == '2'){
			    	        $this->sms_model->sendSMS_Nettyfish($row['mobile'],$row['message'],'trans');
			    		}
						$res = $this->send_singlealert_notification($arraycontent);
						$r = json_decode($res);
						if($r->recipients > 0){
                          $status= $this->$model->insert_sent_notification($arraycontent);  
                        }
						$result['res'][$i]=$res;
								if($status){
    					$alertcount = $alertcount+1;
    				}
					}
					}
				    $i++;		
				}
				
				if($this->db->trans_status() === TRUE){
            $this->db->trans_commit();
            	$msg = $alertcount.' Customer(s) Due ALert Notification sent successfully.';
			echo  $msg;
        }else{
            $this->db->trans_rollback();
            echo "Did't Due ALert Notification sent.";
        }
            }
            
            //send birthday wish
				
			$data = $this->$model->get_cusnotiData('7'); 
			$a=0;
			$otp_promotion =1;
			//$arraycontent=array();
			$targetUrl='#/app/notification';
			foreach ($data['data']  as $bday){
				if(((sizeof($bday['token'])>0) || sizeof($bday['mobile']>0))){
					$arraycontent=array('token'=>$bday['token'],
										'notification_service'=>7,
										'header'=>$data['header'],
										'message'=>$bday['message'],
										'mobile'=>$bday['mobile'],
										'footer'=>$data['footer'],
										'id_customer'=>$bday['id_customer'],					
										'targetUrl'=>$targetUrl				
					);
					 
					if($this->config->item('sms_gateway') == '1'){
		    		    $this->sms_model->sendSMS_MSG91($bday['mobile'],$bday['message'],1);		
		    		}
		    		elseif($this->config->item('sms_gateway') == '2'){
		    	        $this->sms_model->sendSMS_Nettyfish($bday['mobile'],$bday['message'],'trans');
		    		}
		    		
					$bdaywish = $this->send_singlealert_notification($arraycontent);
					$res = json_decode($bdaywish);
					if($res->recipients > 0){
                       $this->$model->insert_sent_notification($arraycontent);  
                    }
					$result['bdaywish'][$a]=$bdaywish;
												
				}
			$a++;	
			}
		
		//send wedding day wish
		
			 $res = $this->$model->get_cusnotiData('8');
			 $b=0;
			 $otp_promotion =1;
			//$array_content=array();
			$targetUrl='#/app/notification';
			foreach ($res['data']  as $wedwish){
				
				if(((sizeof($wedwish['token'])>0) || sizeof($wedwish['mobile']>0))){
					
					$array_content = array('token'=>$wedwish['token'],
										'notification_service'=>8,
										'header'=>$res['header'],
										'message'=>$wedwish['message'],
										'mobile'=>$wedwish['mobile'],
										'footer'=>$res['footer'],
										'id_customer'=>$wedwish['id_customer'],
										'targetUrl'=>$targetUrl
					);
					//echo "<pre>";print_r($array_content);echo "</pre>"; 
					if($this->config->item('sms_gateway') == '1'){
		    		    $this->sms_model->sendSMS_MSG91($wedwish['mobile'],$wedwish['message'],1);	
		    		}
		    		elseif($this->config->item('sms_gateway') == '2'){
		    	        $this->sms_model->sendSMS_Nettyfish($wedwish['mobile'],$wedwish['message'],'trans');
		    		}
					$wedwish = $this->send_singlealert_notification($array_content); 
					$res = json_decode($wedwish);
					if($res->recipients > 0){
                       $this->$model->insert_sent_notification($array_content);  
                    }
					$result['wedwish'][$b]=$wedwish;
					
				}
			$b++;		
			} 
		}	
		
		//print_r($result);
		return $result;	
		
	}
	
	 // send due sms single  & multipl continus date by service call //HH  
	 function send_smsdue(){
		$model = self::MODEL;
		$result =array();
              $sendSMS = $this->$model->get_sms_settings(22); 
         	//	echo "<pre>";print_r($sendSMS);echo "</pre>";exit;
            	if($sendSMS ){
            //send today due sms
          
            $sendDueAlert = 0;
            if(date('d') >= $sendSMS['send_daily_from'] && $sendSMS['send_daily_from'] != 0){ 
                // Ex: send_daily_from = 25 , then sms will be sent daily from 25 th
               
                $sendDueAlert = 1;
            }else{ 
               
                // Send Due sms alert Multiple Dates
                $dates = explode(',',$sendSMS['send_sms_on']);
                foreach ($dates as $date) {
    			   // echo "<pre>";print_r($date);exit;
    			    if($date == date('d')){
    			        $sendDueAlert = 1;
    				}
                }
            }
            
            if($sendDueAlert == 1){
                $data = $this->$model->get_SMS_due('22');
                 //	echo "<pre>";print_r($data);echo "</pre>";exit;
			
				$arraycontent=array();
				
				foreach ($data['data']  as $row){
					if((sizeof($row['mobile']>0)))
					{
						$arraycontent=array('id_services'=>22,
											'message'=>$row['message'],
											'mobile'=>$row['mobile'],
											'footer'=>$data['footer'],
											'id_customer'=>$row['id_customer'],
											'currentpaycount' =>$row['currentpaycount']
												
						);
						//print_r($arraycontent);exit;
					if($row['currentpaycount'] == 0)
					{
						
						if($this->config->item('sms_gateway') == '1'){
			    		  $status=$this->sms_model->sendSMS_MSG91($row['mobile'],$row['message'],1);
			    		   //print_r($status);exit;  
			    		}
			    		elseif($this->config->item('sms_gateway') == '2'){
			    	    $this->sms_model->sendSMS_Nettyfish($row['mobile'],$row['message'],'promo');
			    		}
			    		if($status){
    					$alertcount = $alertcount+1;
    				}
				}	
		    }
		
        }
        
         if($this->db->trans_status() === TRUE){
            $this->db->trans_commit();
            	$msg = $alertcount.' Customer(s) Due ALert sms sent successfully.';
			echo  $msg;
        }else{
            $this->db->trans_rollback();
            echo "Did't Due ALert sms sent.";
        }
    }   
            
     //return true;	
		
	}
	
    }  	// send due sms by service call//   
	
	
	
	function send_singlealert_notification($alertdetails = array()) 
	{
		$registrationIds =array();
		$registrationIds[0] = $alertdetails['token'];
		$content = array(
		"en" => $alertdetails['message']
		);
		
		if($alertdetails['notification_service']== '2'){
			$targetUrl='#/app/offers';
		}
		else if($alertdetails['notification_service']== '3'){
			$targetUrl='#/app/newarrivals';
		}
		else if($alertdetails['notification_service']== '4' || $alertdetails['notification_service']== '5' || $alertdetails['notification_service']== '6'){
			$targetUrl='#/app/paydues';
		}
		else{
			$targetUrl='#/app/notification';
		}
			
		$fields = array(
		'app_id' => $this->config->item('app_id'),
		'include_player_ids' => $registrationIds,
		'contents' => $content,
		'headings' => array("en" => $alertdetails['header']),
		'subtitle' => array("en" => $alertdetails['footer']),
		'data' => array('targetUrl'=>$targetUrl,'noti_service'=>$alertdetails['notification_service'],'mobile'=>$alertdetails['mobile']),
		'big_picture' => (isset($alertdetails['noti_img'])?$alertdetails['noti_img']:" ")
		);
	
		$auth_key = $this->config->item('authentication_key');
		$fields = json_encode($fields);
			
		 $ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
		  'Authorization: Basic '.$auth_key));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

		$response = curl_exec($ch);
		curl_close($ch); 
		//print_r($response);
	return $response;
	}
	
	public function getmetal_content($noti_data)
	{
		$model=self::MODEL;		
		$send_notif =$this->$model->check_noti_settings();
		$metalrate['message']=$this->$model->get_noticontent($noti_data);
		$noti=$this->$model->get_noti($noti_data['notification_service']);
		if($send_notif == 1 ){
			$data['token']=$this->$model->getDevicetokens();
			$i =1;
			
			foreach ($data['token']  as $row){
				if(sizeof($row['token'])>0){
					$metalcontent=array('token'=>$row['token'],
										'notification_service'=>$noti['id_notification'],
										'header'=>$noti['noti_name'],
										'message'=>$metalrate['message'],
										'mobile'=>$row['mobile'],
										'footer'=>$noti['noti_footer'],
					);
					//echo "<pre>";print_r($metalrate['message']); 
					$res = $this->send_singlealert_notification($metalcontent);
					$result['noti'][$i]=$res;
					$i++;							
				}
			}
		}
		return $result;
	}
	
	public function lowest_goldrate_noti()
	{
	  if(date('d') > 10){
	  	
		$model=self::MODEL;
		//$lowmatelrate=$this->$model->metalrate_gold('ALL');
		$lowmatelrate_month = $this->$model->metalrate_gold('TM');
		
		//$lowmatelrate_yesterday=$this->$model->metalrate_gold('Y');
		$goldrate_today = $this->$model->metalrate_gold('T');
		
		
		/*if(isset($goldrate_today['goldrate_22ct'])<=isset($lowmatelrate['goldrate_22ct']))
		{
			$data=array(
							'tgoldrate_22ct'=>$goldrate_today['goldrate_22ct'],
							'ygoldrate_22ct'=>$lowmatelrate['goldrate_22ct'],
							'notification_service'=>11
							);
			$this->getmetal_content($data);	
		}*/
		if(isset($goldrate_today['goldrate_22ct'])<=isset($lowmatelrate_month['goldrate_22ct']))
		{
				
				$data=array(
							'tgoldrate_22ct'=>$goldrate_today['goldrate_22ct'],
							'ygoldrate_22ct'=>$lowmatelrate_month['goldrate_22ct'],
							'notification_service'=>9
							);
							
			$res = $this->getmetal_content($data);
				
		} 
	/*	elseif(isset($goldrate_today['goldrate_22ct'])<=isset($lowmatelrate_yesterday['goldrate_22ct']))
		{
							$data=array(
							'tgoldrate_22ct'=>$goldrate_today['goldrate_22ct'],
							'ygoldrate_22ct'=>$lowmatelrate_yesterday['goldrate_22ct'],
							'notification_service'=>9
							);
			$this->getmetal_content($data);
		} */
	
	 }
	 return true;
	
	}
	
// scheme free payments installments
	
	function scheme_freepayment()
	{		
		$model= self::PAY_MODEL;
	    $freepaycust = $this->$model->get_freepaycust();
	    $insertCount = 0;
	    $status = array();
		$this->db->trans_begin();
		
		foreach($freepaycust as $data)
		{ 
		    $free_ins = explode(',',$data['free_payInstallments']);		
			foreach($free_ins as $ins)
			{				
				if($data['paid_installments']+1 == $ins && $data['has_free_ins'] == 1 && $data['last_paid_month'] != date('m-Y'))
    			 {	
    				$insertData = $this->getFreePayData($data);
    				$status = $this->$model->paymentDB("insert","",$insertData);
    				if($status['insertID']){
    					$insertCount = $insertCount+1;
    				}
    			 }									
			}
			if($status)
			{
				 $pay_status_array = array(
 			       	'id_payment'		=>  (isset($status['insertID'])?$status['insertID']: NULL),
					'id_status_msg' 	=>  'success',
 			       	'charges' 			=>  '',
 			       	'id_employee' 		=>  $this->session->userdata('uid'),
 			       	'date_upd'			=>  date('Y-m-d H:i:s')
				 );
 			 
 			  $ppsm = $this->$model->payment_statusDB("insert","",$pay_status_array);
			
			 //send sms/mail to Customer 
			  $payData =  $this->$model->getPpayment_data($status['insertID']);  
			  $mailSubject = "Reg- ".$this->company['company_name']." saving scheme payment details";
			  $mailtype= 2;
			  $this->sendSMSMail('3',$payData,$mailSubject,$mailtype,$status['insertID']);
			  
			//send sms/mail to Customer 
			  $payData =  $this->$model->getPpayment_data($status['insertID']);  
			  $mailSubject = "Reg- ".$this->company['company_name']." saving scheme payment details";
			  $mailtype= 3;
			  $this->sendSMSMail('7',$payData,$mailSubject,$mailtype,$status['insertID']);			
			}		
		}	
		if($this->db->trans_status() === TRUE)
		{
			$this->db->trans_commit();
			$msg = $insertCount.' payment(s) credited successfully.';
			echo  $msg;
		}
		else{
			$this->db->trans_rollback();
			echo "Something went wrong";
		}
	}

   
	
	function getFreePayData($sch_data)
	{
		

		$model		 = self::PAY_MODEL;		
		$metal_rate  = $this->payment_model->getMetalRate();		
		$gold_rate   = number_format((float)$metal_rate['goldrate_22ct'], 2, '.', '');		
		$converted_wgt = number_format((float)($sch_data['amount']/$gold_rate), 3, '.', '');		
		$fxd_wgt 	= $sch_data['max_weight'];
		if($sch_data['receipt_no_set']==1){
		    $receipt_no = $this->generate_receipt_no();
		}
		if($sch_data['gst_type']==0){
			$gst_amt=$sch_data['amount']-($sch_data['amount']*(100/(100+$sch_data['gst'])));
			$cal_amt=$sch_data['amount']-$gst_amt;
			
		}
			if($sch_data['gst_type']==1){
				$gst_amt=$sch_data['amount']*$sch_data['gst']/100;
				$cal_amt=$sch_data['amount']+ $gst_amt;
			}
		$insertData = array(
							"id_scheme_account"	 => $sch_data['id_scheme_account'],	
							"date_payment" 		 => date('Y-m-d H:i:s'),
							"payment_type" 	     => "Cost free payment", 
							"payment_mode" 	     => "FP", 
							"act_amount" 	     => NULL, 		
							"payment_amount" 	 => $sch_data['amount'], 
							"due_type" 	         => 'D', 
							"no_of_dues" 	     => '1', 
							"metal_rate"         => $gold_rate,
							"metal_weight"       => ($sch_data['scheme_type']==2 ? $converted_wgt : ($sch_data['scheme_type']==1 ? $fxd_wgt : 0.000)),
							"remark"             => "Paid by ".$sch_data['company_name'],
							"payment_status"     => '1',
							"receipt_no"     	 => $receipt_no,
							"gst"				=>$sch_data['gst'],
							"gst_type"			=>$sch_data['gst_type']
							
					  );		
//echo "<pre>";print_r($insertData);echo "</pre>";exit;
		  
		return 	$insertData;	
	}
	
	
	function generate_receipt_no()

	{

		$model =	self::PAY_MODEL;

		$rcpt_no = "";

		$rcpt = $this->$model->get_receipt_no();

		if($rcpt!=NULL)

		{

		  	$temp = explode($this->company['short_code'],$rcpt);

			 	if(isset($temp))

			 	{

			 	    

					$number = (int) $temp[1];

					$number++;

					$rcpt_no =$this->company['short_code'].str_pad($number, 6, '0', STR_PAD_LEFT);

				}		   

		}

		else

		{

			 	$rcpt_no =$this->company['short_code']."000001";

			 

		}

		return $rcpt_no;

	}
	
// scheme free payments installments


function sendSMSMail($serviceID,$data,$subject,$type,$id)

	{

		$ser_model = self::SET_MODEL;

	    $mail_model=self::MAIL_MODEL;

		$service = $this->$ser_model->get_service($serviceID);

		$email	=  $data['email'];

		$sms_model= self::SMS_MODEL;			

		if($service['serv_email'] == 1  && $email!= '')

				{

					$data['payData'] = $data;

					$data['company_details'] = $this->company;

					$data['type'] = $type;

					$to = $email;

					$message = $this->load->view('include/emailPayment',$data,true);

					$sendEmail = $this->$mail_model->send_email($to,$subject,$message);

					

				}

		if($service['serv_sms'] == 1)

		{	

			$data =$this->$sms_model->get_SMS_data($serviceID,$id);

			$mobile_number =$data['mobile'];

			$message = $data['message'];
 
			if($this->config->item('sms_gateway') == '1'){
    		    $this->sms_model->sendSMS_MSG91($mobile_number,$message,1);	
    		}
    		elseif($this->config->item('sms_gateway') == '2'){
    	        $this->sms_model->sendSMS_Nettyfish($mobile_number,$message,'promo');
    		}

			

		}

		return true;

	}
	
	function send_sms($mobile,$message,$otp_prom="")

	{

		$model = self::ADM_MODEL;	

		// '0 - promotion sms , 1 - otp	
		
		if($otp_prom!=''){
		 $otp_promotion =$otp_prom;
		}else{			
			$otp_promotion =0;		}		
		
		if($this->config->item('sms_gateway') == '1'){
		    $this->sms_model->sendSMS_MSG91($mobile,$message,$otp_promotion);	
		}
		elseif($this->config->item('sms_gateway') == '2'){
	        $this->sms_model->sendSMS_Nettyfish($mobile,$message,'promo');
		} 

		return true;

	}
	
//  MJDMA rate notification 
	
	function send_mjdmarate_notification()
	{
		$model=self::SET_MODEL; 
		$chitsettings = $this->$model->settingsDB("get",1,"");
		/* 1 -> Rate updated & notification sent  2 -> Rate updated & didn\'t send notification ' */
		if($chitsettings['allow_notification'] == 1){
			if($chitsettings['is_ratenoti_sent'] == 2){			
				$sendnoti = $this->sendmjdmarate_noti($chitsettings);
				if($sendnoti){
					$upd = $this->$model->settingsDB("update",1,array('is_ratenoti_sent'=>1));
				}
				print_r($sendnoti);
			}
			elseif($chitsettings['is_ratenoti_sent'] == 1){
				echo 'Notification already sent';
			}
			else{
				echo 'Something went wrong!!!';
			}
		}else{
			echo 'Notification disabled.';
		}
				
	}
	
	// this func rate notifi//
	function sendmjdmarate_noti($chitsettings){
		$model = self::MODEL;
		$result = array(); 
		//send rate notification
		if($chitsettings['is_branchwise_rate']==1)
		{
		    if($chitsettings['is_branchwise_cus_reg'] == 1)
		    {
		        $branches = $this->$model->getBranches();
		        foreach($branches as $branch){
		            $cusData = $this->$model->get_cusBranchRate($branch,"1,2"); // 1-Automatic,2-partial 
    		        if(count($cusData)>0)
        		    {
        			    foreach($cusData as $cus)
        			    {
        			        if($cus['metal_rate_type'] == 1 || $cus['metal_rate_type'] == 2){ // 1-Automatic,2-partial
        			            $noti_msg  = '';
            		            $resultset = $this->db->query("SELECT noti_name,noti_name, noti_footer,noti_msg from notification where id_notification =1");
                				foreach($resultset->result() as $row)
                				{
                					$noti_msg = $row->noti_msg;
                					$noti_footer = $row->noti_footer;
                					$noti_header=$row->noti_name;
                				}
                    			$resultset->free_result();
            		           //Generating Message content
                    			$field_name = explode('@@', $noti_msg);	
                    			for($i=1; $i < count($field_name); $i+=2) 
                    			{	
                    			    $field =  $field_name[$i];
                    				if(isset($cus[$field])) 
                    				{
                    					$noti_msg = str_replace("@@".$field."@@",$cus[$field],$noti_msg);					
                    				}	
                    			}
                    			$field_name_footer = explode('@@', $noti_footer);	
                    			for($i=1; $i < count($field_name_footer); $i+=2)
                    			 {
                    				if(isset($cus->$field_name_footer[$i]))
                    				 { 
                    					$noti_footer = str_replace("@@".$field_name_footer[$i]."@@",$cus[$field_name_footer[$i]],$noti_footer);					
                    				}	
                    			}
                                $arraycontent = array(
                                                    'notification_service'  => 1,
                                                    'header'                => 'Daliy Rate',
                                                    'message'               => $noti_msg,
                                                    'token'                 => $cus['token']
                                                    );
            			        $result = $this->send_singlealert_rate_notification($arraycontent);
        			        }
        			    }
        		    }
		        }
		    }
		    else{
    		    $account = $this->$model->get_account('');
    		    /*echo "<pre>";print_r($account);
    		    echo $this->db->last_query();exit;*/
    		    if(count($account)>0)
    		    {
    			    foreach($account as $acc)
    			    {
    		            $rate = $this->$model->get_metal_rateby_branch($acc['id_customer']);
    		            $noti_msg  = '';
    		            $resultset = $this->db->query("SELECT noti_name,noti_name, noti_footer,noti_msg from notification where id_notification =1");
    		            if($rate['metal_rate_type'] == 1 || $rate['metal_rate_type'] == 2){ // 1-Automatic,2-partial
            				foreach($resultset->result() as $row)
            				{
            					$noti_msg = $row->noti_msg;
            					$noti_footer = $row->noti_footer;
            					$noti_header=$row->noti_name;
            				}
                			$resultset->free_result();
        		            foreach($rate as $cusData)
        			        {
        			            //$msg.="Today ".$rates['name']." Gold Rate Rs.".$rates['goldrate_22ct']."/Gm (22 kt),Silver Rate Rs.".$rates['silverrate_1gm']." Gm at ".$rates['updatetime']." .";
        			            //Generating Message content
                    			$field_name = explode('@@', $noti_msg);	
                    			for($i=1; $i < count($field_name); $i+=2) 
                    			{	
                    			    $field =  $field_name[$i];
                    				if(isset($cusData[$field])) 
                    				{
                    					$noti_msg = str_replace("@@".$field."@@",$cusData[$field],$noti_msg);					
                    				}	
                    			}
                    			$field_name_footer = explode('@@', $noti_footer);	
                    			for($i=1; $i < count($field_name_footer); $i+=2)
                    			 {
                    				if(isset($cusData->$field_name_footer[$i]))
                    				 { 
                    					$noti_footer = str_replace("@@".$field_name_footer[$i]."@@",$cusData[$field_name_footer[$i]],$noti_footer);					
                    				}	
                    			}
        			            $msg .= $noti_msg;
        			        }
                            $arraycontent = array(
                                                'notification_service'  => 1,
                                                'header'                => 'Daliy Rate',
                                                'message'               => $msg,
                                                'token'                 => $rate[0]['token']
                                                );
                            
        			        $result = $this->send_singlealert_rate_notification($arraycontent);
    		            }     
    			    }
    		    }
    		}
		    
		}
		else
		{
		    $data = $this->$model->get_cusnotiData('1');
		    //print_r($data);exit;
		    foreach ($data['data']  as $r)
		    { 
				$arraycontent=array('notification_service'=>1,
									'header'=>$data['header'],
									'message'=>$r['message'],
									'footer'=>$data['footer']						
				);
				$send = $this->onesignalNotificationToAll($arraycontent);
				$result['rate_noti'] = $send;
				//print_r($send);exit;
		    }
		}
			 
		return $result;			
	}

	function onesignalNotificationToAll($alertdetails = array()) 
	{		  
		$content = array(
		"en" => $alertdetails['message']
		);
	 
		$targetUrl='#/app/notification';
		
		$fields = array(
		'app_id' => $this->config->item('app_id'),
		'included_segments' => array(
			'All'
		),
		'contents' => $content,
		'headings' => array("en" => $alertdetails['header']),
		'subtitle' => array("en" => $alertdetails['footer']),
		'data' => array('targetUrl'=>$targetUrl,'noti_service'=>$alertdetails['notification_service'],'mobile'=>''),
		'big_picture' =>(isset($alertdetails['noti_img'])?$alertdetails['noti_img']:" ")
		);
		 
		$auth_key = $this->config->item('authentication_key');
		$fields = json_encode($fields);

		 $ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
		  'Authorization: Basic '.$auth_key));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

		$response = curl_exec($ch);
		curl_close($ch); 
		return $response;
	}


    function add_daily_collection() // NOTE : Daily collection service is executed on 2 AM of next day
	{
		$model=	self::SERV_MODEL;
		$previousDay = date('Y-m-d',strtotime("-2 days"));
		$branch = $this->$model->allBranches();
		$this->db->trans_begin();
    	//echo $previousDay;
    	foreach ($branch as $br){
		    $ydaytoday = $this->$model->daily_collection('get',$previousDay,'',$br['id_branch']);
		    if(sizeof($ydaytoday) == 0){
		        $ydaytoday['closing_balance_amt']=0;
		        $ydaytoday['closing_balance_wgt'] = 0;
		        $ydaytoday['closing_weight'] = 0;
		    }
    	    $today = $this->$model->getTodaySummaryBranchWise( date('Y-m-d',strtotime("-1 days")),$br['id_branch']); 
        	if(sizeof($today['canceled']) == 0){
				$today['canceled']['today_cancelled_amt'] = 0;
				$today['canceled']['today_cancelled_wgt'] = 0;
				$today['canceled']['weight_cancelled'] = 0;
			}
			if(sizeof($today['collection']) == 0){
				$today['collection']['today_collection_amt'] = 0;
				$today['collection']['today_collection_wgt'] = 0;
				$today['collection']['today_weight'] = 0;
			}
			if(sizeof($today['closed']) == 0){        	    
				$today['closed']['amtSchClosedAmt'] = 0;
				$today['closed']['wgtSchClosedAmt'] = 0;
				$today['closed']['wgtSchClosedWgt'] = 0;
			}
        	//echo $ydaytoday['closing_balance_amt'];
          	$closing_balance_amt =  $ydaytoday['closing_balance_amt'] + $today['collection']['today_collection_amt'] - $today['closed']['amtSchClosedAmt'] - $today['canceled']['today_cancelled_amt'];
    		$closing_balance_wgt =  $ydaytoday['closing_balance_wgt'] + $today['collection']['today_collection_wgt'] - $today['closed']['wgtSchClosedAmt'] - $today['canceled']['today_cancelled_wgt'];
    		$closing_weight =  $ydaytoday['closing_weight'] + $today['collection']['today_weight'] - $today['closed']['wgtSchClosedWgt'] - $today['canceled']['weight_cancelled'];
             
        
            $instoday = array('date' 			=>  date('Y-m-d',strtotime("-1 days")),
							'today_collection_amt' 	=> $today['collection']['today_collection_amt'],
							'today_collection_wgt' 	=> $today['collection']['today_collection_wgt'],
							'today_weight' 			=> $today['collection']['today_weight'],
							'amtSchClosedAmt'		=> $today['closed']['amtSchClosedAmt'],
							'wgtSchClosedAmt'		=> $today['closed']['wgtSchClosedAmt'],
							'wgtSchClosedWgt'		=> $today['closed']['wgtSchClosedWgt'],
							'today_cancelled_amt'	=> $today['canceled']['today_cancelled_amt'], 
							'today_cancelled_wgt'	=> $today['canceled']['today_cancelled_wgt'], 
							'weight_cancelled'		=> $today['canceled']['weight_cancelled'], 
							'closing_balance_amt'	=> number_format($closing_balance_amt, 2, '.', ''),
							'closing_balance_wgt'	=> number_format($closing_balance_wgt, 2, '.', ''),
							'closing_weight'		=> number_format($closing_weight, 2, '.', ''),
							'date_add'				=> date('Y-m-d H:i:s'),
							'id_branch'             => $br['id_branch']
						); 
			echo print_r($instoday);
		  	$this->$model->daily_collection('insert','',$instoday);
        }
        
        if($this->db->trans_status() === TRUE){
            $this->db->trans_commit();
            echo "Executed successfully.Inserted successfully";
        }else{
            $this->db->trans_rollback();
            echo "Executed successfully.Unable to insert.";echo $this->db->_error_message();
        } 
	}
	public function ajax_interWallet_trans()
	{
		$id_branch = $_GET['id_branch'];
		$date = $_GET['date'];
		$model_name = self::SET_MODEL; 
		$data['trans'] = $this->$model_name->get_interWallet_trans_temp($id_branch,$date); 		
		
		echo "Bills : ".sizeof($data['trans']);
		echo "<pre>";
		print_r($data['trans']);
	}
	
	function loadTempToMainView(){ 
	    $model = self::SERV_MODEL;
	    $data['main_content'] = self::TEST_VIEW.'tempTomain'; 
	    $data['tempData'] = $this->$model->getTempData();
	    $this->load->view('layout/template', $data);
	}
	
	function ajaxtempTotest(){
		$id_branch = $_POST['id_branch'];
		$entry_date = $_POST['entry_date']; 
		$tmp_wal_trans = [1,2,3];
		$del_trans_ids = [1,2,3];
		$till_update = $_POST['till_updated'];
		$success_ids = [];
		$failed_ids = [];
		 $log_path = '../api/logTempToMain.txt';
		    $data = "\n ---- \n Branch : ".$id_branch." Entry Date : ".$entry_date." \n Till Updated : ".(sizeof($success_ids)+$till_update)." \n No of records fetched : ".sizeof($tmp_wal_trans)."\n Success : ".json_encode($success_ids)."\n Failed : ".json_encode($failed_ids)."\n Deleted :".json_encode($del_trans_ids);
		    file_put_contents($log_path,$data,FILE_APPEND | LOCK_EX); 
		    echo 0;
	}
	
	function ajaxtempToMain(){
		$model = self::SERV_MODEL;
		$id_branch = $_POST['id_branch'];
		$entry_date = $_POST['entry_date'];
		$till_update = $_POST['till_updated'];
		$del_trans_ids = [];
		$success_ids = [];
		$failed_ids = [];
		$tmp_wal_trans = $this->$model->getIwalTrans_temp($id_branch,$entry_date);
		if(sizeof($tmp_wal_trans) > 0){
			foreach($tmp_wal_trans as $t){
				$main_wal_trans = $this->$model->getIwalTrans_main($t);
				$tmp_wal_details = $this->$model->getIwalTranDetail_tmp($t['id_inter_waltrans_tmp']);
				$this->db->trans_begin();
				if($main_wal_trans['action'] == 'Add'){
					$insertTran = $this->$model->insertTransinMain($t);
					if(sizeof($tmp_wal_details) > 0 && $insertTran['status']){
						foreach($tmp_wal_details as $d){ 
							$insertDetail = $this->$model->insertTransDetailInMain($d,$insertTran['id_inter_wallet_trans']);
						}
					}				
				}else if($main_wal_trans['action'] == 'Update'){
					$main_trans = $main_wal_trans['trans']; 
					$uTData  = array('actual_redeemed' => $main_trans['actual_redeemed']+$t['actual_redeemed'],
									'redeem_req_pts' => $main_trans['redeem_req_pts']+$t['redeem_req_pts']
								);
					$updTran = $this->$model->updTransin_main($uTData,$main_trans['id_inter_wallet_trans']);
					$main_detailData = $this->$model->getIwalTranDetail_main($main_trans['id_inter_wallet_trans']);
					/*echo "<pre> Main :";
					print_r($main_detailData['trans']);
					echo "<br/>";
					echo "<pre> Temp :";
					print_r($tmp_wal_details);
					echo "<br/>";*/
					if(sizeof($main_detailData['trans']) > 0){
						foreach($main_detailData['trans'] as $main){ 						
							$upd = $this->updateTransDetailInmain($main,$tmp_wal_details);
							$tmp_wal_details = $upd['tmp_detail'];
						}
					}
					/*echo "<pre>A del Temp :";
					print_r($tmp_wal_details);
					echo "<br/>";*/
					if(sizeof($tmp_wal_details) > 0){ 
						foreach($tmp_wal_details as $tmp){  
							$ins = $this->$model->insertTransDetailInMain($tmp,$main_trans['id_inter_wallet_trans']);
						}
					} 
				}
				
				// Detete data in temp tables
				$deleteTrans = $this->$model->delTransAndDetail($t['id_inter_waltrans_tmp']);
				if($deleteTrans){
					$del_trans_ids[]=$t['id_inter_waltrans_tmp'];
				} 
				if($this->db->trans_status() == TRUE){
					$this->db->trans_commit();
					$success_ids[] = $t['id_inter_waltrans_tmp'];  
				}else{
					$this->db->trans_rollback(); 
					$failed_ids[] = $t['id_inter_waltrans_tmp']; 
				}
			}
			// Log
		    $log_path = '../api/logTempToMain.txt';
		    $data = "\n ---------------------------------------------- \n Branch : ".$id_branch." Entry Date : ".$entry_date." \n No of records fetched : ".sizeof($tmp_wal_trans)."\n Success : ".json_encode($success_ids)."\n Failed : ".json_encode($failed_ids)."\n Deleted :".json_encode($del_trans_ids)." \n Executed records : ".(sizeof($success_ids)+$till_update);
		    file_put_contents($log_path,$data,FILE_APPEND | LOCK_EX); 
            // End of log 
            echo sizeof($success_ids);
		}else{
			echo "0";
		}
		
	}
	
	/*function tempToMain(){
		$model = self::SERV_MODEL;
		$id_branch = $_GET['id_branch'];
		$entry_date = $_GET['entry_date'];
		$del_trans_ids = [];	
		$tmp_wal_trans = $this->$model->getIwalTrans_temp($id_branch,$entry_date);
		if(sizeof($tmp_wal_trans) > 0){
			foreach($tmp_wal_trans as $t){
				$main_wal_trans = $this->$model->getIwalTrans_main($t);
				$tmp_wal_details = $this->$model->getIwalTranDetail_tmp($t['id_inter_waltrans_tmp']);
				$this->db->trans_begin();
				if($main_wal_trans['action'] == 'Add'){
					$insertTran = $this->$model->insertTransinMain($t);
					if(sizeof($tmp_wal_details) > 0 && $insertTran['status']){
						foreach($tmp_wal_details as $d){ 
							$insertDetail = $this->$model->insertTransDetailInMain($d,$insertTran['id_inter_wallet_trans']);
						}
					}				
				}else if($main_wal_trans['action'] == 'Update'){
					$main_trans = $main_wal_trans['trans']; 
					$uTData  = array('actual_redeemed' => $main_trans['actual_redeemed']+$t['actual_redeemed'],
									'redeem_req_pts' => $main_trans['redeem_req_pts']+$t['redeem_req_pts']
								);
					$updTran = $this->$model->updTransin_main($uTData,$main_trans['id_inter_wallet_trans']);
					$main_detailData = $this->$model->getIwalTranDetail_main($main_trans['id_inter_wallet_trans']); 
					if(sizeof($main_detailData['trans']) > 0){
						foreach($main_detailData['trans'] as $main){ 						
							$upd = $this->updateTransDetailInmain($main,$tmp_wal_details);
							$tmp_wal_details = $upd['tmp_detail'];
						}
					} 
					if(sizeof($tmp_wal_details) > 0){ 
						foreach($tmp_wal_details as $tmp){  
							$ins = $this->$model->insertTransDetailInMain($tmp,$main_trans['id_inter_wallet_trans']);
						}
					} 
				}
				
				// Detete data in temp tables
				$deleteTrans = $this->$model->delTransAndDetail($t['id_inter_waltrans_tmp']);
				if($deleteTrans){
					$del_trans_ids[]=$t['id_inter_waltrans_tmp'];
				} 
				if($this->db->trans_status() == TRUE){
					$this->db->trans_commit();
					echo "Success : ".$t['id_inter_waltrans_tmp']; 
					echo "############################### <br/>";
				}else{
					$this->db->trans_rollback(); 
					echo "Failed : ".$t['id_inter_waltrans_tmp']." Rolled back <br/>";
					echo "############################### <br/>";
				}
			}
			
			echo "No of records fetched : ".sizeof($tmp_wal_trans)."<br/>";
			echo "<pre> Deleted : ";
			echo print_r($del_trans_ids);
		}else{
			echo "No records to proceed";
		}
		
	}*/
	
	function updateTransDetailInmain($main_detail,$tmp_detail){	
		$model = self::SERV_MODEL;	
		$i=0;
		foreach($tmp_detail as $tmp){ 
			if($tmp['category_code'] == $main_detail['category_code']){
				$d = array('trans_points' 	=> $tmp['trans_points']+$main_detail['trans_points'],
						   'amount'			=>	$tmp['amount']+$main_detail['amount'],
						   'last_update'	=>	date('Y-m-d H:i:s')
					 	  ); 
				$res = $this->$model->updateTransDetail_main($d,$main_detail['id_inter_waltransdetail']);
				/*echo "<pre>D Temp :";
				print_r($tmp_detail);
				echo "<br/>"; */
				$tmp_detail = $this->removeElementWithValue($tmp_detail,'id_tmp_waldetails',$tmp['id_tmp_waldetails']);
				return array('status'=>$res,'tmp_detail'=>$tmp_detail);
			}		
			$i++;		
		}
		return array('tmp_detail'=>$tmp_detail);		
	}
	
	function removeElementWithValue($array, $key, $value){
	     foreach($array as $subKey => $subArray){
	          if($subArray[$key] == $value){
	               unset($array[$subKey]);
	          }
	     }
	     return $array;
	}
	
	// Reset Wallet Transaction	
	/*function insertWalletTR(){
		$model = self::SERV_MODEL;
		$updated_walAc = []; 
		$id_wallet_account = ($this->session->userdata('id_wallet_account')?$this->session->userdata('id_wallet_account'):NULL);
		$wal_accounts = $this->$model->getWalletAccounts($id_wallet_account);
		if(sizeof($wal_accounts) > 0){
			foreach($wal_accounts as $ac){
				if($ac['mobile'] != NULL){
					$this->db->trans_begin();
					$this->$model->insChitwallet($ac['id_wallet_account'],$ac['mobile'],$ac['id_customer']);
					if($this->db->trans_status() == TRUE){
						$this->db->trans_commit();
						$updated_walAc[] = 	$ac['id_wallet_account'];
						$this->session->set_userdata('id_wallet_account',$ac['id_wallet_account']);
					}else{
						$this->db->trans_rollback();	
					}	
				}			
			}
			
			
			echo "No of records fetched : ".sizeof($wal_accounts)."<br/>";
			echo "Session id_wallet_account : ".$this->session->userdata('id_wallet_account')."<br/>";
			echo "<pre> Updated : ";
			echo print_r($updated_walAc);	
		}else{
			echo "No records to proceed";
		}
		
	}*/ 

	function send_queue_sms(){
	   $fields = array(
           'mobile' => array(0=>8526737799,1=>7010198473,2=>8489957773,3=>6383032800,4=>9790100539,5=>909529309,6=>9688550514,7=>9488577633,8=>9965473800,9=>9080802153,10=>9080130172,11=>9095563265),
           'message' => "Queue Message"
           );
            $postData= json_encode($fields); 
  
 
       $ch = curl_init();
       curl_setopt($ch, CURLOPT_URL, "http://nammauzhavan.com/api/v1/smjtvm_sendsms");
       curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/json; charset=utf-8',
      'Authorization: Basic '.base64_encode("lmx@uzhavan:lmx@2018")
       ));
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
      curl_setopt($ch, CURLOPT_HEADER, FALSE);
      curl_setopt($ch, CURLOPT_POST, TRUE);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
     
      $response = curl_exec($ch);
      curl_close($ch);
      $data['response']=$response;
      print_r($data);
	}
    
    
    function postRequest($url, $_data) {
            // convert variables array to string:
                $data = array(); 
                while(list($n,$v) = each($_data))
                {
                    $data[] = "$n=$v";
                }
                $data = implode('&', $data);
                // format --> test1=a&test2=b etc.
                // parse the given URL
                $url = parse_url($url);
                /*if ($url['scheme'] != 'http') {
                	echo "<pre>";print_r($url);
                    die('Only HTTP request are supported !');
                	
                }*/
                // extract host and path:
                $host = $url['host'];
                $path = $url['path'];
                echo "<pre> DATA : ";print_r($data);
                echo "<pre> HOST : ";print_r($host);
                echo "<pre> PATH ";print_r($path);
                // open a socket connection on port 80
                $fp = fsockopen($host, 80);
                // send the request headers:
                fputs($fp, "POST $path HTTP/1.1\r\n");
                fputs($fp, "Host: $host\r\n");
                fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n");
                fputs($fp, "Content-length: ". strlen($data) ."\r\n");
                fputs($fp, "Connection: close\r\n\r\n");
                fputs($fp, $data);
                $result = '';
                while(!feof($fp)) {
                    // receive the results of the request
                    $result .= fgets($fp, 128);
                }
                // close the socket connection:
                fclose($fp);
                // split the result header from the content
                $result = explode("\r\n\r\n", $result, 2);
                $header = isset($result[0]) ? $result[0] : '';
                $content = isset($result[1]) ? $result[1] : '';
                // return as array:
                return array($header, $content);
    }
	function Nettyfish_smsGateway(){
		    $data = array(
                'apikey' => "wC/ePE0tehvWCcC2IqqUXrv5usSBx8s+hEppxZBbNQ8=",
                'clientid' => "e7126180-afd4-4c50-9865-a85248a87398",
                'msisdn' => "8526737799",
                'sid' => "JWLONE",
                'msg' => "Test Message",
                'fl' =>"0",
                "gwid"=>2
            );
            list($header, $content) = $this->postRequest("http://45.127.102.185:6005/api/v2/SendSMS",
                $data
            );
            echo "\n Response : ".$content; 
    }
    
    // Service to Update Maturity Date in scheme_account table (if maturity date is flexible)
    /*function updMaturityDate(){
        $execute = date("Y-m-t", strtotime(date("Y-m-d")));
        if($execute == date("Y-m-d")){
            $this->services_model->updMaturityDate();
        }
        return true;
    }*/
    
    function syncExistingCusData($last_id_cus){
        $sql = $this->db->query("select mobile,id_customer from customer where id_customer >=".$last_id_cus." limit 100"); 
		$customers = $sql->result_array(); 
		foreach($customers as $cus){
		    $syncData = $this->sync_existing_data($cus['mobile'],$cus['id_customer'], 1);
		    echo "<pre>";print_r($syncData);
		    echo $cus['id_customer'];
		} 
    }

     function createExistingCus($id_branch){
        $sql = $this->db->query("select * from customer_reg where is_transferred='N' and id_branch=".$id_branch." group by mobile limit 20000");
		$customers = $sql->result_array();  
	//	echo "<pre>";print_r($customers);exit; 
		$cus_model = self::CUS_MODEL;
		foreach($customers as $cus){
		    $id_customer = $this->$cus_model->isCustomerExist($cus['mobile'],$cus['id_branch']);
		    
		    if($id_customer == 0){
		        
		        $id_state = $this->$cus_model->get_state_id($cus['state']);
                $id_city = $this->$cus_model->get_city_id($cus['city']);
                
    		    // create customer
    		    $cus_data = array(
			       		'info'=>array(
			       			'firstname'			=>  (isset($cus['firstname'])?ucfirst($cus['firstname']): NULL), 
			       			'lastname' 			=>  (isset($cus['lastname'])?ucfirst($cus['lastname']): NULL),
							'id_branch'	    	=>  (isset($cus['id_branch'])?$cus['id_branch']: NULL), 
							'date_of_birth'		=>	(isset($cus['date_of_birth']) && $cus['date_of_birth']!=''? $cus['date_of_birth']: NULL), 	
							'date_of_wed'		=>	(isset($cus['date_of_wed']) && $cus['date_of_wed']!=''? $cus['date_of_wed']: NULL),
							'email'				=>	(isset($cus['email'])?$cus['email']: NULL), 
							'mobile'			=>	(isset($cus['mobile'])?$cus['mobile']: NULL),
							'phone'				=>	(isset($cus['phone'])?$cus['phone']: NULL),
							'passwd'			=>	(isset($cus['passwd'])?$this->$cus_model->__encrypt($cus['passwd']): NULL), 
							'active'			=>	(isset($cus['active'])?$cus['active']: 1),
							'date_add'			=>  date("Y-m-d H:i:s") ,
							'custom_entry_date' =>  (isset($cus['custom_entry_date'])?ucfirst($cus['custom_entry_date']): NULL),
							'added_by'			=>  6    // import
			       		),
			       		
			       		'address'=>array(
    			       			'id_country'		=>	101,
    							'id_state' 			=>	$id_state,
    							'id_city'			=>	$id_city,					
    							'address1'			=>	(isset($cus['address1'])?$cus['address1']:NULL),
    							'address2'			=>	(isset($cus['address2'])?$cus['address2']:NULL),
    							'address3'			=>	(isset($cus['address3'])?$cus['address3']:NULL),
    							'pincode'			=>	(isset($cus['pincode'])?$cus['pincode']:NULL),	
    							'active'			=>	1,							
    							'date_add'			=>	date("Y-m-d H:i:s")
    			       		)
			       );
			       
                echo "<pre>";print_r($cus_data);echo "</pre>";
                $this->db->trans_begin();
                $cus_id =  $this->$cus_model->insert_customer($cus_data);
                if( $this->db->trans_status() === TRUE && $cus_id > 0 ){
                    $this->db->trans_commit();
                    $syncData = $this->sync_existing_data($cus['mobile'],$cus_id, $id_branch);
                    echo "<pre>";print_r($syncData);
                }else{
                    $this->db->trans_rollback();
                    echo "Rolled back";
                    echo $this->db->last_query();
                    echo $this->db->_error_message();
                }
		    }else{
		        echo "Customer already exist";
		        $syncData = $this->sync_existing_data($cus['mobile'],$id_customer, $id_branch);
                echo "<pre>";print_r($syncData);
		    }
		} 
    }
    
    function sync_existing_data($mobile,$id_customer,$id_branch)
	{   
	   $this->load->model("customer_model");
	   $data['id_customer'] = $id_customer;  
	   $data['id_branch'] = $id_branch;  
	   $data['branchWise'] = 0;  
	   $data['mobile'] = $mobile;  
	   $res = $this->customer_model->insExisAcByMobile($data); 
	   //echo $this->db->last_query();echo $this->db->_error_message();exit;
	   if(sizeof($res) > 0)
	   {
	        $this->db->trans_begin();
	   		$payData = $this->customer_model->syncPayData($res);  
	   		//echo $this->db->last_query();echo $this->db->_error_message();exit;
	   	    if(sizeof($payData['succeedIds']) > 0 || $payData['no_records'] > 0){
				$status = $this->customer_model->updateInterTableStatus($res,$payData['succeedIds']);
				if($this->db->trans_status() === TRUE)
				{
				    $this->db->trans_commit();
					return array("status" => TRUE, "msg" => "Purchase Plan registered successfully"); 
				}
				else{
				    echo $this->db->last_query();
				    echo $this->db->_error_message();exit;
				    $this->db->trans_rollback();
					return array("status" => FALSE, "msg" => "Error in updating intermediate tables");
				}
			}
			else
			{
				return array("status" => FALSE, "msg" => "Error in updating payment tables");
			}
	   }
	   else
	   {
	       echo $this->db->last_query();
	   		return array("status" => FALSE, "msg" => "No records to update in scheme account tables");
	   } 
	}
	
	
	function send_singlealert_rate_notification($alertdetails = array()) 
	{
		$registrationIds =array();
		$registrationIds[0] = $alertdetails['token'];
		$content = array(
		"en" => $alertdetails['message']
		);
	    
		$targetUrl='#/app/notification';
		$fields = array(
		'app_id' => $this->config->item('app_id'),
		'include_player_ids' => $registrationIds,
		'contents' => $content,
		'headings' => array("en" => $alertdetails['header']),
		'data' => array('targetUrl'=>$targetUrl,'noti_service'=>$alertdetails['notification_service']),
		'big_picture' => (isset($alertdetails['noti_img'])?$alertdetails['noti_img']:" ")
		);
	
		$auth_key = $this->config->item('authentication_key');
		$fields = json_encode($fields);
			
		 $ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
		  'Authorization: Basic '.$auth_key));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		$response = curl_exec($ch);
		//print_r($response);exit;
		curl_close($ch);  
	return $response;
	}
	
	
	
	
	/*public function sendmjdmarate_noti()
	{
		$model=self::MODEL;		
		$noti=$this->$model->get_metalnotiContent(1);
		$notidata = $noti['data'][0];		
		$data['token']=$this->$model->getDevicetokens();
			//echo "<pre>";print_r($data);echo "</pre>";exit;
			$i =1;
			$token = array();
			foreach ($data['token']  as $row){
				$token[]=$row['token'];
			}	
//			foreach ($data['token']  as $row){
				if(sizeof($token)>0){
					$metalcontent=array('token'					=> $token,
										'notification_service'	=> 1,
										'header'				=> $noti['header'],
										'message'				=> $notidata['message'],
										'mobile'				=> '',
										'footer'				=> $noti['footer'],
					);
					$res = $this->send_bulk_notification($metalcontent);
					$result['noti'][$i]=$res;
					$i++;							
				}
			
//		}
		return $result;
	}*/
	
	/*function send_bulk_notification($alertdetails = array()) 
	{
		$regIdChunk = array_chunk($alertdetails['token'],1000);
		foreach($regIdChunk as $RegId){
            $registrationIds = $RegId;
            $content = array(
            "en" => $alertdetails['message']
            );
        	if($alertdetails['notification_service']== '2'){
				$targetUrl='#/app/offers';
			}
			else if($alertdetails['notification_service']== '3'){
				$targetUrl='#/app/newarrivals';
			}
			else if($alertdetails['notification_service']== '4' || $alertdetails['notification_service']== '5' || $alertdetails['notification_service']== '6'){
				$targetUrl='#/app/paydues';
			}
			else{
				$targetUrl='#/app/notification';
			}
            $fields = array(
            'app_id' => $this->config->item('app_id'),
            'include_player_ids' => $registrationIds,
            'contents' => $content,
            'headings' => array("en" => $alertdetails['header']),
            'subtitle' => array("en" => $alertdetails['footer']),
            'data' => array('targetUrl'=>$targetUrl,'noti_service'=>$alertdetails['notification_service'],'mobile'=>$alertdetails['mobile']),
            'big_picture' =>(isset($alertdetails['noti_img'])?$alertdetails['noti_img']:" ")
            );
            $auth_key = $this->config->item('authentication_key');
            $fields = json_encode($fields);

             $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
              'Authorization: Basic '.$auth_key));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($ch, CURLOPT_HEADER, FALSE);
            curl_setopt($ch, CURLOPT_POST, TRUE);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

            $response = curl_exec($ch);
            curl_close($ch);
        }
	return $response;
	}*/
	
	// For SKTM Group (SCM,TKTM only)
	function syncInterData(){  
		$api_model = "sktm_syncapi_model";  
		$acc_model = "account_model";
		$record_to = 2; // 2 - Online 
		$branch_id = null;
		$acc_id=""; 
        $acc_rec = 0;
        $trans_rec = 0;
        $records = 0;
        $pay_id="";
        $rejected_pay_id = "";
        $rejected_acc_id = "";
		$cus_reg_data = $this->$api_model->getcustomerByStatus('N',$branch_id,$record_to); 
		
		if($cus_reg_data)
        { 
           $records += count($cus_reg_data);
           foreach($cus_reg_data as $client)
		   { 
               // is_registered_online -> 0 - No, 1- Yes , 2 - online record
		       if($client['is_modified'] == 1 && $client['is_registered_online'] >= 1 ){
		           $this->db->trans_begin();
		           // $isClientID =  $this->$api_model->checkClientID($client['id_scheme_account'],"");
		           $acc_data = array(
    									'closed_by'         => $client['closed_by'],
                    					'closing_date'      => $client['closing_date'],
                    					'closing_balance'   => $client['closing_amount'],
                    					'closing_weight'    => $client['closing_weight'],
                    					'closing_add_chgs'  => $client['closing_add_chgs'],
                    				//	'additional_benefits'=> $client['additional_benefits'],
                    					'remark_close'      => $client['remark_close'],
                    					'is_closed'         => $client['is_closed'],
                    					'active'            => ($client['is_closed'] == 1 ? 0:1),
                                        'scheme_acc_number' => $client['scheme_ac_no'],
        								'ref_no'            => $client['clientid'],
                                        'date_upd'	        => date("Y-m-d H:i:s")								
        							);
		           if($client['id_scheme_account'] != null){ 
        		       $acc_status = $this->$api_model->update_account($acc_data,$client['id_scheme_account'],$client['id_customer_reg']);
        		       $id = "ID".''.$client['id_scheme_account']; // Online record
		           }else{
		               $acc_status = $this->$api_model->update_accountByClientId($acc_data,$client['clientid'],$client['id_customer_reg']);
		                $id = "CID".''.$client['clientid']; // Offline record
		           }
    		       
                    if( $this->db->trans_status() == TRUE){
                      $this->db->trans_commit();
                      $acc_rec +=1;				
                      $acc_id .= $id.'|';
                    }else{
                      $this->db->trans_rollback();
                      $rejected_acc_id .= $id.'|';
                    }
		       }
		   }
        }
      //  echo $this->db->last_query();exit;
       
        $trans_data = $this->$api_model->getTransactionByStatus('N',$branch_id,$record_to);  
		if($trans_data)
        {
		  $records += count($trans_data);
		  foreach($trans_data as $trans)
		  {
		     // payment_type -> 1- Online , 2 - Offine
		     if($trans['payment_type'] == 1 ){ 
		         // to update online record
		         // check whether scheme a/c data updated
		         $isClientID =  $this->$api_model->checkClientID($trans['id_scheme_account'],""); 
    	         if($isClientID['status'] &&  $trans['is_modified'] == 1 && $trans['payment_status'] == 1){
    	            $this->db->trans_begin();
    	            $trans_data = array('receipt_no' =>  $trans['receipt_no'], 
    	                                'payment_ref_number' =>  $trans['ref_no'],
    	                                "payment_status" 	=> 1,
    								    'date_upd'	 => date("Y-m-d H:i:s"));
    				$updPayment  = $this->$api_model->updatePayment($trans_data,$trans['payment_type'],$trans['id_scheme_account'],$trans['payment_date']);
    				$trans_rec += 1;
    				if( $this->db->trans_status() == TRUE){
                      $this->db->trans_commit();
                      $trans_rec += 1;
		              $pay_id .=$trans['ref_no'].'|';
                    }else{
                      $this->db->trans_rollback();
                      $rejected_pay_id .=$trans['ref_no'].'|';
                    }
    	         } 
		     }else if($trans['payment_type'] == 2 && ($trans['client_id'] != null || $trans['client_id'] != '')){
		         // to update offline record
		         $isClientID =  $this->$api_model->checkClientID("",$trans['client_id']); 
    		         if($isClientID['status']){
    		             $this->db->trans_begin();
    		             if($trans['payment_status'] == 1){
    		                $id_branch = $this->$api_model->get_branchid($trans['branch_code']);
            				$pay_array = array ( "id_scheme_account" => $isClientID['id_scheme_account'],
            			   						"date_payment" 		=> $trans['payment_date'],
            			   					//	"id_metal" 			=> $trans['metal'],
            			   						"metal_rate" 		=> $trans['rate'],
            			   						"payment_amount"	=> $trans['amount'],
            			   						"metal_weight" 		=> $trans['weight'],
            			   						"payment_mode" 		=> $trans['payment_mode'],
            			   						"payment_status" 	=> 1,
            			   						"payment_type" 		=> "Offline",
            			   						"due_type"          => $trans['due_type'],
            			   						"installment" 		=> $trans['installment_no'],
            			   						"receipt_no" 		=> $trans['receipt_no'],
            			   						"remark" 			=> $trans['remarks'],
            			   						"discountAmt"		=> $trans['discountAmt'],
            			   						"payment_ref_number"=> $trans['ref_no'],
            									"date_upd" 			=> date('Y-m-d H:i:s'),
            									"id_branch"         => $id_branch
            			    					);	
            			    $insPayment  = $this->$api_model->insertPayment($pay_array); 
            			}else{
            				//update if offline record is with cancelled status
            				$upd_array = array ( "payment_status" 	=> 2,
            			   						"receipt_no" 		=> $trans['receipt_no'],
            			   						"remark" 			=> $trans['remarks'],
            			   						"date_upd" 			=> date('Y-m-d H:i:s'),
            			   						"payment_ref_number"=> $trans['ref_no']
            			    					);	
            
            			    $updPayment  = $this->$api_model->updatePayment($upd_array,$trans['payment_type'],$isClientID['id_scheme_account'],$trans['payment_date']);
                           
            			}
            			
            			if( $this->db->trans_status() == TRUE){
                          $this->db->trans_commit();
                          $trans_rec += 1;
			              $pay_id .=$trans['ref_no'].'|';
                        }else{
                          "Rollback!!";
                          $this->db->trans_rollback();
                          $this->db->_error_message();exit;
                          $rejected_pay_id .=$trans['ref_no'].'|';
                        }
        			
    		         }
    	         }
		         
		     }	
		      
		  }
		   
 
		if($acc_id > 0 || $pay_id > 0 || $rejected_acc_id != "" ||  $rejected_pay_id != ""){
		  $remark = array("acc" => $acc_id,	"pay" => $pay_id, "ac_error" => $rejected_acc_id , "pay_error" => $rejected_pay_id);
		  $sync_data = array(
								"total_records"   => $records,
								"scheme_accounts" => $acc_rec,
								"payments"		  => $trans_rec,	
								"sync_date"		  => date('Y-m-d H:i:s'),	
								"remark"          => json_encode($remark)
							);  
							
	
		  $this->$acc_model->insert_sync($sync_data);
		  $result =  array('message' => 'Total '.$records.' records affected '.$acc_rec.' scheme accounts and '.$trans_rec.' payments records. Error Records : Account = '.$rejected_acc_id.' Payment ='.$rejected_pay_id,'class' => 'success','title'=>'Update Client Details');

		}
        else
        {
		  $result = array('message' => 'No records to proceed ','class' => 'info','title'=>'Update Client Details');

		} 	
		echo "<pre>";print_r($result);
	}
	
	// to update scheme ac and payments
	function update_client()
	{   
		$api_model = self::SYN_MODEL;  
		$acc_model = self::ACC_MODEL;
		$record_to = 2; // 2 - Online 
		$branch_id = (isset($_POST['sync_branch_id'])?$_POST['sync_branch_id']:NULL);
	//	$trans_date = (isset($_POST['sync_trans_date'])?$_POST['sync_trans_date']:date('Y-m-d'));
    	$trans_date = (isset($_GET['sync_trans_date'])?$_GET['sync_trans_date']:date('Y-m-d'));  
		$acc_id=""; 
        $acc_rec = 0;
        $trans_rec = 0;
        $records = 0;
        $pay_id="";
        // echo $this->session->userdata('id_branch');exit; 
		$cus_reg_data = $this->$api_model->getcustomerByStatus('N','-1',$record_to,$trans_date);   
		if($cus_reg_data)
        {
           $records += count($cus_reg_data);
           foreach($cus_reg_data as $client)
		   {
               // is_registered_online -> 0 - No, 1- Yes , 2 - online record
		       if($client['is_modified'] == 1 && $client['is_registered_online'] >= 1){
		       		if($client['clientid'] != null){
						$isClientID =  $this->$api_model->checkClientID("",$client['clientid']);
		           
	    		       if($isClientID['status']){
	    					 $acc_data = array(
	    									'closed_by'         => $client['closed_by'],
	                    					'closing_date'      => $client['closing_date'],
	                    					'closing_amount'    => $client['closing_amount'],
	                    					'closing_weight'    => $client['closing_weight'],
	                    					'closing_add_chgs'  => $client['closing_add_chgs'],
	                    					'additional_benefits'=> $client['additional_benefits'],
	                    					'remark_close'      => $client['remark_close'],
	                    					'is_closed'         => $client['is_closed'],
	                    					'active'            => ($client['is_closed'] == 1 ? 0:1),
	                                        'date_upd'	        => date("Y-m-d H:i:s")								
	        							);
	        				 $acc_status = $this->$api_model->update_closed_ac($acc_data,$client['clientid'],$client['id_customer_reg']);
	    		       }else{
						  $acc_data = array(
						                  	'group_code'              => $client['group_code'],
	    								'scheme_acc_number'       => $client['scheme_ac_no'],
	    								'ref_no'                  => $client['clientid'],
	                                    'date_upd'	              => date("Y-m-d H:i:s")								
	    							    );
	    				  $acc_status = $this->$api_model->update_account($acc_data,$client['id_scheme_account'],$client['id_customer_reg']);
					   }
					} 	
    				if($acc_status)
    				{
    					$acc_rec +=1;				
    				    $acc_id .=$client['id_scheme_account'].'|';
    				    $inter_data = array('is_transferred' => 'Y', 'is_modified'=>'N','transfer_date' => date('Y-m-d'),'ref_no'=>$client['ref_no'] );
				        $this->$api_model->updateData($inter_data,$branch,'customer_reg');
    				}
		       }
		   }
        }
        $trans_data = $this->$api_model->getTransactionByTranStatus('N','-1',$record_to,$trans_date); 
		if($trans_data)
        {
		  $records += count($trans_data);
		  foreach($trans_data as $trans)
		  {
		     // payment_type -> 1- Online , 2 - Offine
		     if($trans['payment_type'] == 1 ){ 
		         // to update online record
		         // check whether scheme a/c data updated
		         $isClientID =  $this->$acc_model->checkClientID($trans['id_scheme_account'],"");
    	         if($isClientID['status'] &&  $trans['is_modified'] == 1 && $trans['payment_status'] == 1){
    	            $trans_data = array('receipt_no' =>  $trans['receipt_no'], 
    	                                'payment_ref_number' =>  $trans['ref_no'],
    	                                "payment_status" 	=> 1,
    								    'date_upd'	 => date("Y-m-d H:i:s"));
    				$updPayment  = $this->$api_model->updatePayment($trans_data,$trans['payment_type'],$trans['id_scheme_account'],$trans['payment_date']);
    				$trans_rec += 1;
				    $pay_id .=$trans['ref_no'].'|';
    	         }
		     }else if($trans['payment_type'] == 2 && ($trans['client_id'] != null || $trans['client_id'] != '')){
		         // to update offline record
		         $isClientID =  $this->$api_model->checkClientID("",$trans['client_id']);
    		         if($isClientID['status']){
    		             if($trans['payment_status'] == 1){
            				$pay_array = array ( "id_scheme_account" => $isClientID['id_scheme_account'],
            			   						"id_branch" 		=> $branch_id,
            			   						"date_payment" 		=> $trans['payment_date'],
            			   						"date_add" 			=> $trans['payment_date'],
//            			   						"id_metal" 			=> $trans['id_metal'],
            			   						"metal_rate" 		=> $trans['rate'],
            			   						"payment_amount"	=> $trans['amount'],
            			   						"actual_trans_amt"	=> $trans['amount'],
            			   						"metal_weight" 		=> $trans['weight'],
            			   						"payment_mode" 		=> $trans['payment_mode'],
            			   						"payment_status" 	=> 1,
            			   						"payment_type" 		=> "Offline",
            			   						"due_type"          => $trans['due_type'],
            			   						"installment" 		=> $trans['installment_no'],
            			   						"receipt_no" 		=> $trans['receipt_no'],
            			   						"remark" 			=> $trans['remarks'],
            			   						"discountAmt"		=> $trans['discountAmt'],
            			   						"payment_ref_number"=> $trans['ref_no'],
            									"date_upd" 			=> date('Y-m-d H:i:s')
            			    					);	
            
            			    $insPayment  = $this->$api_model->insertPayment($pay_array);
            			    if($insPayment){					
        						$trans_rec += 1;
				                $pay_id .=$trans['ref_no'].'|';
            				}
            			}else{
            				//update if offline record is with cancelled status
            				$upd_array = array ( "payment_status" 	=> 2,
            			   						"receipt_no" 		=> $trans['receipt_no'],
            			   						"remark" 			=> $trans['remarks'],
            			   						"date_upd" 			=> date('Y-m-d H:i:s'),
            			   						"payment_ref_number"=> $trans['ref_no']
            			    					);	
            
            			    $updPayment  = $this->$api_model->updatePayment($upd_array,$trans['payment_type'],$isClientID['id_scheme_account'],$trans['payment_date']);
            				if($updPayment){
        						$trans_rec += 1;
				                $pay_id .=$trans['ref_no'].'|';
            				}
            
            			} 
        			
    		         }
    	           
    	         }
		         
		     }			  
		  }
		 
		  //$this->session->set_flashdata('chit_alert', array('message' => $records.' records updated','class' => 'success','title'=>'Update Client Details'));
		 if($acc_id != '' || $pay_id != ''){
		  $remark = array("acc" => $acc_id,	"pay" => $pay_id);
		  $sync_data = array(
								"total_records"   => $records,
								"scheme_accounts" => $acc_rec,
								"payments"		  => $trans_rec,	
								"sync_date"		  => date('Y-m-d H:i:s'),	
								"remark"          => json_encode($remark)
							);   
							
	
		  $this->$acc_model->insert_sync($sync_data);
		 $result = array('message' => 'Total '.$records.' records .Updated '.$acc_rec.' scheme accounts and '.$trans_rec.' payments records. ','class' => 'success','title'=>'Update Client Details');
		}
        else
        {
		
			$result = array('message' => 'No updates to proceed','class' => 'danger','title'=>'Update Client Details');
		}			
        $this->load->database('default',true);	
        
        echo json_encode($result);
	}
	
	// offline data trans details
	
	// Delete scheme accounts if no payments from start date to $months [passed months].
     function deleteNoPayments_Acc($months){
		$model = self::MODEL;
		if($months > 0){
		    $delete  = $this->$model->deleteNoPayments_Acc($months);
	        echo $delete;
		}else{
		    echo "Invalid Month";
		}
	    
	}
	

	
	function import_off_cusData()
	{
	 
		
		    $model=self::SET_MODEL;
		    
		 	$pathToUpload=self::OFF_DATA_FILE_PATH;
		 //	print_r($pathToUpload);exit;
	
			 // get all file //
		
		
		//$filename = file_get_contents(self::OFF_DATA_FILE_PATH."customer_reg.csv");
		$filename = array_map('str_getcsv', file(self::OFF_DATA_FILE_PATH."customer_reg.csv"));
		//	print_r($filename);
			
			
		
				
					$data=array(
							'xl_data'	 => $filename	
						);
						 print_r($data);exit;	
						  
					$this->parse_customer_reg($data);	
								
		

	
		 
	}
	

	
		function parse_customer_reg($data)
	{
		$records=array();
		
		
		//send the data in an array format
	//	print_r($data);exit;
		foreach((array)$data  as $row)
		{
		   print_r($row);exit;
			
			  $records[]=array(
			   	 'clientid'				=>$row['clientid'],
			   	 'id_branch'					=>$row['id_branch'],
			   	 'reg_date'					=>$row['reg_date'],
			   	 'ac_name'					=>$row['ac_name'],
			   	 'firstname'						=>$row['firstname'],
			   	 'lastname'					=>$row['lastname'],
			   	 'address1'				=>$row['address1'],
			   	 'address2'				=>$row['address2'],
			   	 'address3'				=>$row['address3'],
			   	 'city'		=>$row['city'],
			   	 'state'		    =>$row['state'],
			   	 'pincode'		    =>$row['pincode'],
			   	 'phone'			=>$row['phone'],
			   	 'mobile'		=>$row['mobile'],
			   	 'email'			=>$row['email'],
			   	 'dt_of_birth'					=>$row['dt_of_birth'],
			   	  'wed_date'					=>$row['wed_date'],
			   	   'sync_scheme_code'					=>$row['sync_scheme_code'],
			   	    'group_code'					=>$row['group_code'],
			   	     'scheme_ac_no'					=>$row['scheme_ac_no'],
			   	      'paid_installments'					=>$row['paid_installments']
			   	 	 	
			   );
			   
			//  print_r($records);exit;
			   
		}
		
     	   
    }
    
     // Auto verify for actuall Pending & failed payment at last 2 days data's only - based on services  //HH
    function verify_cashfreepayment($id_branch,$pg_code)
	{
	    $model=	self::PAY_MODEL;
	    $set_model=	self::SET_MODEL;
	    $previousDay = date('Y-m-d',strtotime("-1 days"));
	    $currentDay = date('Y-m-d',strtotime(" 0 days"));
	    $transData =array();
	    //print_r($currentDay);exit;
	    $data['data'] = $this->$model->getPendpayment_Data($previousDay,$currentDay,$id_branch,$pg_code);
	     // print_r($data);exit;
	     	foreach($data['data'] as $pay)
    		{
             $transData[]     = $pay['txn_ids']; 
    		}
      	//print_r($transData);exit;
      	
      	 $gateway_info = $this->$model->getBranchGatewayData($id_branch,$pg_code);
	    
        $secretKey      = $gateway_info['param_1'];   
        $appId          = $gateway_info['param_3'];  
        
       
		$vCount = 0;
		if(sizeof($transData) > 0){
    		foreach($transData as $tran)
    		{
    		    
    		    $postData = "appId=".$appId."&secretKey=".$secretKey."&orderId=".$tran;
    		   
    			$curl = curl_init();
                curl_setopt_array($curl, array(
                    CURLOPT_URL => $gateway_info['api_url'].'api/v1/order/info/status',
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "POST",
                    CURLOPT_POSTFIELDS => $postData,
                    // Getting  server response parameters //
                    CURLOPT_HTTPHEADER => array(
                        "cache-control: no-cache",
                        "content-type: application/x-www-form-urlencoded"
                    ),
                ));
                $response = curl_exec($curl);
                $err = curl_error($curl);
                curl_close($curl);
                if ($err) {
                    echo "cURL Error #:" . $err;
                } 
                else { 
                    $response = json_decode($response);
                    //echo "<pre>"; print_r($response);exit;
                    //var_dump ($response->status);
                    if($response->status == "OK"){ // OK - Api call success  - ERROR Failed
                       
                        $status_code = $response->txStatus ; // SUCCESS,
                      
                        $txn_id      = $tran;
                        if($txn_id != "" && $status_code != 'PENDING' && $status_code != 'FLAGGED' && $status_code != '')
                        {   
                        	$updateData = array( 
                        		"payu_id"           => $response->referenceId, // referenceId
                        		"payment_ref_number"=> $response->referenceId, 
                        		"payment_mode"      => ($response->paymentMode == "CREDIT_CARD" ? "CC":($response->paymentMode == "DEBIT_CARD" ? "DC":($response->paymentMode == "NET_BANKING" ? "NB":$response->paymentMode))), 
                        		"remark"            => $response->txMsg,
                        	    "payment_status"    => ($status_code == 'SUCCESS' ? 1:($status_code == 'CANCELLED'?4:($status_code == 'FAILED'?3:($status_code == 'REFUND'?6:7))))
                        	); 
                        	//print_r($updateData);exit;
                            $this->db->trans_begin();		
                		    $result =	$this->$model->updateGatewayResponse($updateData,$txn_id);
                		    if($status_code == 'SUCCESS'){
                    		    $payIds = $this->$model->getPayIds($txn_id);
                				if(sizeof($payIds) > 0)
                				{
                					foreach ($payIds as $py)
                					{	
                    				   
                    					$pay =  $this->$model->paymentDB("get",$py['id_payment']); 	
                    						// Multi mode payment
                                        if($pay['payment_mode']!= NULL)
                                         {
                                             $arrayPayMode=array(
                                                            'id_payment'         => $pay['id_payment'],
                                                            'payment_amount'     => (isset($pay['payment_amount']) ? $pay['payment_amount'] : NULL),
                                                            'payment_date'         => date("Y-m-d H:i:s"),
                                                            'created_time'         => date("Y-m-d H:i:s"),
                                                            "payment_mode"       => $pay['payment_mode'],
                                                  
                                                            "remark"             => $txMsg."[".$txTime."] manual verif",
                                                            "payment_ref_number" => $pay['payment_ref_number'],
                                                            "payment_status"     => 1
                                                            );
                                            if(!empty($arrayPayMode)){
                                                $cashPayInsert = $this->$model->insertData($arrayPayMode,'payment_mode_details'); 
                                            }
                                         }
                    					// Referral Code :- allow_referral - 0 => No , 1 => Yes
                    					if($pay['allow_referral'] == 1){
                    					    $ref_data	=	$this->$model->get_refdata($pay['id_scheme_account']);
                        					$ischkref	=	$this->$model->get_ischkrefamtadd($pay['id_scheme_account']);	
                        					if($ref_data['ref_benifitadd_ins_type'] == 1 && $ref_data['referal_code'] != '' && ($ref_data['ref_benifitadd_ins'] == $ref_data['paid_installments']) && $ischkref == TRUE){	
                        						$this->insert_referral_data($ref_data['id_scheme_account']);
                        					}else if($ref_data['ref_benifitadd_ins_type'] == 0 && $ref_data['referal_code'] != '' && $ischkref == TRUE){
                        						$this->insert_referral_data($ref_data['id_scheme_account']);
                        					}
                    					}
                    					// Account number :- schemeacc_no_set - 0 => generate a/c no ,  0 => manual a/c no , 2 => integration , 3 => Integration Auto
                    					$this->load->model("account_model");
                    					if($pay['schemeacc_no_set'] == 0  || $pay['schemeacc_no_set']== 3){   
                    						// Generate a/c no
                    						if($pay['acc_no'] == '' ||  $pay['acc_no'] == null){
                    							$scheme_acc_number = $this->account_model->account_number_generator($pay['id_scheme'],$pay['branch']);
                    							if($scheme_acc_number != NULL){
                    								$updateData['scheme_acc_number'] = $scheme_acc_number;
                    							}
                    							$updSchAc = $this->account_model->update_account($updateData,$pay['id_scheme_account']);
                    							if($pay['gent_clientid'] ==1 && $scheme_acc_number != NULL){        //upd client id & acc no cus reg table based on the settings//
                    							    $updateData['ref_no'] = $this->config->item('cliIDcode')."/".$pay['group_code'].'/'.$scheme_acc_number;
                    							}
                    							if($pay['receipt_no_set'] == 1 && $this->config->item('integrationType') == 2){   
                    							    $updateDatacus['scheme_acc_number'] = $scheme_acc_number;
                    							//	$updateDatacus['ref_no'] = $this->config->item('cliIDcode')."/".$pay['group_code'].'/'.$scheme_acc_number;
                    								$updateDatacus['sync_scheme_code'] =$pay['sync_scheme_code'];
                    							}
                    							
                    								if($pay['gent_clientid'] ==1 && $pay['receipt_no_set'] == 1 && $this->config->item('integrationType') == 2){	
                    											$updateDatacus['ref_no'] = $this->config->item('cliIDcode')."/".$pay['group_code']."/".$scheme_acc_number;
                    									}
                    							
                    							$updSchAc = $this->account_model->update_account($updateData,$pay['id_scheme_account']);
                    						
                    						}
                    					}
                    					// Receipt Number :-  receipt_no_set - 0 => Donot generate , 1 => generate
                    					if($pay['receipt_no_set'] == 1 ){  
                    						$receipt_no = $this->generate_receipt_no($pay['id_scheme'],$pay['branch']);
                    						$pay_array = array('receipt_no'=>$receipt_no,'approval_date'=>date("Y-m-d H:i:s"));  
                    						$result =  $this->$model->paymentDB("update",$pay['id_payment'],$pay_array); 
                    					}
                    					if($pay['edit_custom_entry_date'] == 1 ){  
                    						$pay_array = array('custom_entry_date'=>$pay['custom_entry_date']);  
                    						$result =  $this->$model->paymentDB("update",$pay['id_payment'],$pay_array); 
                    					}
                    					if($pay['firstPayamt_as_payamt'] == 1 || $pay['firstPayamt_maxpayable'] == 1)
                    					{
                    					    	$pay_array = array('firstPayment_amt'=>$pay['payment_amount']);
                    					    	$result =  $this->account_model->update_account($pay_array,$pay['id_scheme_account']); 
                    					}
                        				
                				
                					}
                				}
                		    }
                			if($this->db->trans_status() === TRUE)
                		  	{
                		  	    $vCount = $vCount + 1;
                		  	    $this->db->trans_commit();
                		  	    $pay_data =  $this->$model->getPpayment_data($result['id_payment']); 
                			    $mailSubject = "Reg- ".$this->company['company_name']." saving scheme payment details";
                		        $this->sendSMSMail('7','',$pay_data,$mailSubject,'3',$result['id_payment']);
                			}else{
                			    $this->db->trans_rollback();
                			}				
                        }else{
                			//$response_msg[] = array ( 'msg' => $status_msg , 'Transaction ID' => $txn_id 	);        	
                		}
                    } 
                }
    		}
            if($vCount > 0){
                echo $vCount." payment records verified successfully."; 	
            }
            else
            {
               // echo " No records to verify. Message ". print_r($response); 
                echo " No records to verify."; 
            }
		}
		else
        {
            echo "Select Payments to verify."; 
        }
	}
     
     
      // Auto verify for actuall Pending & failed payment at last 2 days data's only - based on services //
      
      
      
    function genInstallmentNo($id_sch_ac)
    {
        $model =	self::PAY_MODEL;
        $installmentNo = $this->$model->genInstallmentNo($id_sch_ac);
        return $installmentNo;
    }
    
    //To insert payment and registration details in intermediate table
	function insert_common_data_jil($id_payment)
	{
		$model = self::CHITAPI_MODEL;
		$this->load->model($model);
		//getting payment detail
		$pay_data = $this->$model->getPaymentByID($id_payment);	
		//storing temp values
		$trans_date = $pay_data[0]['trans_date'];
		$approval_no = $pay_data[0]['approval_no'];
		$ref_no = $pay_data[0]['ref_no'];
		$id_scheme_account = $pay_data[0]['id_scheme_account'];
		//getting customer detail to post registration again
		 $reg = $this->$model->getCustomerByID($id_scheme_account,$id_payment);		 
		 $isExists = $this->$model->checkTransExists($trans_date,$approval_no,$ref_no);
		if(!$isExists)
		{
			//insert payment detail
			$status =	$this->$model->insert_transaction($pay_data[0]);
			  if($status)
			  {
				  //insert registration detail
				  if($reg)
				 {
					$reg[0]['transfer_jil']	= 'N';
					$reg[0]['transfer_date']= NULL ;
					$reg[0]['ref_no']		= $ref_no;
					$status = $this->$model->insert_CustomerReg($reg[0]);
				 }	 
			  }	
		}	
			return true;
	}
	//To insert payment and registration details in intermediate table
	function insert_common_data($id_payment)
	{
		$model = self::SYN_MODEL;
		$this->load->model($model);
		//getting payment detail
		$pay_data = $this->$model->getPaymentByID($id_payment);	
		//storing temp values
		$ref_no = $pay_data[0]['ref_no'];
		$id_scheme_account = $pay_data[0]['id_scheme_account']; 
		$isCusRegExists = $this->$model->checkCusRegExists($id_scheme_account,$ref_no);
		if(!$isCusRegExists['status']){
		     $reg = $this->$model->getCustomerByID($id_scheme_account);	
             //insert customer registration detail
             if($reg)
             {
            	$reg[0]['record_to']= 1 ;
            	$reg[0]['id_branch']= ( $reg[0]['id_branch'] == 0 ? NULL : $reg[0]['id_branch']);
            	$reg[0]['is_registered_online']= 2 ;  // 2 - online record
            	$reg[0]['ref_no']		= $ref_no;
            	$status = $this->$model->insert_CustomerReg($reg[0]);
             }	
		}
		$isTranExists = $this->$model->checkTransExists($ref_no);
		if(!$isTranExists)
		{
            //insert payment detail
            $pay_data[0]['record_to'] = 1;
            $pay_data[0]['id_branch']= ( $pay_data[0]['id_branch'] == 0 ? NULL : $pay_data[0]['id_branch']);
            $pay_data[0]['payment_type'] = 1;	// 1 - online
            $status =	$this->$model->insert_transaction($pay_data[0]);
		}	
		return true;
	}
	
	function insert_referral_data($id_scheme_account)
	{
	    $log_model    = self::LOG_MODEL;
		$model        = self::PAY_MODEL;
	    $cusmodel = $this->load->model("customer_model");
		$set_model    = self::SET_MODEL;		
	
		$status=FALSE;			
		$serviceID=16;
		$chkreferral=$this->$model->get_referral_code($id_scheme_account);
		if($chkreferral['referal_code']!='' && $chkreferral['is_refferal_by']==1){			
		  $data = $this->$model->get_empreferrals_datas($id_scheme_account);
		}else if($chkreferral['referal_code']!='' && $chkreferral['is_refferal_by']==0){			
			$data = $this->$model->get_cusreferrals_datas($id_scheme_account);
		}
		if(!empty($data))
		{			
			if($data['referal_code']!='' && $data['referal_value']!=''  &&  $data['id_wallet_account']!=''){
			// insert wallet transaction data //
							$wallet_data = array(
							'id_wallet_account' => $data['id_wallet_account'],
							'id_sch_ac'         => $id_scheme_account,
							'date_transaction' =>  date("Y-m-d H:i:s"),
							'id_employee'      =>  $this->session->userdata('uid'),
							'transaction_type' =>  0,
							'value'            => $data['referal_value'],
							'description'      => 'Referral Benefits - '.$data['cusname'].''
							);
						//	echo"<pre>"; print_r($wallet_data);exit;
						$this->load->model("Wallet_model");
				$status =$this->Wallet_model->wallet_transactionDB('insert','',$wallet_data);
				  if($status)
				  {
				  		// Update credit flag in customer table
					  	/* is_refbenefit_crt = 0 -> already  benefit credited  & 1-> yet to credit benefits' */					 		if($chkreferral['is_refferal_by']==0 && $data['cusbenefitscrt_type']==0 && ($data['schrefbenifit_secadd']==0 || $data['schrefbenifit_secadd']==1) ){
							// customer referal - single  
							$this->$cusmodel->update_customer_only(array('is_refbenefit_crt_cus'=>0),$chkreferral['id_customer']);
						}else if($chkreferral['is_refferal_by']==0 && $data['cusbenefitscrt_type']==1 && $data['schrefbenifit_secadd']==1){
							// customer referal - multiple  
							$this->$cusmodel->update_customer_only(array('is_refbenefit_crt_cus'=>1),$chkreferral['id_customer']);
						}else if($chkreferral['is_refferal_by']==1 && $data['empbenefitscrt_type']==0 && ($data['schrefbenifit_secadd']==0 || $data['schrefbenifit_secadd']==1)){	
							 // emp referal - single  					
							$this->$cusmodel->update_customer_only(array('is_refbenefit_crt_emp'=>0),$chkreferral['id_customer']);
						}else if($chkreferral['is_refferal_by']==1 && $data['empbenefitscrt_type']==1 && $data['schrefbenifit_secadd']==1){	
							// emp referal - single  			
							$this->$cusmodel->update_customer_only(array('is_refbenefit_crt_emp'=>1),$chkreferral['id_customer']);
						}
						$log_data = array(
										'id_log'     => $this->id_log,
										'event_date' => date("Y-m-d H:i:s"),
										'module'     => 'Wallet Transaction',
										'operation'  => 'Delete', 
										'record'     => $status['insertID'],  
										'remark'     => 'Wallet Transaction Insert successfully'
									 );
					$this->$log_model->log_detail('insert','',$log_data);							  
				  }
				
				 }
		}
	}
}	

?>