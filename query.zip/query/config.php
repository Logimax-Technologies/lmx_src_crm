<?php
session_start();

$errors = [];
$old_db = ['host' => '', 'username' => '', 'password' => '', 'database' => ''];
$new_db = ['host' => '', 'username' => '', 'password' => '', 'database' => ''];

// Reset session if reset_session POST or expired (1 hour = 3600 seconds)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_session'])) {
    session_unset();
    session_destroy();
    session_start();
} elseif (isset($_SESSION['config_saved_time']) && (time() - $_SESSION['config_saved_time'] > 3600)) {
    session_unset();
    session_destroy();
    session_start();
}

// Load saved configs if any
$old_db = $_SESSION['old_db'] ?? $old_db;
$new_db = $_SESSION['new_db'] ?? $new_db;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['reset_session'])) {
    // Collect POST data
    $old_db = [
        'host' => trim($_POST['old_host'] ?? ''),
        'username' => trim($_POST['old_user'] ?? ''),
        'password' => $_POST['old_pass'] ?? '',
        'database' => trim($_POST['old_db'] ?? ''),
    ];

    $new_db = [
        'host' => trim($_POST['new_host'] ?? ''),
        'username' => trim($_POST['new_user'] ?? ''),
        'password' => $_POST['new_pass'] ?? '',
        'database' => trim($_POST['new_db'] ?? ''),
    ];

    // Validate Old DB fields
    if ($old_db['host'] === '') {
        $errors['old_host'] = "Old DB host is required.";
    }
    if ($old_db['username'] === '') {
        $errors['old_user'] = "Old DB username is required.";
    }
    if ($old_db['database'] === '') {
        $errors['old_db'] = "Old DB database name is required.";
    }

    // Validate New DB fields
    if ($new_db['host'] === '') {
        $errors['new_host'] = "New DB host is required.";
    }
    if ($new_db['username'] === '') {
        $errors['new_user'] = "New DB username is required.";
    }
    if ($new_db['database'] === '') {
        $errors['new_db'] = "New DB database name is required.";
    }

    // If no errors, save to session and redirect
    if (!$errors) {
        $_SESSION['old_db'] = $old_db;
        $_SESSION['new_db'] = $new_db;
        $_SESSION['config_saved_time'] = time();

        header('Location: config.php?success=1');
        exit;
    }
}

// Calculate remaining time for timer (seconds left until 1 hour after saved)
$time_left = 0;
if (isset($_SESSION['config_saved_time'])) {
    $elapsed = time() - $_SESSION['config_saved_time'];
    $time_left = max(3600 - $elapsed, 0);
}

// If this is an AJAX reset_session request, respond with JSON
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_session']) && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    echo json_encode(['status' => 'reset']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Database Configuration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f4f7f6;
        }
        .container {
            max-width: 900px;
        }
        .card {
            border-radius: 12px;
        }
        .form-label {
            font-weight: bold;
        }
        .error-msg {
            color: #d6336c;
            font-size: 0.875em;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white text-center">
            <h4>Database Configuration</h4>
        </div>
        <div class="card-body">

            <?php if ($time_left > 0): ?>
                <div class="alert alert-info text-center" id="timer-box">
                    Session expires in <span id="timer"><?= gmdate("H:i:s", $time_left) ?></span>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success">Configuration saved successfully!</div>
            <?php endif; ?>

            <form method="post" novalidate>
                <div class="row">
                    <div class="col-md-6">
                        <h5 class="mb-3">Old Database</h5>

                        <div class="mb-3">
                            <label class="form-label" for="old_host">Host</label>
                            <input id="old_host" type="text" name="old_host" class="form-control <?= isset($errors['old_host']) ? 'is-invalid' : '' ?>" value="<?= htmlspecialchars($old_db['host']) ?>" required />
                            <?php if (isset($errors['old_host'])): ?>
                                <div class="error-msg"><?= $errors['old_host'] ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="old_user">Username</label>
                            <input id="old_user" type="text" name="old_user" class="form-control <?= isset($errors['old_user']) ? 'is-invalid' : '' ?>" value="<?= htmlspecialchars($old_db['username']) ?>" required />
                            <?php if (isset($errors['old_user'])): ?>
                                <div class="error-msg"><?= $errors['old_user'] ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="old_pass">Password</label>
                            <input id="old_pass" type="password" name="old_pass" class="form-control" value="<?= htmlspecialchars($old_db['password']) ?>" />
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="old_db">Database Name</label>
                            <input id="old_db" type="text" name="old_db" class="form-control <?= isset($errors['old_db']) ? 'is-invalid' : '' ?>" value="<?= htmlspecialchars($old_db['database']) ?>" required />
                            <?php if (isset($errors['old_db'])): ?>
                                <div class="error-msg"><?= $errors['old_db'] ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <h5 class="mb-3">New Database</h5>

                        <div class="mb-3">
                            <label class="form-label" for="new_host">Host</label>
                            <input id="new_host" type="text" name="new_host" class="form-control <?= isset($errors['new_host']) ? 'is-invalid' : '' ?>" value="<?= htmlspecialchars($new_db['host']) ?>" required />
                            <?php if (isset($errors['new_host'])): ?>
                                <div class="error-msg"><?= $errors['new_host'] ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="new_user">Username</label>
                            <input id="new_user" type="text" name="new_user" class="form-control <?= isset($errors['new_user']) ? 'is-invalid' : '' ?>" value="<?= htmlspecialchars($new_db['username']) ?>" required />
                            <?php if (isset($errors['new_user'])): ?>
                                <div class="error-msg"><?= $errors['new_user'] ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="new_pass">Password</label>
                            <input id="new_pass" type="password" name="new_pass" class="form-control" value="<?= htmlspecialchars($new_db['password']) ?>" />
                        </div>

                        <div class="mb-3">
                            <label class="form-label" for="new_db">Database Name</label>
                            <input id="new_db" type="text" name="new_db" class="form-control <?= isset($errors['new_db']) ? 'is-invalid' : '' ?>" value="<?= htmlspecialchars($new_db['database']) ?>" required />
                            <?php if (isset($errors['new_db'])): ?>
                                <div class="error-msg"><?= $errors['new_db'] ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary mt-3" <?= $time_left > 0 ? 'disabled' : '' ?>>Save Configuration</button>
            </form>

            <form id="reset-session-form" method="post" class="mt-3">
                <input type="hidden" name="reset_session" value="1" />
                <button type="submit" class="btn btn-danger">Reset Session</button>
            </form>

        </div>
    </div>
<div style="margin:50px">
    <?php if ($time_left > 0): ?>
        <button class="btn btn-primary" onclick="window.location.href='tables.php'">Tables Comparison</button>
        <button class="btn btn-primary" onclick="window.location.href='columns.php'">Columns Comparison</button>
        <button class="btn btn-primary" onclick="window.location.href='size.php'">Size Comparison</button>
        <button class="btn btn-primary" onclick="window.location.href='insert_datas.php'">Insert Data</button>
    <?php else: ?>
        <button class="btn btn-primary" disabled>Tables Comparison</button>
        <button class="btn btn-primary" disabled>Columns Comparison</button>
        <button class="btn btn-primary" disabled>Size Comparison</button>
        <button class="btn btn-primary" disabled>Insert Data</button>
    <?php endif; ?>
</div>

</div>

<script>
(function(){
    let secondsLeft = <?= $time_left ?>;
    const timerBox = document.getElementById('timer-box');
    const timerSpan = document.getElementById('timer');

    if (secondsLeft > 0) {
        const interval = setInterval(() => {
            secondsLeft--;

            if (secondsLeft <= 0) {
                clearInterval(interval);
                timerSpan.textContent = "00:00:00";
                timerBox.textContent = "Session expired. Resetting session...";
                resetSession();
            } else {
                let h = Math.floor(secondsLeft / 3600);
                let m = Math.floor((secondsLeft % 3600) / 60);
                let s = secondsLeft % 60;
                timerSpan.textContent =
                    String(h).padStart(2, '0') + ':' +
                    String(m).padStart(2, '0') + ':' +
                    String(s).padStart(2, '0');
            }
        }, 1000);
    }

    // Reset session via AJAX
    function resetSession() {
        fetch(window.location.href, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: 'reset_session=1'
        })
        .then(response => response.json())
        .then(data => {
            if(data.status === 'reset') {
                location.reload();
            }
        })
        .catch(() => {
            // fallback: reload anyway
            location.reload();
        });
    }

    // Handle manual reset button via AJAX
    const resetForm = document.getElementById('reset-session-form');
    resetForm.addEventListener('submit', function(e) {
        e.preventDefault();
        resetSession();
    });
})();
</script>

</body>
</html>
