<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-01-12 04:32:41 --> Severity: Warning  --> mkdir(): File exists /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 127
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 05:56:03 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:00:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:13 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 06:05:22 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 13:29:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 13:29:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:19 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 13:29:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 13:29:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-12 23:59:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-12 13:31:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 13:31:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 13:31:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 13:31:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 13:38:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 13:38:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 13:38:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 13:38:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 13:39:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 13:39:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 13:39:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 13:39:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 13:43:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 13:43:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 13:43:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 13:43:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:28:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 23:28:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 23:28:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 23:28:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:28:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:28:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-12 23:30:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
