<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2024-07-22 01:19:47 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2024-07-22 09:50:39 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2024-07-22 10:07:22 --> Severity: Notice  --> Undefined index: id_branch /home/retaillogimaxind/public_html/etail_v3/application/controllers/user.php 1677
ERROR - 2024-07-22 20:17:06 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
