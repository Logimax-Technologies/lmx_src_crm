<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:38 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:11:38 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:11:38 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:11:38 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:11:38 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 10:11:38 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:11:38 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:11:38 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:11:38 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:47 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:11:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:11:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:11:47 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:11:47 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 00:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:11:51 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:11:54 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 10:11:54 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 10:11:54 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 10:11:54 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 10:11:54 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:41:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:41:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:43:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:43:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:43:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:43:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:43:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:43:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:15:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:15:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:15:43 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:15:43 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:15:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:15:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:15:43 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:15:43 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:16:36 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:16:36 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:16:36 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:16:36 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:16:36 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:16:36 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:16:36 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:16:36 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:46:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:20:57 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:20:57 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:20:57 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:20:57 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 10:20:57 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:20:57 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:20:57 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:20:57 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:50:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:22:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:22:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:22:34 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 00:52:34 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 10:22:34 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:22:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:22:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:22:34 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:22:34 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:45 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:26:45 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:26:45 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:26:45 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:26:45 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 10:26:45 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:26:45 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:26:45 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:26:45 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 00:56:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:23 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:30:23 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:30:23 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:30:23 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:30:23 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:30:23 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:30:23 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:30:23 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 10:30:23 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:30:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:30:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:30:41 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:30:41 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 01:00:41 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:30:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:30:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:30:41 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:30:41 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:00:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:24 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:31:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:31:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:31:24 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:31:24 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:31:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:31:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 01:01:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:31:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:31:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:31:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:31:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:31:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 01:01:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:31:29 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 01:01:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:31:31 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 10:31:31 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 10:31:31 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 10:31:31 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 10:31:31 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 01:01:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:01:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:01:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:33:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:33:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:33:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:33:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:33:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:33:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:33:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:33:11 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 01:03:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:33:15 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 10:33:15 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 10:33:15 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 10:33:15 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 10:33:15 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 01:03:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:33:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:33:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:33:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:33:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:33:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:33:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:33:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 01:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:33:35 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 01:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:33:39 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 10:33:39 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 10:33:39 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 10:33:39 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 10:33:39 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 01:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:05:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:05:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:05:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:05:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:05:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:05:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:06:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:06:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:06:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:06:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:06:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:06:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:06:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:06:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:36:15 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:36:15 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:36:15 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:36:15 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:36:15 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:36:15 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:36:15 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:36:15 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 01:06:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:06:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:06:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:06:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:08:49 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:38:49 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:38:49 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:38:49 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:38:49 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:08:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:17 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:39:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:39:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:39:17 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:39:17 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:43 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:39:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:39:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:39:43 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:39:43 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:09:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:15:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:15:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:15:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:15:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:45:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:45:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:45:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:45:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:45:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:45:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:45:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 01:15:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:15:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:15:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:15:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:45:04 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 01:16:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:16:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:16:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:16:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:16:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:16:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:16:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:16:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:16:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:16:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:46:47 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 10:46:47 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 10:46:47 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 10:46:47 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 10:46:47 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 01:16:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:16:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:16:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:16:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:16:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:16:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:16:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:16:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:16:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:16:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:46:50 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:46:50 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:46:50 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:46:50 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:46:50 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:46:50 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:46:50 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 01:16:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:16:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:46:50 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 01:16:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:16:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:44 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:56:44 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:56:44 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:56:44 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:56:44 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 01:26:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:56:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:56:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:56:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:56:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:56:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:56:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 10:56:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 01:26:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:56:48 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 01:26:58 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:56:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 10:56:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 10:56:58 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 10:56:58 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:53:13 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 11:23:13 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 11:23:13 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 11:23:13 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 11:23:13 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 01:53:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 11:23:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 11:23:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 11:23:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 11:23:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 11:23:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 11:23:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 11:23:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 01:53:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:53:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 01:53:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 01:53:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 11:23:57 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:52 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:10:52 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:10:52 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:10:52 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 12:10:52 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 02:40:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:56 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:10:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:10:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:10:56 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 12:10:56 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:40:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:19:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:19:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:19:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:19:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:19:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:19:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:19:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 02:49:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:19:10 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 02:49:15 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 02:49:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:19:16 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:19:16 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:19:16 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 12:19:16 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:33 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:19:33 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:19:33 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:19:33 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 12:19:33 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:19:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:19:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:19:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:19:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:19:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:19:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:19:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 02:49:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:49:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:49:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:19:37 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:55:17 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 12:25:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:25:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:25:17 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 12:25:17 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:55:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:55:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:56:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:56:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:56:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:56:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:26:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:26:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:26:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:26:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:26:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:26:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:26:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:26:47 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 02:56:50 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:26:50 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:26:50 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:26:50 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 12:26:50 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 02:56:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:20 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:38:20 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:38:20 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:38:20 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 12:38:20 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:08:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:38:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:38:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:38:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:38:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:38:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:38:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:38:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 03:08:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:38:26 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:28 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:38:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:38:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:38:28 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 12:38:28 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:08:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 12:45:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:45:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:45:47 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 12:45:47 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 12:45:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:45:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:45:47 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 12:45:47 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:33 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:52:33 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:52:33 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:52:33 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 12:52:33 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:52:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:52:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:52:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:52:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:52:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:52:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:52:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 03:22:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:52:37 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 03:22:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:52:40 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 12:52:40 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 12:52:40 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 12:52:40 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 12:52:40 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 03:22:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:22:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:22:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:53:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:53:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:53:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:53:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:53:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:53:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:53:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 03:23:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:53:18 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 03:23:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:19 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:53:19 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:53:19 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:53:19 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 12:53:19 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:53:24 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:53:24 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:53:24 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:53:24 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:53:24 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:53:24 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 12:53:24 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 03:23:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:53:24 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 03:23:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:53:28 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 12:53:28 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 12:53:28 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 12:53:28 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 12:53:28 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 03:23:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:53:30 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3938
ERROR - 2023-04-07 12:53:30 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3981
ERROR - 2023-04-07 12:53:30 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3982
ERROR - 2023-04-07 12:53:30 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4017
ERROR - 2023-04-07 12:53:30 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4074
ERROR - 2023-04-07 12:53:30 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4075
ERROR - 2023-04-07 12:53:30 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4083
ERROR - 2023-04-07 12:53:30 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4108
ERROR - 2023-04-07 12:53:30 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4114
ERROR - 2023-04-07 12:53:30 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4118
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:53:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:53:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:53:58 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 12:53:58 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:23:58 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 12:53:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 12:53:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 12:53:58 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 12:53:58 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:23:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:23:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:31:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:31:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:31:50 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:31:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:31:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:31:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:31:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:31:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:31:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:01:50 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:01:50 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:01:50 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:01:50 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:31:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:31:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:31:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:31:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:31:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:31:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:31:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:31:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:31:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:31:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:31:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:31:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:31:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:31:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 13:05:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 03:35:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:05:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:05:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:05:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:05:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:05:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:05:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 03:35:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:35:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:35:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:38:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:38:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:38:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:38:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:38:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:38:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:38:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:38:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:08:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:08:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:08:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:08:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:08:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:08:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:08:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 03:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:08:28 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 03:39:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:09:34 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 13:09:34 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 13:09:34 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 13:09:34 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 13:09:34 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 03:39:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:09:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:09:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:09:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:09:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:09:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:09:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:09:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 03:39:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:09:42 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 03:39:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:44 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:09:44 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:09:44 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:09:44 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:09:44 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:39:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:09:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:09:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:09:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:09:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:09:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:09:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:09:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 03:39:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:39:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:09:59 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:01 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:10:01 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:10:01 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:10:01 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:10:01 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:10 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:10:10 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:10:10 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:10:10 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:10:10 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:10:23 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:10:23 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:10:23 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:10:23 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:10:23 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:10:23 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:10:23 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 03:40:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:10:23 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 03:40:26 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:10:26 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:10:26 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 13:10:26 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:10:26 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:40:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:40:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:05 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:11:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:11:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:11:05 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:11:05 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:11:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:11:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:11:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:11:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:11:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:11:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:11:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 03:41:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:11:08 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 03:41:10 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:11:10 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:11:10 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:11:10 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:11:10 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:29 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:11:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:11:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:11:29 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:11:29 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:41:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:47:12 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 13:17:12 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 03:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:17:12 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:17:12 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:17:12 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:18:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:18:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:18:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:18:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:18:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:18:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:18:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 03:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:18:36 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 03:48:42 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 03:48:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:48:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:18:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:18:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:18:43 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:18:43 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:48:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:25:08 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:25:08 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:25:08 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:25:08 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:25:08 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:25:08 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:25:08 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:25:08 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 13:25:08 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 13:25:08 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 13:25:08 --> Severity: Notice  --> Undefined index: payment_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1005
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 03:55:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:40:53 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:40:53 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:40:53 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:40:53 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:10:53 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:40:53 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:40:53 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:40:53 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:40:53 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 13:40:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 04:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:40:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:40:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:40:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:40:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:40:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:40:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 04:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:40:56 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 04:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:40:59 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 13:40:59 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 13:40:59 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 13:40:59 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 13:40:59 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 04:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:41:00 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3938
ERROR - 2023-04-07 13:41:00 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3981
ERROR - 2023-04-07 13:41:00 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3982
ERROR - 2023-04-07 13:41:00 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4017
ERROR - 2023-04-07 13:41:00 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4074
ERROR - 2023-04-07 13:41:00 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4075
ERROR - 2023-04-07 13:41:00 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4083
ERROR - 2023-04-07 13:41:00 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4108
ERROR - 2023-04-07 13:41:00 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4114
ERROR - 2023-04-07 13:41:00 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4118
ERROR - 2023-04-07 04:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:25 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:41:26 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:41:26 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:41:26 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:41:26 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 13:41:26 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:41:26 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:41:26 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:41:26 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:41 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:41:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:41:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:41:41 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:41:41 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:41:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:41:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:41:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:41:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:41:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:41:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:41:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 04:11:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:41:43 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 04:11:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:41:47 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 13:41:47 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 13:41:47 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 13:41:47 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 13:41:47 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 04:11:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:11:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:11:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:41:48 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3938
ERROR - 2023-04-07 13:41:48 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3981
ERROR - 2023-04-07 13:41:48 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3982
ERROR - 2023-04-07 13:41:48 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4017
ERROR - 2023-04-07 13:41:48 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4074
ERROR - 2023-04-07 13:41:48 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4075
ERROR - 2023-04-07 13:41:48 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4083
ERROR - 2023-04-07 13:41:48 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4108
ERROR - 2023-04-07 13:41:48 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4114
ERROR - 2023-04-07 13:41:48 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4118
ERROR - 2023-04-07 04:12:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:35 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:42:36 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:42:36 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:42:36 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:42:36 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:42:36 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:42:36 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:42:36 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:42:36 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:47 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:42:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:42:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 13:42:47 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:42:47 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:12:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:13:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:13:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:43:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:43:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:43:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:43:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:43:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:43:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:43:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 04:13:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:13:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:13:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:13:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:13:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:13:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:43:07 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 04:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:43:12 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 13:43:12 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 13:43:12 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 13:43:12 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 13:43:12 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 04:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:13:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:13:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:13:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:13:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:43:16 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3938
ERROR - 2023-04-07 13:43:16 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3981
ERROR - 2023-04-07 13:43:16 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3982
ERROR - 2023-04-07 13:43:16 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4017
ERROR - 2023-04-07 13:43:16 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4074
ERROR - 2023-04-07 13:43:16 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4075
ERROR - 2023-04-07 13:43:16 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4083
ERROR - 2023-04-07 13:43:16 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4108
ERROR - 2023-04-07 13:43:16 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4114
ERROR - 2023-04-07 13:43:16 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4118
ERROR - 2023-04-07 04:13:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:13:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:43:53 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3938
ERROR - 2023-04-07 13:43:53 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3981
ERROR - 2023-04-07 13:43:53 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3982
ERROR - 2023-04-07 13:43:53 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4017
ERROR - 2023-04-07 13:43:53 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4074
ERROR - 2023-04-07 13:43:53 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4075
ERROR - 2023-04-07 13:43:53 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4083
ERROR - 2023-04-07 13:43:53 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4108
ERROR - 2023-04-07 13:43:53 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4114
ERROR - 2023-04-07 13:43:53 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4118
ERROR - 2023-04-07 04:13:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:13:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:44:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:44:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:44:05 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:44:05 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:14:05 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:44:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:44:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:44:05 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:44:05 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:18 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:44:18 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:44:18 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:44:18 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:44:18 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:44:27 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:27 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:27 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:27 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:27 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:27 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:27 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 04:14:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:44:30 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:30 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:30 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:30 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:30 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:30 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:30 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 04:14:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fsockopen(): Peer certificate CN=`mi3-lr5.supercp.com' did not match expected CN=`smtp.googlemail.com' /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fsockopen(): Failed to enable crypto /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Unknown error) /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 13:44:41 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 04:14:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:44:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:44:42 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 04:14:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:44:42 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 04:14:44 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:44:44 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:44:44 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:44:44 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:44:44 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:14:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:14:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:45:06 --> Severity: Notice  --> Undefined index: pan_no /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1102
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fsockopen(): Peer certificate CN=`mi3-lr5.supercp.com' did not match expected CN=`smtp.googlemail.com' /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fsockopen(): Failed to enable crypto /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Unknown error) /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 13:45:06 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 04:15:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:45:06 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 13:45:06 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 13:45:06 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 04:15:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 13:45:06 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 13:45:06 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 04:15:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:11 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:45:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:45:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:45:11 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:45:11 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:45:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:45:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:45:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:45:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:45:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:45:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 13:45:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 04:15:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:45:13 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 04:15:18 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:45:18 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:45:18 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:45:18 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:45:18 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1700
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1765
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1766
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1769
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Undefined variable: restrict_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1771
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Undefined variable: digi_allowpay_msg /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1775
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Undefined index: daily_payLimit_applicable /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1776
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Undefined index: eligible_amt /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1777
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Undefined index: daily_pay_limit /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1778
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Undefined index: min_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1779
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Undefined index: max_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1780
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 3966
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 3967
ERROR - 2023-04-07 13:45:19 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 3968
ERROR - 2023-04-07 04:15:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:15:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:15:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:47:30 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2023-04-07 13:47:31 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:17:41 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:17:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 13:47:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 13:47:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 13:47:41 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 13:47:41 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:41:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:41:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:41:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:41:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 14:11:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 14:11:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 14:11:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 14:11:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 14:11:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 14:11:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 14:11:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 14:11:43 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:41:52 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 14:11:52 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 14:11:52 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 14:11:52 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 14:11:52 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:41:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:41:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 04:41:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 04:41:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:48:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:48:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:48:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:48:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:48:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:48:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:48:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:48:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 15:18:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 15:18:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 15:18:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 15:18:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 15:18:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 15:18:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 15:18:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 15:18:59 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 05:49:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 15:19:04 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 15:19:04 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 15:19:04 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 15:19:04 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 15:19:04 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 05:49:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 15:19:07 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 15:19:07 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 15:19:07 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 15:19:07 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 15:19:07 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 15:19:07 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 15:19:07 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 05:49:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 15:19:07 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 05:49:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:09 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 15:19:09 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 15:19:09 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 15:19:09 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 15:19:09 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:12 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 15:19:12 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 15:19:12 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 15:19:12 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 15:19:12 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1700
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1765
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1766
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1769
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Undefined variable: restrict_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1771
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Undefined variable: digi_allowpay_msg /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1775
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Undefined index: daily_payLimit_applicable /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1776
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Undefined index: eligible_amt /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1777
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Undefined index: daily_pay_limit /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1778
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Undefined index: min_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1779
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Undefined index: max_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1780
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 3966
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 3967
ERROR - 2023-04-07 15:19:51 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 3968
ERROR - 2023-04-07 05:49:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:59 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 15:19:59 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 15:19:59 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 15:19:59 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 15:19:59 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 05:49:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 06:01:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 06:01:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 06:10:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 06:10:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 06:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 06:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 06:30:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 06:30:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:43 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 16:50:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 16:50:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 16:50:43 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 16:50:43 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 16:50:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 16:50:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 16:50:47 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 16:50:47 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:49 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 16:50:49 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 16:50:49 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 16:50:49 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 16:50:49 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:13 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:43:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:43:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:44:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:44:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:44:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:44:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:44:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:44:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:44:10 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:44:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:44:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:44:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:44:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:44:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:44:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:44:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:44:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:44:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:44:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:44:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:44:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:44:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:44:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:44:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:44:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:44:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:44:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:44:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:44:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:14:11 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:14:11 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 07:47:40 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:47:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:17:40 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:17:40 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 07:50:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:20:19 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:20:19 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:25 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:20:25 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:20:25 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 07:50:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:50:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:50:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:22:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 17:22:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 17:22:24 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 17:22:24 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:25 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:22:25 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 17:22:25 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 17:22:25 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 17:22:25 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:31 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:22:31 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-04-07 17:22:31 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-04-07 17:22:31 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-04-07 17:22:31 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:22:53 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:22:53 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 07:53:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:53:01 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:23:01 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:23:01 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 07:53:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:53:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:53:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:53:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:53:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:25:56 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:25:56 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:55:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:05 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:26:06 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:26:06 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 07:56:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:37 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:56:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:56:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:57:03 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:57:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:57:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:57:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 07:57:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 07:57:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:27:04 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:27:04 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:00:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:00:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:00:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:00:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:01:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:01:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:01:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:01:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:01:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:01:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:32:07 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:32:07 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:02:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:32:22 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 17:32:22 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 17:32:22 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 17:32:22 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 17:32:22 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 17:32:22 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 17:32:22 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 08:02:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:32:23 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:32:23 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:32:23 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 08:02:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:32:34 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 17:32:34 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 17:32:34 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 17:32:34 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 17:32:34 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 08:02:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:02:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:02:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:32:36 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3938
ERROR - 2023-04-07 17:32:36 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3938
ERROR - 2023-04-07 17:32:36 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3938
ERROR - 2023-04-07 17:32:36 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3981
ERROR - 2023-04-07 17:32:36 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3982
ERROR - 2023-04-07 17:32:36 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4017
ERROR - 2023-04-07 17:32:36 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4074
ERROR - 2023-04-07 17:32:36 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4075
ERROR - 2023-04-07 17:32:36 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4083
ERROR - 2023-04-07 17:32:36 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4108
ERROR - 2023-04-07 17:32:36 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4114
ERROR - 2023-04-07 17:32:36 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4118
ERROR - 2023-04-07 08:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:33:47 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:33:47 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:55 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:33:55 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:33:55 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:03:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:03:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:33:58 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:33:58 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:03:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:03:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:04:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:04:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:04:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:04:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:04:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:04:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:04:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:04:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:34:01 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:34:01 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:04:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:04:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:04:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:04:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:07:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:07:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:07:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:07:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:07:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:07:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:07:47 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:07:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:37:48 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:37:48 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:09:57 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:09:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:39:57 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:39:57 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:10:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:19 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 08:10:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:40:20 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:40:20 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:40 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:40:40 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:40:40 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:16:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:16:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:16:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:16:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:16:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:16:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:16:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:16:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:16:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:16:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:16:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:16:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:16:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:16:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:16:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:16:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:18:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:18:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4520
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fsockopen(): Peer certificate CN=`mi3-lr5.supercp.com' did not match expected CN=`smtp.googlemail.com' /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fsockopen(): Failed to enable crypto /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Unknown error) /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 17:48:52 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 08:18:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:18:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:18:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:18:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:21:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:21:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:21:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:21:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:21:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:21:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:21:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:21:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:21:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:21:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:22:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:22:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:22:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:22:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:52:49 --> Severity: Notice  --> Undefined index: pincode /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 455
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fsockopen(): Peer certificate CN=`mi3-lr5.supercp.com' did not match expected CN=`smtp.googlemail.com' /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fsockopen(): Failed to enable crypto /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Unknown error) /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2023-04-07 17:52:49 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2023-04-07 08:22:50 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:22:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:52:50 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:52:50 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:22:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:22:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:23:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:23:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:23:56 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:53:56 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:53:56 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:25:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:25:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:25:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:25:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:25:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:25:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:25:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:25:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:25:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:25:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:26:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:26:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:26:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:26:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:26:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:26:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:27:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:27:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:27:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:27:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 17:57:41 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 17:57:41 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:27:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:27:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:33:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:33:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:33:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:33:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:33:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:33:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:33:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:33:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:04:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 18:04:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 18:04:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 18:04:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 18:04:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 18:04:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 18:04:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 08:34:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:04:05 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:04:05 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:04:05 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 08:34:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:04:09 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:04:09 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:34:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:04:14 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2816
ERROR - 2023-04-07 08:34:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:04:21 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:04:21 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:34:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:34:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:04:31 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:04:31 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:34:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:34:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:35:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:35:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:35:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:35:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:35:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:35:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:35:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:35:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:05:09 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:05:09 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:35:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:35:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:35:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:35:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:35:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:35:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:36:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:36:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:36:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:36:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:36:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:36:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:46 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 08:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:10:47 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:10:47 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:12:08 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:12:08 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:13 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:12:13 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:12:13 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:42:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:12:17 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:12:17 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:42:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:42:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:42:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:05 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:25:06 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:25:06 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:10 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 08:55:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:25:10 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:25:10 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:32:20 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:13 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:39:13 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:39:13 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:09:55 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:09:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:39:55 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:39:55 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:10:35 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:10:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:40:35 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:40:35 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:41:25 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2816
ERROR - 2023-04-07 09:11:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:11:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:11:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:12:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:12:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:12:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:12:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:12:09 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:12:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:42:09 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:42:09 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:38 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 18:44:38 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:44:38 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:14:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:45 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:44:45 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:44:45 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:51 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:14:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:27 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:15:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:15:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:20 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:17:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:47:20 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:47:20 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:50:04 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:50:04 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:16 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:50:16 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:50:16 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:36 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:50:36 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:50:36 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:41 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:50:41 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:50:41 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:43 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:50:43 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:50:43 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:20:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:45 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:50:45 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:50:45 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:50:48 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:50:48 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:20:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:20:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:50:49 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:50:49 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:23:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:53:46 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:53:46 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:56 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:23:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:53:56 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:53:56 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:54:12 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:54:12 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:23 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:54:23 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:54:23 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:24:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:24:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:24:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:25:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:25:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:25:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:25:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:25:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:25:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:25:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:25:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:25:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:25:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:25:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:25:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:25:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:25:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:25:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:25:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:25:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:25:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:25:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:25:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:12 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:56:12 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:56:12 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:26:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:26:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:26:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:57:13 --> Severity: Notice  --> Undefined index: pan_no /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1102
ERROR - 2023-04-07 09:27:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:57:13 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 18:57:13 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 18:57:13 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 18:57:13 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 18:57:13 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 09:27:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1700
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1765
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1766
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1769
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Undefined variable: restrict_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1771
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Undefined variable: digi_allowpay_msg /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1775
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Undefined index: daily_payLimit_applicable /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1776
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Undefined index: eligible_amt /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1777
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Undefined index: daily_pay_limit /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1778
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Undefined index: min_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1779
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Undefined index: max_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1780
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 3966
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 3967
ERROR - 2023-04-07 18:57:36 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 3968
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:57:47 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:57:47 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:53 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:57:53 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:57:53 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:27:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:27:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1700
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1765
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1766
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1769
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Undefined variable: restrict_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1771
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Undefined variable: digi_allowpay_msg /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1775
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Undefined index: daily_payLimit_applicable /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1776
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Undefined index: eligible_amt /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1777
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Undefined index: daily_pay_limit /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1778
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Undefined index: min_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1779
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Undefined index: max_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1780
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 3966
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 3967
ERROR - 2023-04-07 18:57:59 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 3968
ERROR - 2023-04-07 09:27:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:27:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:28:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:28:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:28:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:28:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:29:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:29:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:29:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:29:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:29:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:29:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:29:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:29:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 18:59:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 18:59:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 18:59:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 18:59:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 18:59:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 18:59:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 18:59:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 18:59:01 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:59:01 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 18:59:01 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 09:32:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:27 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:02:27 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:02:27 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:29 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:02:29 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:02:29 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:30 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:02:30 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:02:30 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:32:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:32:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:02:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 19:02:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 19:02:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 19:02:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 19:02:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 19:02:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 19:02:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-04-07 09:32:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:32:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:02:31 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:02:31 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:02:31 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-04-07 09:33:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:33:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:33:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:33:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:03:18 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 19:03:18 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1981
ERROR - 2023-04-07 19:03:18 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1983
ERROR - 2023-04-07 19:03:18 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1985
ERROR - 2023-04-07 19:03:18 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1989
ERROR - 2023-04-07 09:33:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:33:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:33:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:33:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:33:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:33:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:33:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:33:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:33:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:03:52 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:03:52 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:33:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:33:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:04:10 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:04:10 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:34:22 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:04:22 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:04:22 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:34:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:04:24 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:04:24 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:34:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:04:36 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1700
ERROR - 2023-04-07 19:04:36 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1765
ERROR - 2023-04-07 19:04:36 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1766
ERROR - 2023-04-07 19:04:36 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1769
ERROR - 2023-04-07 19:04:36 --> Severity: Notice  --> Undefined variable: restrict_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1771
ERROR - 2023-04-07 19:04:36 --> Severity: Notice  --> Undefined variable: digi_allowpay_msg /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1775
ERROR - 2023-04-07 19:04:36 --> Severity: Notice  --> Undefined index: daily_payLimit_applicable /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1776
ERROR - 2023-04-07 19:04:36 --> Severity: Notice  --> Undefined index: eligible_amt /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1777
ERROR - 2023-04-07 19:04:36 --> Severity: Notice  --> Undefined index: daily_pay_limit /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1778
ERROR - 2023-04-07 19:04:36 --> Severity: Notice  --> Undefined index: min_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1779
ERROR - 2023-04-07 19:04:36 --> Severity: Notice  --> Undefined index: max_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1780
ERROR - 2023-04-07 09:34:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:34:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:34:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:04:45 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1700
ERROR - 2023-04-07 19:04:45 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1765
ERROR - 2023-04-07 19:04:45 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1766
ERROR - 2023-04-07 19:04:45 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1769
ERROR - 2023-04-07 19:04:45 --> Severity: Notice  --> Undefined variable: restrict_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1771
ERROR - 2023-04-07 19:04:45 --> Severity: Notice  --> Undefined variable: digi_allowpay_msg /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1775
ERROR - 2023-04-07 19:04:45 --> Severity: Notice  --> Undefined index: daily_payLimit_applicable /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1776
ERROR - 2023-04-07 19:04:45 --> Severity: Notice  --> Undefined index: eligible_amt /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1777
ERROR - 2023-04-07 19:04:45 --> Severity: Notice  --> Undefined index: daily_pay_limit /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1778
ERROR - 2023-04-07 19:04:45 --> Severity: Notice  --> Undefined index: min_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1779
ERROR - 2023-04-07 19:04:45 --> Severity: Notice  --> Undefined index: max_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1780
ERROR - 2023-04-07 09:35:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:35:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:35:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:35:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:35:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:35:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:35:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:35:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:05:30 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:05:30 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:35:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:35:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:35:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:35:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:35:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:35:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:35:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:35:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:35:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:35:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:05:56 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:05:56 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:35:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:35:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:36:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:36:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:36:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:36:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:06:12 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:06:12 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:36:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:36:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:36:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:36:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:36:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:36:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:36:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:36:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:06:29 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:06:29 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:36:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:36:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:36:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:36:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:06:33 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1700
ERROR - 2023-04-07 19:06:33 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1765
ERROR - 2023-04-07 19:06:33 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1766
ERROR - 2023-04-07 19:06:33 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1769
ERROR - 2023-04-07 19:06:33 --> Severity: Notice  --> Undefined variable: restrict_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1771
ERROR - 2023-04-07 19:06:33 --> Severity: Notice  --> Undefined variable: digi_allowpay_msg /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1775
ERROR - 2023-04-07 19:06:33 --> Severity: Notice  --> Undefined index: daily_payLimit_applicable /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1776
ERROR - 2023-04-07 19:06:33 --> Severity: Notice  --> Undefined index: eligible_amt /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1777
ERROR - 2023-04-07 19:06:33 --> Severity: Notice  --> Undefined index: daily_pay_limit /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1778
ERROR - 2023-04-07 19:06:33 --> Severity: Notice  --> Undefined index: min_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1779
ERROR - 2023-04-07 19:06:33 --> Severity: Notice  --> Undefined index: max_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1780
ERROR - 2023-04-07 09:37:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:37:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:37:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:37:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:37:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:37:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:37:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:37:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:37:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:37:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:37:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:37:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:37:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:37:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:37:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:37:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:37:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:37:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:37:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:37:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:37:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:37:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:37:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:37:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:38:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:38:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:38:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:38:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:38:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:38:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:38:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:38:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:29 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:10:29 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:10:29 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:49 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:10:49 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:10:49 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:42:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:42:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:12:47 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:12:47 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:43:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:43:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:43:50 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:43:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:13:50 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:13:50 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:44:30 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:14:30 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:14:30 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:44:35 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:14:35 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:14:35 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:44:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:44:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:44:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:48:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:48:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:48:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:48:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:28:21 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:28:21 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 09:58:21 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 09:58:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:07:36 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:07:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:37:36 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:37:36 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 10:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:40 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 10:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:10:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:40:41 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:40:41 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:12:52 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-04-07 10:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-04-07 19:42:52 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
ERROR - 2023-04-07 19:42:52 --> Severity: Notice  --> Undefined property: stdClass::$firstPayment_flexible /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 962
