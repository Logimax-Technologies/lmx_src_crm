<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-01-23 02:51:12 --> Severity: Warning  --> mkdir(): File exists /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 127
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-01-23 02:51:12 --> Severity: Warning  --> mkdir(): File exists /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 127
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-01-23 02:51:12 --> Severity: Warning  --> mkdir(): File exists /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 127
ERROR - 2025-01-23 02:51:18 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 360
ERROR - 2025-01-23 02:52:37 --> Severity: Notice  --> Undefined index: email /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1699
ERROR - 2025-01-23 02:52:37 --> Severity: Notice  --> Undefined index: firstname /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1707
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fsockopen(): Peer certificate CN=`*.supercp.com' did not match expected CN=`smtp.googlemail.com' /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fsockopen(): Failed to enable crypto /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Unknown error) /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5068
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5539
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /home/retaillogimaxind/public_html/etail_v3/system/libraries/Email.php 5608
ERROR - 2025-01-23 02:52:37 --> Severity: Warning  --> rawurlencode() expects parameter 1 to be string, array given /home/retaillogimaxind/public_html/etail_v3/application/models/sms_model.php 215
ERROR - 2025-01-23 02:52:39 --> Severity: Notice  --> Undefined index: serv_whatsapp /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1765
ERROR - 2025-01-23 02:52:51 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-01-23 02:52:51 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1541
ERROR - 2025-01-23 02:52:51 --> Severity: Notice  --> Undefined property: stdClass::$amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1663
ERROR - 2025-01-23 02:52:55 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-01-23 02:52:55 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1541
ERROR - 2025-01-23 02:52:55 --> Severity: Notice  --> Undefined property: stdClass::$amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1663
ERROR - 2025-01-23 02:53:06 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-01-23 02:53:06 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1541
ERROR - 2025-01-23 02:53:06 --> Severity: Notice  --> Undefined property: stdClass::$amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1663
ERROR - 2025-01-23 02:53:07 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-01-23 02:53:07 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1541
ERROR - 2025-01-23 02:53:07 --> Severity: Notice  --> Undefined property: stdClass::$amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1663
ERROR - 2025-01-23 02:53:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-01-23 02:53:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-01-23 02:53:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-01-23 02:53:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-01-23 02:53:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-01-23 02:53:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-01-23 02:53:09 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-01-23 02:53:09 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1541
ERROR - 2025-01-23 02:53:09 --> Severity: Notice  --> Undefined property: stdClass::$amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1663
ERROR - 2025-01-23 02:53:17 --> Severity: Notice  --> Undefined index: sch_approval /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2429
ERROR - 2025-01-23 02:53:17 --> Severity: Notice  --> Undefined index: sch_approval /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3218
ERROR - 2025-01-23 02:53:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-01-23 02:53:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-01-23 02:53:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-01-23 02:53:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-01-23 02:53:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-01-23 02:53:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-01-23 02:53:17 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-01-23 02:53:17 --> Severity: Notice  --> Undefined property: stdClass::$amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1663
ERROR - 2025-01-23 02:53:17 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-01-23 02:53:17 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1541
ERROR - 2025-01-23 02:53:17 --> Severity: Notice  --> Undefined property: stdClass::$amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1663
ERROR - 2025-01-23 02:53:17 --> Severity: Warning  --> file_get_contents(https://retail.logimaxindia.com/etail_v3/api/language.txt): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 9225
ERROR - 2025-01-23 02:53:26 --> Severity: Warning  --> array_column() expects parameter 1 to be array, null given /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 11167
ERROR - 2025-01-23 02:53:26 --> Severity: Warning  --> array_sum() expects parameter 1 to be array, null given /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 11167
ERROR - 2025-01-23 02:53:26 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 9263
ERROR - 2025-01-23 13:11:46 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-01-23 13:11:47 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-01-23 14:52:31 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-01-23 15:13:32 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
