<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-04-08 13:49:23 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-04-08 13:50:07 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-04-08 04:28:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 04:28:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 04:30:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 04:30:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 14:00:07 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 569
ERROR - 2025-04-08 04:33:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 04:33:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 14:03:34 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 569
ERROR - 2025-04-08 04:36:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 04:36:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 14:06:46 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 569
ERROR - 2025-04-08 04:39:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 04:39:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 14:09:46 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 569
ERROR - 2025-04-08 14:09:46 --> Severity: Notice  --> Undefined property: stdClass::$schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1039
ERROR - 2025-04-08 14:09:46 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1231
ERROR - 2025-04-08 14:09:46 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 569
ERROR - 2025-04-08 14:09:46 --> Severity: Notice  --> Undefined property: stdClass::$schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1039
ERROR - 2025-04-08 14:09:46 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1231
ERROR - 2025-04-08 14:09:46 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 569
ERROR - 2025-04-08 14:09:46 --> Severity: Notice  --> Undefined property: stdClass::$schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1039
ERROR - 2025-04-08 14:09:46 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1231
ERROR - 2025-04-08 14:09:46 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 569
ERROR - 2025-04-08 14:09:46 --> Severity: Notice  --> Undefined property: stdClass::$schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1039
ERROR - 2025-04-08 14:09:46 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1231
ERROR - 2025-04-08 06:00:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:00:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:00:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:00:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:00:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:00:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:00:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:00:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:01:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:01:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:01:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:01:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:01:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:01:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:01:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:01:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:01:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:01:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:01:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:01:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:02:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:02:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:02:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:02:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:02:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:02:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:02:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:02:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:02:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:02:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:03:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:03:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:03:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:03:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:03:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:03:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:03:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:03:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:03:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:03:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:03:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:03:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:03:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:03:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:06:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:06:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:08:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:08:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:08:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:08:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:08:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:08:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:08:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:12:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:12:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:12:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:12:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:13:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:13:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:15:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:15:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:15:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:15:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:15:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:15:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:15:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 15:45:46 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 570
ERROR - 2025-04-08 15:45:46 --> Severity: Notice  --> Undefined property: stdClass::$schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1040
ERROR - 2025-04-08 15:45:46 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1232
ERROR - 2025-04-08 15:45:46 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 570
ERROR - 2025-04-08 15:45:46 --> Severity: Notice  --> Undefined property: stdClass::$schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1040
ERROR - 2025-04-08 15:45:46 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1232
ERROR - 2025-04-08 15:45:46 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 570
ERROR - 2025-04-08 15:45:46 --> Severity: Notice  --> Undefined property: stdClass::$schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1040
ERROR - 2025-04-08 15:45:46 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1232
ERROR - 2025-04-08 15:45:46 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 570
ERROR - 2025-04-08 15:45:46 --> Severity: Notice  --> Undefined property: stdClass::$schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1040
ERROR - 2025-04-08 15:45:46 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1232
ERROR - 2025-04-08 06:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 15:45:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 329
ERROR - 2025-04-08 15:45:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 329
ERROR - 2025-04-08 15:45:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 329
ERROR - 2025-04-08 15:45:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 329
ERROR - 2025-04-08 15:45:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 329
ERROR - 2025-04-08 15:45:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 329
ERROR - 2025-04-08 06:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 15:45:48 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 570
ERROR - 2025-04-08 15:45:48 --> Severity: Notice  --> Undefined property: stdClass::$schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1040
ERROR - 2025-04-08 15:45:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1232
ERROR - 2025-04-08 15:45:48 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 570
ERROR - 2025-04-08 15:45:48 --> Severity: Notice  --> Undefined property: stdClass::$schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1040
ERROR - 2025-04-08 15:45:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1232
ERROR - 2025-04-08 15:45:48 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 570
ERROR - 2025-04-08 15:45:48 --> Severity: Notice  --> Undefined property: stdClass::$schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1040
ERROR - 2025-04-08 15:45:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1232
ERROR - 2025-04-08 15:45:48 --> Severity: Notice  --> Undefined property: stdClass::$payment_chances /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 570
ERROR - 2025-04-08 15:45:48 --> Severity: Notice  --> Undefined property: stdClass::$schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1040
ERROR - 2025-04-08 15:45:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1232
ERROR - 2025-04-08 06:16:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:16:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:16:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:16:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:16:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:16:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:24:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:24:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:24:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:24:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 15:54:21 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/adminapp_api.php 1344
ERROR - 2025-04-08 15:54:22 --> Severity: Notice  --> Undefined index: serv_whatsapp /home/retaillogimaxind/public_html/etail_v3/application/controllers/adminapp_api.php 1929
ERROR - 2025-04-08 06:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:24:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:24:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:24:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:24:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:25:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:25:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:25:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:25:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:25:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:25:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-04-08 06:25:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-04-08 06:25:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
