<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-03-14 06:20:05 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-03-14 06:20:05 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-03-14 06:20:05 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-03-14 06:20:30 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-03-14 06:20:30 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-03-14 06:20:30 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-03-14 06:20:33 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-03-14 06:20:33 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-03-14 06:20:34 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-03-14 06:20:44 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-03-14 06:20:44 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-03-14 06:20:44 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-03-14 13:21:30 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-03-14 13:22:27 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-03-14 13:36:26 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-03-14 14:09:40 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-03-14 14:09:40 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
