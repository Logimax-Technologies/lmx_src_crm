<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-01-30 02:50:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-30 02:50:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:41 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 02:50:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-30 02:50:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:20:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 02:57:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-30 02:57:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:51 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 02:57:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-30 02:57:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 13:27:57 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 03:37:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-30 03:37:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 03:37:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-30 03:37:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:07:15 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 03:41:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-30 03:41:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:20 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 03:41:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-01-30 03:41:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-30 14:11:24 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-30 14:36:59 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-01-30 14:37:00 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
