<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2024-08-22 02:17:19 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2024-08-22 02:35:16 --> Severity: Notice  --> Undefined index: id_branch /home/retaillogimaxind/public_html/etail_v3/application/controllers/user.php 1677
ERROR - 2024-08-22 11:07:29 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2024-08-22 17:30:33 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
