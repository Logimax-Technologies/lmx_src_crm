<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2024-04-25 07:43:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:43:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 07:43:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:43:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:47 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:43:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:43:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:43:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:43:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:13:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:18 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:23 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:30 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:34 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:38 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:40 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:43 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:45 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:46 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:50 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:52 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:55 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:44:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:44:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:14:58 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:45:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:45:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:45:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:45:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:08 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 07:45:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-04-25 07:45:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2024-04-25 17:15:10 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2024-04-25 18:01:27 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2024-04-25 18:01:27 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
