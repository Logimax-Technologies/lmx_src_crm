<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2024-05-29 00:34:00 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2024-05-29 12:55:36 --> Severity: Notice  --> Undefined variable: schCommodity /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/schemes.php 128
ERROR - 2024-05-29 12:55:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/schemes.php 128
ERROR - 2024-05-29 13:23:04 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
