<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:19:21 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:19:21 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:19:21 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:19:21 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:19:21 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:19:21 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:19:21 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:19:21 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:19:21 --> Severity: Notice  --> Undefined index: token /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 698
ERROR - 2021-06-16 19:19:21 --> Severity: Notice  --> Undefined index: token /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 701
ERROR - 2021-06-16 19:19:21 --> Severity: Notice  --> Undefined index: uuid /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 702
ERROR - 2021-06-16 19:19:21 --> Severity: Notice  --> Undefined index: device_type /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 703
ERROR - 2021-06-16 19:19:21 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:19:21 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:19:21 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:19:21 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:49:21 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:49:30 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:49:30 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:49:30 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:49:30 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:19:30 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:19:30 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:19:30 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:19:30 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:19:30 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:19:30 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:19:30 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:19:30 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:19:30 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:19:30 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:19:30 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:19:30 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 09:49:31 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:49:31 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:20:03 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 155
ERROR - 2021-06-16 19:20:03 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 157
ERROR - 2021-06-16 19:20:03 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 158
ERROR - 2021-06-16 19:20:03 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 159
ERROR - 2021-06-16 19:20:07 --> Severity: Notice  --> Undefined variable: records /home/acdmbcin/public_html/wcrm/v5/application/models/payment_modal.php 2093
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:20:39 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:20:39 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:20:39 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:20:39 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:20:39 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:20:39 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:20:39 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:20:39 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:20:39 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:20:39 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:20:39 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:20:39 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:20:39 --> Severity: Notice  --> Undefined index: token /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 698
ERROR - 2021-06-16 19:20:39 --> Severity: Notice  --> Undefined index: token /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 701
ERROR - 2021-06-16 19:20:39 --> Severity: Notice  --> Undefined index: uuid /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 702
ERROR - 2021-06-16 19:20:39 --> Severity: Notice  --> Undefined index: device_type /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 703
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:50:39 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:20:42 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 155
ERROR - 2021-06-16 19:20:42 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 157
ERROR - 2021-06-16 19:20:42 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 158
ERROR - 2021-06-16 19:20:42 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 159
ERROR - 2021-06-16 19:20:43 --> Severity: Notice  --> Undefined variable: records /home/acdmbcin/public_html/wcrm/v5/application/models/payment_modal.php 2093
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:51:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:21:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:21:45 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:21:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:21:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:21:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:21:45 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:21:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:21:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:21:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:21:45 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:21:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:21:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:22:15 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:22:15 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:22:15 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:22:15 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:22:15 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:22:15 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:22:15 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:22:15 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:22:15 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:22:15 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:22:15 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:22:15 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:22:15 --> Severity: Notice  --> Undefined index: token /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 698
ERROR - 2021-06-16 19:22:15 --> Severity: Notice  --> Undefined index: token /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 701
ERROR - 2021-06-16 19:22:15 --> Severity: Notice  --> Undefined index: uuid /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 702
ERROR - 2021-06-16 19:22:15 --> Severity: Notice  --> Undefined index: device_type /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 703
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:15 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:52:23 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:23 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:52:23 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:23 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:22:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:22:23 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:22:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:22:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:22:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:22:23 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:22:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:22:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:22:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:22:23 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:22:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:22:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 09:52:23 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:52:23 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:22:43 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 155
ERROR - 2021-06-16 19:22:43 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 157
ERROR - 2021-06-16 19:22:43 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 158
ERROR - 2021-06-16 19:22:43 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 159
ERROR - 2021-06-16 19:22:46 --> Severity: Notice  --> Undefined variable: records /home/acdmbcin/public_html/wcrm/v5/application/models/payment_modal.php 2093
ERROR - 2021-06-16 19:23:32 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 155
ERROR - 2021-06-16 19:23:32 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 157
ERROR - 2021-06-16 19:23:32 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 158
ERROR - 2021-06-16 19:23:32 --> Severity: Notice  --> Undefined variable: value /home/acdmbcin/public_html/wcrm/v5/application/views/chitscheme/payment_history.php 159
ERROR - 2021-06-16 19:23:35 --> Severity: Notice  --> Undefined variable: records /home/acdmbcin/public_html/wcrm/v5/application/models/payment_modal.php 2093
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:24:16 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:24:16 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:24:16 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:24:16 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:24:16 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:24:16 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:24:16 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:24:16 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:24:16 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:24:16 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:24:16 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:24:16 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:16 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:24:16 --> Severity: Notice  --> Undefined index: token /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 698
ERROR - 2021-06-16 19:24:16 --> Severity: Notice  --> Undefined index: token /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 701
ERROR - 2021-06-16 19:24:16 --> Severity: Notice  --> Undefined index: uuid /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 702
ERROR - 2021-06-16 19:24:16 --> Severity: Notice  --> Undefined index: device_type /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 703
ERROR - 2021-06-16 09:54:17 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:17 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:54:17 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:17 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:54:23 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:23 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:54:23 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:23 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:24:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:24:23 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:24:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:24:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:24:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:24:23 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:24:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:24:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:24:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:24:23 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:24:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:24:23 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 09:54:24 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:54:24 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:24:40 --> Severity: Notice  --> Undefined variable: records /home/acdmbcin/public_html/wcrm/v5/application/models/payment_modal.php 2093
ERROR - 2021-06-16 09:56:27 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:56:27 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:26:27 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:26:27 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:26:27 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:26:27 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:26:27 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:26:27 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:26:27 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:26:27 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:26:27 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:26:27 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:26:27 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:26:27 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:26:57 --> Severity: Notice  --> Undefined variable: records /home/acdmbcin/public_html/wcrm/v5/application/models/payment_modal.php 2093
ERROR - 2021-06-16 19:27:29 --> Severity: Notice  --> Undefined variable: records /home/acdmbcin/public_html/wcrm/v5/application/models/payment_modal.php 2093
ERROR - 2021-06-16 19:28:03 --> Severity: Notice  --> Undefined variable: records /home/acdmbcin/public_html/wcrm/v5/application/models/payment_modal.php 2093
ERROR - 2021-06-16 09:58:44 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:58:44 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:58:44 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:58:44 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:58:44 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:58:44 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:58:44 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:58:44 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:58:44 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:58:44 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:58:44 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:58:44 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:58:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:58:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:58:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:58:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:58:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 19:28:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 09:58:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:28:45 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:28:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:28:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:28:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:28:45 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:28:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:28:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:28:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:28:45 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:28:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:28:45 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 09:58:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:58:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:58:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:58:45 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:28:45 --> Severity: Notice  --> Undefined index: token /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 698
ERROR - 2021-06-16 19:28:45 --> Severity: Notice  --> Undefined index: token /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 701
ERROR - 2021-06-16 19:28:45 --> Severity: Notice  --> Undefined index: uuid /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 702
ERROR - 2021-06-16 19:28:45 --> Severity: Notice  --> Undefined index: device_type /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 703
ERROR - 2021-06-16 09:58:52 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:58:52 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 09:58:52 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:58:52 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:28:52 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:28:52 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:28:52 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:28:52 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:28:52 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:28:52 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:28:52 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:28:52 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:28:52 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:28:52 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:28:52 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:28:52 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 09:58:53 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 09:58:53 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:30:01 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:30:01 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:30:01 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:30:01 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:30:01 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:30:01 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:30:01 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:30:01 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:30:01 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 19:30:01 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:30:01 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:30:01 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:30:01 --> Severity: Notice  --> Undefined index: token /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 698
ERROR - 2021-06-16 19:30:01 --> Severity: Notice  --> Undefined index: token /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 701
ERROR - 2021-06-16 19:30:01 --> Severity: Notice  --> Undefined index: uuid /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 702
ERROR - 2021-06-16 19:30:01 --> Severity: Notice  --> Undefined index: device_type /home/acdmbcin/public_html/wcrm/v5/application/controllers/mobile_api.php 703
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 10:00:01 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 10:00:02 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 10:00:02 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 10:00:11 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 10:00:11 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 10:00:11 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 10:00:11 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
ERROR - 2021-06-16 19:30:11 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:30:11 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:30:11 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:30:11 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:30:11 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:30:11 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:30:11 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:30:11 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 19:30:11 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:30:11 --> Severity: Warning  --> Division by zero /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1159
ERROR - 2021-06-16 19:30:11 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1195
ERROR - 2021-06-16 19:30:11 --> Severity: Notice  --> Undefined index:  /home/acdmbcin/public_html/wcrm/v5/application/models/mobileapi_model.php 1204
ERROR - 2021-06-16 10:00:11 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 133
ERROR - 2021-06-16 10:00:11 --> Severity: Warning  --> Creating default object from empty value /home/acdmbcin/public_html/wcrm/v5/application/libraries/REST_Controller.php 322
