<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-02-24 10:10:09 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 10:10:09 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 10:10:09 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 10:10:09 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 10:10:09 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-24 10:10:09 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-24 10:10:09 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-24 10:10:09 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-24 10:10:09 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 10:10:09 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 10:10:13 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 10:10:13 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 10:10:16 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 10:10:16 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 10:10:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:10:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:10:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:10:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:10:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:10:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:10:18 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:10:18 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 10:10:18 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 10:22:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 10:22:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 10:22:45 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 10:22:45 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 10:22:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:22:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:22:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:22:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:22:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:22:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:22:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:25:57 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 10:25:57 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 10:25:59 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 10:25:59 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 10:25:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:25:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:25:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:25:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:25:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:25:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 10:25:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:46 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 15:14:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 04:44:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:44:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:44:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 15:15:01 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-24 15:15:01 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-24 15:15:01 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-24 15:15:01 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-24 15:15:01 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 15:15:01 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 04:45:01 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 15:15:01 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 15:15:01 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 15:15:01 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 15:15:01 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:45:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:46:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:46:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:46:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:46:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:46:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:46:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 15:16:52 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 15:16:52 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 04:46:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:46:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:46:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:46:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:46:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:46:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:46:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:46:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 15:16:59 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 15:16:59 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 04:46:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:46:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:46:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:46:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:47:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:47:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:47:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:47:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:47:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 04:47:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 15:17:38 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 15:17:38 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 04:47:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 04:47:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:04:56 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:04:56 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:56 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-24 16:04:56 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:04:56 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:34:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:04:57 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:35:00 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:05:00 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:05:00 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:05:00 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-24 16:05:00 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-24 16:05:00 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-24 16:05:00 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-24 16:05:00 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:05:00 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:35:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:35:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:35:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:05:01 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:05:01 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 16:05:01 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 05:35:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:35:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:05:01 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:05:01 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:05:01 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:06:10 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:06:10 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:06:10 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:06:10 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 16:06:10 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:06:10 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:36:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:36:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:06:23 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:06:23 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:36:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:36:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:06:25 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:06:25 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:08:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-24 16:08:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-24 16:08:28 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-24 16:08:28 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-24 16:08:28 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:08:28 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:38:29 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:08:29 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:38:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:21 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-24 05:40:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:10:21 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:10:21 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 16:10:21 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:10:21 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:10:22 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:26 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-24 16:10:26 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-24 05:40:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
