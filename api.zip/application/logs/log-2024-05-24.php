<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:38:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:39:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:39:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:39:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:39:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:39:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:39:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:39:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:39:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:39:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:39:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:39:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:39:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:39:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:39:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:39:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:39:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:39:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:39:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:39:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:39:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:39:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:39:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:39:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:40:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:40:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:40:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:40:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 13:10:03 --> Severity: Notice  --> Undefined variable: res /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1725
ERROR - 2024-05-24 03:40:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:40:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: scheme_group_code /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1695
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: schemeaccNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1696
ERROR - 2024-05-24 13:10:13 --> Severity: Notice  --> Undefined index: receiptNo_displayFrmt /home/retaillogimaxind/public_html/etail_v3/application/models/adminappapi_model.php 1708
ERROR - 2024-05-24 03:40:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:40:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:40:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:40:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:42:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:42:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:42:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:42:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:42:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:42:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:42:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:42:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:42:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:42:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:43:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:43:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:43:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:43:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:43:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:43:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:43:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:43:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:43:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:43:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:44:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:44:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:47:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:47:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:47:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:47:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:47:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:47:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:47:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:47:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:47:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:47:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:48:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:48:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:48:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:48:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:48:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:48:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:48:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:48:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:48:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:48:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:49:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:49:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 13:19:11 --> Severity: Notice  --> Undefined index: fileName /home/retaillogimaxind/public_html/etail_v3/application/controllers/adminapp_api.php 188
ERROR - 2024-05-24 03:50:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 13:20:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 03:50:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 13:20:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:43 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 03:50:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 13:20:56 --> Severity: Notice  --> Undefined index: panfileName /home/retaillogimaxind/public_html/etail_v3/application/controllers/adminapp_api.php 574
ERROR - 2024-05-24 13:20:56 --> Severity: Notice  --> Undefined index: panfileName /home/retaillogimaxind/public_html/etail_v3/application/controllers/adminapp_api.php 582
ERROR - 2024-05-24 03:50:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:50:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 13:20:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 13:20:56 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2024-05-24 03:50:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:50:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 13:20:56 --> Severity: Notice  --> Undefined index: schemecode /home/retaillogimaxind/public_html/etail_v3/application/controllers/adminapp_api.php 809
ERROR - 2024-05-24 03:53:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:53:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:53:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:53:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:53:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:53:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:53:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:53:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:53:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:53:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:53:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:53:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:53:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:53:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:53:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:53:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:54:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:54:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:54:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:54:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:55:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:55:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 03:56:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-05-24 03:56:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-05-24 16:27:25 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
