<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-01-03 15:45:08 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-01-03 15:45:08 --> Severity: Notice  --> Undefined variable: profile /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/signup.php 37
