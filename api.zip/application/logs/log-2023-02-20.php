<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-02-20 10:18:56 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:18:56 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:18:56 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:18:56 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:18:56 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:24:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:24:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:24:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:24:55 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:24:55 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:24:55 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:24:55 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:24:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:24:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:24:56 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:24:56 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:24:56 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:24:56 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:24:56 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:28:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:29:37 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:29:37 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:29:37 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:29:37 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:29:37 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:29:37 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:29:37 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:29:37 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:29:37 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:29:37 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:29:37 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:29:37 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:29:37 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:08 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:33:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:03:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:33:09 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:33:09 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:03:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:33:23 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:33:23 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:33:23 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:33:23 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:33:23 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:33:23 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:33:23 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:33:23 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:03:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:33:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:33:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:33:24 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:33:24 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:33:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:33:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:24 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:33:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:33:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:33:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:33:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:33:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:03:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:03:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:03:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:33:56 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:33:56 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:04:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:04:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:04:05 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:34:05 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:34:05 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:34:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:34:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:34:05 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:34:05 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:34:05 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:34:05 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:34:05 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:34:05 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:04:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:34:05 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:34:05 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:34:05 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:36:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:36:47 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:36:47 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:47 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:36:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:36:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:36:47 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:36:47 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:36:47 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:36:47 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:06:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:36:47 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:36:47 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:36:47 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:36:47 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:36:47 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:11 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:38:11 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:08:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:17 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:38:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:38:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:38:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:38:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:38:17 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:38:17 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:38:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:38:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:08:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:38:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:38:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:38:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:38:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:38:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:24 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:39:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:32 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:39:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:39:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:39:32 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:39:32 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:39:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:39:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:39:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:39:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:09:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:39:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:39:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:39:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:39:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:39:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:53 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:42:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:59 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:42:59 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:42:59 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:42:59 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:42:59 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:42:59 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:42:59 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:42:59 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:42:59 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:42:59 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:42:59 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:42:59 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:42:59 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:42:59 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:33 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:44:33 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:14:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:40 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 10:44:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:44:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:44:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:44:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 10:44:40 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:44:40 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:44:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:44:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:44:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:44:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:44:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:44:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:44:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:14:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:15:55 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:45:55 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:15:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:16:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:16:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:16:03 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:16:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:16:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:46:03 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:46:03 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:46:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:46:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:46:04 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:46:04 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:46:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:46:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:46:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:46:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:16:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:46:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:46:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:46:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:31 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:49:31 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:49:42 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:49:42 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:49:42 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:49:42 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:49:42 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:49:42 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:19:42 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:49:42 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:49:42 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:49:42 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:49:42 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:19:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:49:42 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:49:42 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:49:42 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:50:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:50:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:50:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:50:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:50:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:50:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:50:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:50:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:50:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:50:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:20:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:20:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:20:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:20:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:50:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 10:50:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 10:50:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 10:50:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 10:50:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 10:50:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 10:50:08 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 10:50:08 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:50:08 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:50:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:50:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:50:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:20:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:20:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:27:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:27:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:32 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:58:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:40 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:58:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:58:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:58:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 10:58:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 10:58:40 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 10:58:40 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 10:58:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:58:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 10:58:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 10:58:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 10:58:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:58:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 10:58:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:31:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:01:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:01:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:31:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:01:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:01:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:01:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:31:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:01:37 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:01:37 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:31:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:01:37 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1710
ERROR - 2023-02-20 11:01:37 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1711
ERROR - 2023-02-20 00:31:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:01:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:01:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:31:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:01:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:01:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:01:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:01:44 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:01:44 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:31:44 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:01:44 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 11:01:44 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 11:01:44 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 11:01:44 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 11:01:44 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:01:44 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:01:44 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:01:44 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:31:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:01:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:01:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:01:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:32:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:32:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:32:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:32:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:32:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:32:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:32:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:32:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:02:28 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-02-20 00:33:04 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:03:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:03:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:03:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 11:03:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 11:03:04 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 11:03:04 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 11:03:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:03:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:33:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:03:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:03:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:03:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:03:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:03:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:33:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:33:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:20 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:06:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:36:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:29 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 11:06:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:06:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 11:06:29 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 11:06:29 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 11:06:29 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:06:29 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:06:29 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:06:29 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:36:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:36:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:06:30 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:06:30 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:06:30 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:06:30 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:06:30 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:39:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:39:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:10:00 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:10:00 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:10:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:10:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:40:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:10:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:10:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:40:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:10:07 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:10:07 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:40:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:10:07 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2760
ERROR - 2023-02-20 00:40:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:10:14 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:10:14 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:40:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:10:15 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:10:15 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:40:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:10:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:10:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:10:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:10:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:10:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:40:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:10:29 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:10:29 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:10:30 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:10:30 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:10:30 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:10:30 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:10:30 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:40:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:10:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:10:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:40:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 00:40:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:40:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:40:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:10:36 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:11:39 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:11:39 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:11:39 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:11:39 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:11:39 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 11:11:39 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 11:11:39 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 11:11:39 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:11:39 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:11:39 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:41:39 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 11:11:39 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:11:39 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:11:39 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:11:54 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:11:54 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:11:54 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:11:54 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:11:54 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:42:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:42:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:42:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:42:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:12:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:12:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:12:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:12:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:12:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:42:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:42:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:42:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:12:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:12:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:12:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:12:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:12:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:12:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:12:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 00:42:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:12:09 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:12:09 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:42:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:42:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:12:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:12:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:12:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:42:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:42:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:42:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:42:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:12:23 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:12:23 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:42:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:12:23 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:12:23 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:12:23 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:42:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:42:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:42:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:53:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:53:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:53:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:53:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:23:41 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:23:41 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:53:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:53:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:24:15 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:24:15 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:24:16 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:24:16 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:24:16 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:54:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:24:18 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:24:18 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:54:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:24:18 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:24:18 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:24:18 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:54:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:24:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:24:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:24:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:24:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:24:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:24:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:24:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:24:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:24:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:54:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:24:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:24:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:24:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 00:54:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:24:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:24:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:54:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:24:36 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:24:36 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:54:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:54:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:54:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:55:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:55:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:25:12 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:25:12 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:55:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:55:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:58:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:58:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:58:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:58:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:58:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:58:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:58:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:58:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:28:41 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:28:41 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:59:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:59:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:59:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:59:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 00:59:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:59:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 00:59:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 00:59:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:29:32 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:30:47 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:30:47 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:00:47 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:30:47 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 11:30:47 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:00:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 11:30:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 11:30:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 11:30:47 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 11:30:47 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 11:30:47 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 11:30:47 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 11:30:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:30:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 11:30:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 01:00:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:00:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:46:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:46:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:46:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:46:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:46:48 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:16:48 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 12:16:48 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 12:16:48 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 12:16:48 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 12:16:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:16:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:46:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:16:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:16:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:46:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:46:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:46:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:46:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:16:49 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:16:49 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:46:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:46:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:16:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:16:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:16:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 01:46:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:46:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:47:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:17:05 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:17:05 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:47:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:47:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:47:12 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 01:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:17:12 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:17:12 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:17:13 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:17:13 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:17:13 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 12:17:13 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 12:17:13 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 12:17:13 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 12:17:13 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:17:13 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 12:17:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:17:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:17:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 01:47:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:47:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:47:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:17:19 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:17:19 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:47:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:47:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:10 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 12:18:10 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 12:18:10 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 12:18:10 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 12:18:10 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:10 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:10 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:10 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:48:10 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:11 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:11 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:48:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:11 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:11 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 12:18:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 12:18:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 12:18:11 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 12:18:11 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 12:18:11 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:11 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:48:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:11 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:18:11 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:18:11 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 01:48:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:19 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:19 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 12:18:19 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 12:18:19 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 12:18:19 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 12:18:19 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:19 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 12:18:19 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:19 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 12:18:19 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:19 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 12:18:19 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:18:19 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:18:19 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 01:48:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:26 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:26 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:48:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:28 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:28 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:48:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:18:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:18:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 01:48:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:18:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:18:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 01:48:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:33 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:33 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:48:36 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:36 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:36 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 12:18:36 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:36 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:36 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 12:18:36 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 12:18:36 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 12:18:36 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 12:18:36 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:36 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:37 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:18:37 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:18:37 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 01:48:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:48 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:48 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 12:18:48 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 12:18:48 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 12:18:48 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 12:18:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:48:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:48:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:48:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:18:49 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:18:49 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 12:18:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:18:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:18:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 01:49:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:49:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:49:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:49:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:49:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:49:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:19:44 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:19:44 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 12:19:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:19:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:19:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 01:49:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:49:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:49:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:49:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:49:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:49:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:49:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:49:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:19:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:19:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:49:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:49:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:19:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:19:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:19:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 01:49:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:49:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:50:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:50:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:50:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:50:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:50:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:50:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:20:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:20:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:50:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:50:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:50:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:50:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:20:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 12:20:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 12:20:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 12:20:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 12:20:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 12:20:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 12:20:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 12:20:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:20:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:20:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 01:50:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:50:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:21:27 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:21:27 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:21:27 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 12:21:27 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 12:21:27 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 12:21:27 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:21:27 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:21:27 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:27 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 12:21:27 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:21:27 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:21:28 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:21:28 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:21:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 12:21:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 12:21:28 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 12:21:28 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 12:21:28 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:21:28 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:21:28 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:21:28 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:21:28 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 01:51:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:34 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 12:21:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:21:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 12:21:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 12:21:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 12:21:34 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 12:21:34 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 12:21:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:21:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:21:35 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 12:21:35 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 01:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 12:21:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:21:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 12:21:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 03:05:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:05:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:05:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:35:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:35:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 13:35:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:35:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:35:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 03:05:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:05:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:35:23 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:35:23 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:35:23 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 03:05:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:05:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:05:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:35:23 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:35:23 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:05:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:05:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:05:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:35:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:35:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:35:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:35:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:35:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:35:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:35:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 03:05:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:35:26 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:35:26 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:05:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:05:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:35:26 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:35:26 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:35:26 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 03:05:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:05:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:17 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:36:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:31 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:36:31 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 13:36:31 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 13:36:31 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 13:36:31 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 13:36:31 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:36:31 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:36:31 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:36:31 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:06:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:36:31 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:36:31 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 13:36:31 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:36:31 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:36:31 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 03:07:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:07:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:07:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:07:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:07:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:07:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:07:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:07:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:37:20 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:39:41 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:39:41 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:09:41 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:39:41 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:39:41 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 13:39:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 13:39:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 13:39:41 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 13:39:41 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 13:39:41 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:39:41 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 13:39:41 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:39:41 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:39:41 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:09:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:26:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:26:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:26:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:56:08 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:56:08 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 13:56:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:56:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:56:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 03:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:26:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:26:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:26:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:56:11 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:56:11 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:26:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:56:11 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:56:11 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:56:11 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 03:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:26:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:26:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:56:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:56:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:56:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:56:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:56:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:56:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 13:56:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 03:26:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:56:13 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:56:13 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:26:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:26:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:56:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:56:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 13:56:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 03:26:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:26:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:26:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:29:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:29:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 13:59:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 13:59:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:29:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:29:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:29:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:29:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 14:00:20 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 14:00:20 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 14:00:20 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 14:00:20 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 14:00:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 14:00:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:30:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 14:00:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 14:00:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:30:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:20 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 14:00:21 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 14:00:21 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 14:00:21 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 14:00:21 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 14:00:21 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 14:00:21 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 14:00:21 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 14:00:21 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 14:00:21 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 14:00:21 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 14:00:21 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 14:00:21 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 14:00:21 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:32 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 14:00:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 14:00:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 14:00:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 14:00:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 14:00:32 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 14:00:32 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 14:00:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 14:00:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 14:00:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 14:00:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 14:00:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 14:00:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 03:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 14:00:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:32:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:02:21 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:02:21 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:32:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:02:21 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:02:21 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:02:21 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:23 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 16:02:23 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:02:23 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:02:23 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:02:23 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:02:23 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:02:23 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:02:23 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:02:23 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:02:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:02:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:02:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:02:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:32:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:02:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 05:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:02:29 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:02:53 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:02:53 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:02:53 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:02:53 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:02:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:02:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:32:53 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:02:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:02:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:02:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:02:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:02:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:02:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:02:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:32:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:33:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 05:33:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:33:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:33:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:03:02 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-02-20 05:33:48 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:03:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:03:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:03:48 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:03:48 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:03:48 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:03:48 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:03:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:03:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:03:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:03:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:03:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:03:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:03:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:33:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:33:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:34:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:34:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:34:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:34:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:34:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:34:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:34:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:34:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:34:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:34:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:34:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:34:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:35:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:35:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:35:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:35:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:05:10 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:05:10 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:35:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:05:13 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:05:13 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:05:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:05:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:05:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:35:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:35:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:35:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:05:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:05:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:35:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:05:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:05:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:05:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:35:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:35:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:35:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:05:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:05:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:05:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:05:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:05:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:05:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:05:20 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 05:35:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:05:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:05:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:35:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:35:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:05:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:05:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:05:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:35:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:35:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:35:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:24 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:10:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:32 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:10:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:10:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:10:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:10:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:10:32 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:10:32 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:10:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:10:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:10:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:10:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:10:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:10:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:10:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:40:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:10:35 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:10:35 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:40:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:10:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:10:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:10:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:40:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:10:47 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:10:47 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:10:47 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:10:47 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:10:47 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:40:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:41:54 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:11:54 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:42:16 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:12:16 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:12:16 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:12:16 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:12:16 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:12:16 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:12:16 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:12:16 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:12:16 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:12:16 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:12:16 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:12:16 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:12:16 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:12:16 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:42:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:42:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:12:19 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:12:19 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:42:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:12:19 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:12:19 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:12:19 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:42:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:42:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:34 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 05:45:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:45:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:43 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:15:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:15:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:15:43 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:15:43 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:15:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:15:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:15:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:15:43 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:15:43 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:15:43 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:45:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:15:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:45:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:46 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:15:46 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:15:46 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:45:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:15:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:45:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:15:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:15:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:45:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:15:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:15:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:15:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:15:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:15:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:15:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 05:45:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:15:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:15:55 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:15:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:15:55 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:15:55 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:45:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:45:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:45:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:46:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:46:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:46:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:16:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:16:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:46:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:16:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:16:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:16:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:46:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:46:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:46:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:46:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:16:08 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:16:08 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:46:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:46:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:46:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:46:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:16:13 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:16:13 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:46:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:16:14 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:16:14 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:46:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:46:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:16:15 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:16:15 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:16:15 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:51:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:21:33 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:21:33 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:51:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:21:33 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1710
ERROR - 2023-02-20 16:21:33 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1711
ERROR - 2023-02-20 05:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:21:35 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:21:35 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:21:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:21:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:21:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:51:37 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:21:37 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:21:37 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:21:37 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:21:37 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:21:37 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:21:37 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:21:37 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:21:37 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:21:37 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:21:37 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:21:37 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:21:37 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:21:37 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 05:51:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:21:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:21:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 05:51:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 05:51:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:21:44 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2760
ERROR - 2023-02-20 06:13:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:43:08 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:43:08 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:43:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:43:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:43:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:13:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:43:12 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:43:12 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:43:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:43:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:43:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:13:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:43:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:43:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:43:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:43:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:43:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:43:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:43:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 06:13:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:43:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:43:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:13:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:43:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:43:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:43:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:13:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:43:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:43:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:13:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:43:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:43:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:43:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:13:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:43:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:43:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:43:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:43:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:43:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:43:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:43:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 06:13:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:43:26 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:43:26 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:13:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:13:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:13:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:43:26 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:43:26 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:43:26 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:15:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:15:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:16:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:16:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:16:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:16:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:16:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:16:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:46:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:46:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:46:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:46:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:46:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:46:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:46:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:46:02 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:46:02 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:16:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:16:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:16:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:16:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:46:02 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:46:02 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:46:02 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:16:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:16:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:16:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:16:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:16:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:16:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:16:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:16:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:46:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:46:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:16:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:16:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 06:20:06 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:50:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:15 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 16:50:15 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:50:15 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:50:15 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:50:15 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:50:15 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:50:15 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:50:15 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:50:15 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:20:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:50:15 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:50:15 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:50:15 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:50:15 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:50:15 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:26:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:26:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:56:14 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:56:14 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:26:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:56:14 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:56:14 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:56:14 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:26:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:26:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:26:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:26:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:26:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:56:57 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:56:57 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:56:57 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:56:57 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:56:57 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 06:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:56:59 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:56:59 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:56:59 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:56:59 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:56:59 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:27:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:27:22 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:57:22 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:27:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:58:35 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:58:35 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:41 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:58:41 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:58:41 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:58:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-20 16:58:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-20 16:58:41 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-20 16:58:41 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-20 16:58:41 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:58:41 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 16:58:41 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:58:41 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:58:41 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:58:41 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:58:41 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:58:49 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:58:49 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:28:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:58:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:58:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:58:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:28:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:58:51 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:58:51 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:58:51 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:58:51 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:58:51 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:58:53 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:58:53 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:58:53 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:58:53 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:58:53 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 06:28:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 16:58:53 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 16:58:53 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-20 06:28:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:58:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 16:58:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 06:28:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:28:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:28:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 16:58:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:58:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 16:58:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 06:29:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:29:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 06:29:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 06:29:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 07:21:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 07:21:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 07:21:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 07:21:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 07:21:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 07:21:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 07:21:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 07:21:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 17:51:36 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-20 17:51:36 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-20 17:51:36 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 17:51:36 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 17:51:36 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-20 07:21:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 07:21:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-20 23:33:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-20 23:33:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
