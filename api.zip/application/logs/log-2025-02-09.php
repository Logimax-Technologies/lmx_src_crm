<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-02-09 03:19:36 --> Severity: Warning  --> mkdir(): File exists /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 127
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-02-09 03:19:36 --> Severity: Warning  --> mkdir(): File exists /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 127
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-02-09 03:19:36 --> Severity: Warning  --> mkdir(): File exists /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 127
ERROR - 2025-02-09 03:20:53 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:20:53 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:20:53 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:12 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:12 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:12 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:33 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:33 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:33 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:36 --> Severity: Notice  --> Undefined variable: tot_bonus_GA_wgt /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2217
ERROR - 2025-02-09 03:21:36 --> Severity: Notice  --> Undefined variable: tot_bonus_GA_wgt /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2223
ERROR - 2025-02-09 03:21:36 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2281
ERROR - 2025-02-09 03:21:36 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2282
ERROR - 2025-02-09 03:21:36 --> Severity: Notice  --> Undefined variable: digi_allowpay_msg /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2291
ERROR - 2025-02-09 03:21:36 --> Severity: Notice  --> Undefined index: daily_payLimit_applicable /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2292
ERROR - 2025-02-09 03:21:36 --> Severity: Notice  --> Undefined index: eligible_amt /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2293
ERROR - 2025-02-09 03:21:36 --> Severity: Notice  --> Undefined index: daily_pay_limit /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2294
ERROR - 2025-02-09 03:21:36 --> Severity: Notice  --> Undefined index: min_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2295
ERROR - 2025-02-09 03:21:36 --> Severity: Notice  --> Undefined index: max_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2296
ERROR - 2025-02-09 03:21:36 --> Severity: Notice  --> Undefined variable: payArray /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2391
ERROR - 2025-02-09 03:21:39 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-02-09 03:21:39 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-02-09 03:21:39 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-02-09 03:21:39 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-02-09 03:21:39 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-02-09 03:21:39 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 327
ERROR - 2025-02-09 03:21:39 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:39 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:39 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:39 --> Severity: Warning  --> file_get_contents(https://retail.logimaxindia.com/etail_v3/api/language.txt): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 9225
ERROR - 2025-02-09 03:21:48 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:48 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:48 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:54 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:54 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:21:54 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:22:01 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:22:01 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:22:01 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:22:05 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:22:05 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:22:05 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:22:56 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:22:56 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:22:56 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:23:03 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:23:03 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:23:03 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:31:10 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:31:10 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:31:10 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:31:16 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:31:16 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 03:31:16 --> Severity: Notice  --> Undefined variable: max_chance /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1502
ERROR - 2025-02-09 14:04:26 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-02-09 14:04:26 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-02-09 17:04:21 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-02-09 17:04:31 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-02-09 06:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 06:55:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:07 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 06:55:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 06:55:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-02-09 17:25:28 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-02-09 17:46:56 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-02-09 17:47:09 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-02-09 11:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 11:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 11:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 11:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 11:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 11:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 11:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 11:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 11:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 11:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 11:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 11:47:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 11:47:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 11:47:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 11:47:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 11:47:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 11:47:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 11:47:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 11:47:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 11:47:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 11:47:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 11:47:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 11:47:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 11:47:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 12:56:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 12:56:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 12:56:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 12:56:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 12:56:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 12:56:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 12:56:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 12:56:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 12:56:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 12:56:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 12:56:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 12:56:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 12:56:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 12:56:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 12:56:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 12:56:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 12:56:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 12:56:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 12:56:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 12:56:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 12:56:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 12:56:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 12:56:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 12:56:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 14:42:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 14:42:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 14:42:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 14:42:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 14:42:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 14:42:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 14:42:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 14:42:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 14:42:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 14:42:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 14:42:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 14:42:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 14:42:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 14:42:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 14:42:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 14:42:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 14:42:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 14:42:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 14:42:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 14:42:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 14:42:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 14:42:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2025-02-09 14:42:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2025-02-09 14:42:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
