<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-05-24 07:32:27 --> Severity: Notice  --> Undefined index: firstname /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 798
ERROR - 2023-05-24 07:32:28 --> Severity: Notice  --> Undefined index: serv_whatsapp /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 820
ERROR - 2023-05-24 09:29:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:29:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 18:59:17 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 472
ERROR - 2023-05-24 18:59:17 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 489
ERROR - 2023-05-24 18:59:17 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 18:59:17 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 18:59:17 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 18:59:17 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:34:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:34:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:04:35 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:04:35 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:04:35 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:04:35 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:04:35 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:04:35 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:34:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:34:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:04:38 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:04:38 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:04:38 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:04:38 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:04:38 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:04:38 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:35:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:35:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:05:25 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:05:25 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:05:25 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:05:25 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:05:25 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:05:25 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:35:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:35:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:35:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:35:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:35:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:35:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:05:27 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 09:37:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:37:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:07:06 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:07:06 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:07:06 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:07:06 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:07:06 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:07:06 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:38:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:38:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 09:38:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:38:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:08:34 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:08:34 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:08:34 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:08:34 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:08:34 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:08:34 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 09:40:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:40:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:10:06 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:10:06 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:40:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 09:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:41:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:11:39 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:11:39 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:11:39 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:11:39 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:11:39 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:11:39 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:41:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:11:54 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:11:54 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:11:54 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:11:54 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:11:54 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:11:54 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:42:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:42:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 09:42:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:42:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:12:20 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:12:20 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:12:20 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:12:20 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:12:20 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:12:20 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:44:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:44:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:14:21 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:14:21 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:14:21 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:14:21 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:14:21 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:14:21 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:44:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:44:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:14:23 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:14:23 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:14:23 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:14:23 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:14:23 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:14:23 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:44:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:44:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:14:23 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:14:23 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:14:23 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:14:23 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:14:23 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:14:23 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:14:24 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:14:24 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:14:24 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:14:24 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:14:24 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:14:24 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:14:24 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:14:24 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:14:24 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:14:24 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:14:24 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:14:24 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:44:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:44:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:14:25 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:14:25 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:14:25 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:14:25 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:14:25 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:14:25 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:44:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:44:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:14:25 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:14:25 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:14:25 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:14:25 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:14:25 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:14:25 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:44:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:44:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:14:58 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:14:58 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 09:45:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:45:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 09:45:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:45:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 09:45:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:45:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 09:45:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:45:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:15:31 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:15:31 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 09:46:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:46:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:16:04 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:16:04 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 09:46:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:46:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:16:06 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:16:06 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 09:46:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:46:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:16:09 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:16:09 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:16:09 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 252
ERROR - 2023-05-24 19:16:09 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 253
ERROR - 2023-05-24 19:16:09 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 254
ERROR - 2023-05-24 19:16:09 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 255
ERROR - 2023-05-24 09:47:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:47:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:17:33 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:17:33 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:17:33 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 504
ERROR - 2023-05-24 19:17:33 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 506
ERROR - 2023-05-24 19:17:33 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 508
ERROR - 2023-05-24 19:17:33 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 510
ERROR - 2023-05-24 09:48:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:48:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:18:23 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:18:23 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:18:23 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 504
ERROR - 2023-05-24 19:18:23 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 506
ERROR - 2023-05-24 19:18:23 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 508
ERROR - 2023-05-24 19:18:23 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 510
ERROR - 2023-05-24 09:48:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-05-24 09:48:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-05-24 19:18:26 --> Severity: Notice  --> Undefined index: branch_settings /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 943
ERROR - 2023-05-24 19:18:26 --> Severity: Notice  --> Undefined index: is_digi /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 977
ERROR - 2023-05-24 19:18:26 --> Severity: Notice  --> Undefined index: cusbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 504
ERROR - 2023-05-24 19:18:26 --> Severity: Notice  --> Undefined index: empbenefitscrt_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 506
ERROR - 2023-05-24 19:18:26 --> Severity: Notice  --> Undefined index: cus_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 508
ERROR - 2023-05-24 19:18:26 --> Severity: Notice  --> Undefined index: emp_ref_code /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 510
