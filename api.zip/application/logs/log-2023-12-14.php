<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-12-14 01:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-12-14 01:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-12-14 01:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-12-14 01:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 11:45:48 --> Severity: Warning  --> mkdir(): File exists /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 63
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 11:45:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1610
ERROR - 2023-12-14 11:45:48 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1610
ERROR - 2023-12-14 11:45:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1690
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 11:45:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1610
ERROR - 2023-12-14 11:45:57 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1610
ERROR - 2023-12-14 11:45:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1690
ERROR - 2023-12-14 01:15:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:15:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:16:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:16:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:16:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:16:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 11:46:13 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1610
ERROR - 2023-12-14 11:46:13 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1610
ERROR - 2023-12-14 11:46:13 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1690
ERROR - 2023-12-14 01:16:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:16:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:16:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:16:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 11:46:16 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2050
ERROR - 2023-12-14 11:46:16 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2051
ERROR - 2023-12-14 11:46:16 --> Severity: Notice  --> Undefined variable: digi_allowpay_msg /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2060
ERROR - 2023-12-14 11:46:16 --> Severity: Notice  --> Undefined index: daily_payLimit_applicable /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2061
ERROR - 2023-12-14 11:46:16 --> Severity: Notice  --> Undefined index: eligible_amt /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2062
ERROR - 2023-12-14 11:46:16 --> Severity: Notice  --> Undefined index: daily_pay_limit /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2063
ERROR - 2023-12-14 11:46:16 --> Severity: Notice  --> Undefined index: min_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2064
ERROR - 2023-12-14 11:46:16 --> Severity: Notice  --> Undefined index: max_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2065
ERROR - 2023-12-14 01:16:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:16:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:16:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:16:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 11:46:26 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1610
ERROR - 2023-12-14 11:46:26 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1610
ERROR - 2023-12-14 11:46:26 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1690
ERROR - 2023-12-14 01:16:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:16:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 01:16:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 01:16:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 11:46:33 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2050
ERROR - 2023-12-14 11:46:33 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2051
ERROR - 2023-12-14 11:46:33 --> Severity: Notice  --> Undefined variable: digi_allowpay_msg /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2060
ERROR - 2023-12-14 11:46:33 --> Severity: Notice  --> Undefined index: daily_payLimit_applicable /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2061
ERROR - 2023-12-14 11:46:33 --> Severity: Notice  --> Undefined index: eligible_amt /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2062
ERROR - 2023-12-14 11:46:33 --> Severity: Notice  --> Undefined index: daily_pay_limit /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2063
ERROR - 2023-12-14 11:46:33 --> Severity: Notice  --> Undefined index: min_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2064
ERROR - 2023-12-14 11:46:33 --> Severity: Notice  --> Undefined index: max_amount /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2065
ERROR - 2023-12-14 08:20:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 18:50:33 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1610
ERROR - 2023-12-14 18:50:33 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1610
ERROR - 2023-12-14 18:50:33 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1690
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-12-14 08:20:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 08:20:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-12-14 18:50:34 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2023-12-14 18:50:34 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2023-12-14 18:50:34 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2023-12-14 18:50:34 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2023-12-14 18:50:34 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2023-12-14 18:50:34 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
ERROR - 2023-12-14 18:50:34 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 163
