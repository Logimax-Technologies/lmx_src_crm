<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-09-11 12:03:58 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2023-09-11 18:19:28 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2023-09-11 18:19:42 --> Severity: Warning  --> getimagesize(https://retail.logimaxindia.com/etail_v3/admin/assets/img/customer/3/customer.jpg): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/dashboard.php 43
