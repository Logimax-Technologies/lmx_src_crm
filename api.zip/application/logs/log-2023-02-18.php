<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 09:58:54 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 09:59:08 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-18 09:59:08 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-18 09:59:08 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-18 09:59:08 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-18 09:59:08 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 09:59:08 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 09:59:08 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 09:59:08 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 09:59:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 09:59:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 09:59:08 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 09:59:08 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 09:59:08 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 09:59:13 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 09:59:13 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 09:59:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 09:59:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 09:59:13 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 09:59:16 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 09:59:16 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 10:02:35 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:02:35 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 10:02:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:02:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:02:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 00:10:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:10:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:10:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:10:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:40:36 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:40:36 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:10:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:10:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:35 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:35 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:35 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 00:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:37 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:37 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:39 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:39 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:39 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:39 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:39 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 00:12:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:41 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1710
ERROR - 2023-02-18 10:42:41 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1711
ERROR - 2023-02-18 00:12:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:41 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:41 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:42 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:42 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:42 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 00:12:43 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-18 10:42:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-18 10:42:43 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-18 10:42:43 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-18 10:42:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:43 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:43 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:43 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 00:12:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:45 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-02-18 00:12:48 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 10:42:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:48 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-18 10:42:48 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-18 10:42:48 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-18 10:42:48 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-18 10:42:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 10:42:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:50 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:50 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 10:42:50 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:50 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:50 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 00:12:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:51 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:51 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:52 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:52 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 10:42:52 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:52 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 10:42:52 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 00:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 10:42:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 00:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:54 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:54 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:56 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:56 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:57 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:57 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:59 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:59 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:12:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:42:59 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 10:42:59 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 00:13:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 00:13:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 10:43:00 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2760
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:06 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 14:42:07 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:07 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:07 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 04:12:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:36 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-18 14:42:36 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-18 14:42:36 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-18 14:42:36 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-18 14:42:36 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:36 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:36 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:36 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:36 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:36 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:36 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:36 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:36 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:36 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 04:12:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:44 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:44 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 04:12:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:49 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 04:12:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:51 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:51 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:52 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1710
ERROR - 2023-02-18 14:42:52 --> Severity: Notice  --> Undefined variable: walletArr /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1711
ERROR - 2023-02-18 04:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:54 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:54 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:54 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:55 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:55 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-18 14:42:55 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-18 14:42:55 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-18 14:42:55 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-18 14:42:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 14:42:55 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:55 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:55 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 04:12:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 04:12:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:12:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:12:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:42:57 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-02-18 04:13:04 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:43:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:43:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 14:43:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-18 14:43:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-18 14:43:04 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-18 14:43:04 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-18 14:43:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:43:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:13:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:43:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:43:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 14:43:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:43:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:43:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 04:13:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:13:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:58:51 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:58:51 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 14:58:51 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:58:51 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:58:51 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 04:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:28:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:28:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:28:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:28:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:58:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:58:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 14:58:55 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:58:55 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:58:55 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 04:28:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:28:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:28:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:58:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 14:58:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 14:58:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 14:58:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 14:58:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 14:58:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 14:58:57 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-02-18 04:28:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:58:58 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:58:58 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:28:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:28:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:28:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:58:58 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:58:58 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:58:58 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 04:29:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:29:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:29:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:59:31 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:59:31 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:29:32 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 14:59:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:29:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:31:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 15:01:07 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-02-18 15:01:07 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-02-18 15:01:07 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-02-18 15:01:07 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-02-18 15:01:07 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 15:01:07 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:31:07 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 15:01:07 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 15:01:07 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 15:01:07 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 15:01:07 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 15:01:07 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 15:01:07 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 15:01:07 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 04:31:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:31:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 15:01:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 15:01:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:31:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 15:01:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 15:01:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 15:01:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 04:31:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:31:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 04:31:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 15:01:25 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 15:01:25 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 04:31:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 04:31:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 07:00:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 07:00:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 07:00:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 07:00:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 07:00:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 07:00:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 17:30:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 17:30:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 17:30:34 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 17:30:34 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 17:30:34 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1357
ERROR - 2023-02-18 07:00:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 07:00:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 07:00:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 07:00:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 07:00:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 07:00:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-02-18 17:30:35 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-02-18 17:30:35 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-02-18 07:00:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-02-18 07:00:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
