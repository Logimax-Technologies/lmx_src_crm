<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2024-07-23 09:34:16 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2024-07-23 09:50:47 --> Severity: Notice  --> Undefined index: id_branch /home/retaillogimaxind/public_html/etail_v3/application/controllers/user.php 1677
ERROR - 2024-07-23 23:56:44 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
