<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 13:13:33 --> Severity: Warning  --> mkdir(): File exists /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 61
ERROR - 2023-11-06 13:13:33 --> Severity: Warning  --> mkdir(): File exists /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 61
ERROR - 2023-11-06 13:13:33 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 13:13:33 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 13:13:33 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 13:13:33 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:43:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:44:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:44:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 13:14:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 13:14:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 13:14:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 13:14:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 13:14:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 02:44:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:12:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 13:42:42 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 13:42:42 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 13:42:42 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 13:42:42 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 13:42:42 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 13:48:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 13:48:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:18:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 13:48:22 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 13:48:22 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 13:48:22 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:22:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:22:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:22:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:22:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:22:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:22:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 13:52:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:52:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:52:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:52:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:52:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:52:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:52:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:52:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 13:52:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 13:52:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:23:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:23:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 13:53:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 13:53:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 13:53:54 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 13:53:54 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 13:53:54 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:23:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 13:53:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:53:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:53:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:53:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:53:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:53:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:53:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 13:53:55 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 13:53:55 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 13:53:55 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:32:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:02:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:02:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:02:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:02:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:02:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:02:56 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:02:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:32:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:32:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:33:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:33:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:34:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:34:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:04:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:04:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:04:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:04:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:04:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:34:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:34:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:34:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:34:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:34:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:04:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:04:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:04:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 03:34:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 14:04:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:04:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:04:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 03:34:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:04:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:04:06 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:04:06 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:04:06 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:39:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:09:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:09:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:09:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:09:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:09:59 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:09:59 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:09:59 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:39:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:39:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:11:49 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:11:49 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:41:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:11:49 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:11:49 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:11:49 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:41:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:11:51 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:11:51 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:11:51 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:11:51 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:53:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:23:44 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:23:44 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:23:44 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:23:44 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:23:44 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:53:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:53:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:53:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:53:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:53:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:53:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:23:46 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:23:46 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:23:46 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:23:46 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:23:46 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:23:46 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:23:46 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:23:46 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:23:46 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:23:46 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:54:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:54:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:54:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:54:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:54:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:54:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:54:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:24:52 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:24:52 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:24:52 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:24:52 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:24:52 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:24:52 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:24:52 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:54:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:57:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:57:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:27:39 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:27:39 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:27:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:27:39 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:27:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:57:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:57:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:57:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:27:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:27:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:27:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:27:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:27:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:27:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:27:55 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 03:57:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:57:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:57:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:57:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:27:55 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:27:55 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:27:55 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:29:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:29:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:29:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:29:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:29:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:29:58 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:29:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 03:59:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:00:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:30:25 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:30:25 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:30:25 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:30:25 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:30:25 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:00:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:00:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:00:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:00:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:30:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:30:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:30:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:30:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:30:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:30:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:30:45 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:30:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:30:45 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:30:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:47:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:47:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:47:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:47:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:47:30 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:47:30 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:47:30 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:17:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:47:45 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:47:45 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:47:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:47:45 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:47:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:17:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:47:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:47:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:47:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:47:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:47:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:47:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:47:47 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 04:17:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:47:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:47:47 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:47:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:47:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:47:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:47:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:47:54 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:47:54 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:47:54 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:47:54 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:17:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:49:51 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:49:51 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:49:51 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:49:51 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:49:51 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:49:51 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:49:51 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 14:49:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:49:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:49:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:49:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:49:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:49:56 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:49:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:19:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:19:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:50:03 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:50:03 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:20:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:50:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:50:03 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:50:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:20:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:50:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:50:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:50:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:50:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:50:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:50:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:50:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:50:06 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:50:06 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:50:06 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:52:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:52:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:52:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:52:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:52:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:52:47 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:52:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:22:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:22:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:23:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:23:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:53:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:53:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:23:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:53:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:53:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:53:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:23:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:23:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:53:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:53:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:53:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:53:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:53:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:53:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:53:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 04:23:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:23:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:23:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:23:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:53:06 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:53:06 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:53:06 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:56:09 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:56:09 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:56:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:56:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:56:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:26:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:56:59 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:56:59 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:56:59 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:56:59 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:58:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:58:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:58:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:58:29 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 14:58:29 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:58:29 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:58:29 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:58:38 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 14:58:38 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:58:38 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:58:38 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:58:38 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 04:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 04:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 04:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:58:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:58:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 04:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 14:58:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:58:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:58:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 04:28:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 14:58:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:58:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 14:58:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:58:40 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 14:58:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:57:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:27:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 16:27:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 16:27:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:27:47 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:27:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 05:57:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:57:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:57:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:57:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:27:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:27:58 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:27:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 05:57:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:57:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:58:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:58:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:58:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:58:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:58:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:58:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:28:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:28:01 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:28:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 05:58:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:58:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:58:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:58:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:28:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:28:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:28:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:28:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:28:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:28:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:28:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 05:58:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:58:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:58:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:58:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:28:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:28:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:28:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 05:58:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:58:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:58:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:58:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:58:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:58:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:28:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:28:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:28:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:28:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:28:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:28:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:28:26 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 05:58:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:58:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 05:58:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 05:58:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:28:26 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:28:26 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:28:26 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:28:26 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:28:26 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:28:26 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:33:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 16:33:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 16:33:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 16:33:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 16:33:28 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:28 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:28 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:33:28 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:28 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:28 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:03:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:33:37 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 16:33:37 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:33:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:37 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:33:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:37 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:33:39 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:33:39 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:33:39 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:33:39 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:33:39 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:33:39 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:33:39 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:33:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:39 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:33:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:39 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:03:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:33:52 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 16:33:52 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 06:03:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:03:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:03:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:33:53 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:53 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:53 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:33:53 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:53 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:33:53 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:04:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:06 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:07 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:07 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:07 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:34:07 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:07 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:07 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:10 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 16:34:10 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:10 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:34:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:10 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:04:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:34:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:04:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:34:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:04:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:21 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:34:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:21 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:04:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:29 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:29 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:29 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:34:29 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:29 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:29 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:04:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 16:34:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 06:04:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 06:04:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:34:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:04:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:35 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 06:04:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:35 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:35 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:35 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:34:35 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:35 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:35 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:04:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:41 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:34:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:41 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:04:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:04:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:34:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 06:04:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:04:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:34:44 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:44 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:44 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:34:44 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:44 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:34:44 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:05:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:05:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:05:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:05:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:05:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:05:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:35:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:01 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:35:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:01 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:05:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:05:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:05:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:05:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:35:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:35:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:35:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:35:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:35:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:35:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:35:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 06:05:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:05:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:05:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:05:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:35:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:35:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:05:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:05:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:05:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:05:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:05:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:05:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:35:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:35:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:35:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:35:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:35:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:35:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:35:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 06:05:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:05:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:05:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:05:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:35:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:37 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:35:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:37 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:35:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:37 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:35:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 16:38:14 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 16:38:14 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:08:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:38:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:14 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:38:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:14 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:38:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:14 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:38:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:14 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:08:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:08:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:08:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:08:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:08:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:08:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:38:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:39:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 16:39:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:39:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:39:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:39:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:39:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 16:39:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:39:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:39:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 06:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:39:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:39:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:39:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:39:13 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 06:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:39:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:14 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:39:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:14 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:39:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:14 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:39:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:14 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:39:14 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:09:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:09:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:09:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:09:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:09:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:10:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:10:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:10:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:10:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:40:04 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3885
ERROR - 2023-11-06 16:40:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2324
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:43:27 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:43:27 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:43:27 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 16:43:27 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 16:43:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:27 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:43:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:27 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:43:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:27 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:43:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:27 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:43:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-11-06 16:43:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 762
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:43:34 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:34 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:34 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:43:34 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:34 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:34 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:43:34 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:34 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:34 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:43:34 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:34 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:34 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:13:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:13:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:13:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:36 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:36 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:36 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:36 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1330
ERROR - 2023-11-06 16:43:36 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1413
ERROR - 2023-11-06 06:30:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:30:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:00:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:10 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:00:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:10 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:00:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:10 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:00:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:10 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 06:30:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:30:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:00:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:00:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:00:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:00:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 06:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:30:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:00:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:32 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:00:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:32 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:00:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:32 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:00:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:32 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:00:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 06:32:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:32:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:33:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:33:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 06:33:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:33:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:03:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:03:37 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:03:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:03:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:03:37 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:03:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:03:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:03:37 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:03:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:03:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:03:37 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:03:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 06:34:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:34:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:04:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:04:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:04:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:04:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:04:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:04:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:04:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:04:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:04:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:04:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:04:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:04:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 06:35:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:35:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:05:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:08 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:05:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:08 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:05:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:08 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:05:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:08 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 06:35:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 06:35:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:05:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:41 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:05:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:41 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:05:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:41 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:05:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:41 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:05:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:09:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:39:53 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:39:53 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:39:53 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:39:53 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:39:53 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 07:10:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 07:10:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:18 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:18 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:18 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:18 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:40:18 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:56 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:56 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:56 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:56 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:40:56 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 07:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:10:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:40:59 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:59 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:59 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:59 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:59 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:59 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:59 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:59 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:59 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:40:59 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:59 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:40:59 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:11:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:11:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:11:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:11:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:12:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:42:39 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:42:39 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:42:39 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:42:39 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:42:39 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 07:14:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:14:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:44:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:44:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:44:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:44:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:14:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:14:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:44:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:43 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:44:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:43 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:44:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:43 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:44:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:43 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:14:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:57 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:57 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:57 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:57 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:44:57 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 07:15:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 07:15:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:01 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:01 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:01 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:01 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:45:09 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:17 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:17 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:17 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:17 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:45:17 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 07:15:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:15:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:45:49 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:49 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:49 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:45:49 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:49 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:49 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:45:49 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:49 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:49 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:45:49 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:49 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:45:49 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:16:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:16:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:46:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:21 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:46:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:21 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:46:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:21 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:46:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:21 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:16:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:16:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:46:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:47 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:46:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:47 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:46:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:47 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:46:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:47 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:46:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:17:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:47:30 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:30 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:30 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:30 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:30 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:30 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:30 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:30 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:30 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:30 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:30 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:30 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:17:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:47:38 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:38 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:38 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:38 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:38 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:38 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:38 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:38 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:38 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:38 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:38 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:38 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:39 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:39 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:39 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:39 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:47:39 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 07:17:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 07:17:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:48 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:48 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:48 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:48 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:58 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:58 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:58 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:58 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:47:58 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 07:17:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:17:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:17:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:48:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:01 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:01 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:01 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:01 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:01 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:18:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:08 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:08 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:08 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:08 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:48:08 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 07:18:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 07:18:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:48:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:48:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:18:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:48:42 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:42 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:42 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:42 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:42 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:42 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:42 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:42 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:42 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:42 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:42 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:48:42 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1602
ERROR - 2023-11-06 17:48:42 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:48:42 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:48:42 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 17:48:42 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2047
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:18 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:18 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:18 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:18 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:18 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:18 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 07:19:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:27 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:27 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:27 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:27 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:27 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:28 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:28 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:28 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:28 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:28 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 07:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 07:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:31 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:31 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:41 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:41 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:41 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:41 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:41 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:43 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:43 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:43 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:43 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:49:43 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 07:19:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:19:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:19:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:49:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:44 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:49:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:45 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:45 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:45 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:49:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:45 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:49:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:45 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:45 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:45 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:45 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:50:45 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:47 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:47 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:47 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:47 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1603
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 17:50:47 --> Severity: Notice  --> Undefined index: allow_pay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 2048
ERROR - 2023-11-06 07:20:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:20:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:50:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:57 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1604
ERROR - 2023-11-06 17:50:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:57 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1604
ERROR - 2023-11-06 17:50:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:57 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1604
ERROR - 2023-11-06 17:50:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:57 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:50:57 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1604
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 17:51:09 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:51:09 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:21:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:51:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1604
ERROR - 2023-11-06 17:51:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1604
ERROR - 2023-11-06 17:51:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1604
ERROR - 2023-11-06 17:51:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1604
ERROR - 2023-11-06 07:21:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:21:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:21:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:21:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:21:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:21:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:10 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1604
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:10 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1604
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:10 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1604
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:10 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1523
ERROR - 2023-11-06 17:51:10 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1604
ERROR - 2023-11-06 07:22:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:22:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:23:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:23:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:54:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:54:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:54:10 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:54:10 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:54:14 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:54:14 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:54:14 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:54:14 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:54:14 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:54:14 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:54:14 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 07:24:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:54:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:54:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:54:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:54:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:54:38 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:54:38 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:24:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:55:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:55:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:55:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:40 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:55:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:40 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:55:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:40 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:55:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:40 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:55:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:55:56 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:55:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:56 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:55:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:56 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:55:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:56 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:55:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:56 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:56 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:25:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:25:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:25:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:58 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:58 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:58 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:58 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:55:58 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:56:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:56:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:56:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:56:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:56:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:56:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 07:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:09 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:09 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:56:19 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 17:56:19 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:56:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:56:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:56:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:56:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:26:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:26:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:26:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:21 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:21 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:21 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:21 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 17:56:21 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:00:55 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:00:55 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:00:55 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:00:55 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:00:55 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:00:55 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:00:55 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:00:55 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:00:55 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:00:55 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:00:55 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:00:55 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:00:55 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:00:55 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:00:55 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:00:55 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:30:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:30:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:01:03 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:01:03 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:01:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:03 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:01:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:03 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:01:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:03 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:01:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:03 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:31:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:31:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:31:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:31:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:31:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:31:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:31:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:01:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:07:03 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:07:03 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:07:03 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:07:03 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:07:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:03 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:07:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:03 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:07:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:03 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:07:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:03 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:03 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:07:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:07:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:07:11 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:11 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:11 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:07:11 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:11 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:11 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:07:11 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:11 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:11 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:07:11 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:11 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:11 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:37:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:37:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:37:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:12 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:07:12 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:09:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:09:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 18:09:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:09:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 18:09:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:09:40 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:09:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:09:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:09:40 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:09:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:09:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:09:40 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:09:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:09:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:09:40 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:09:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:39:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:39:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:10:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:10:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:10:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:10:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:10:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:10:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:04 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:04 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:40:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:10:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:40:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:40:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:10:33 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3884
ERROR - 2023-11-06 18:10:33 --> Severity: Notice  --> Undefined index: paid_installments /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3981
ERROR - 2023-11-06 07:40:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:40:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:11:48 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:11:48 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 18:11:48 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:11:48 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 18:11:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:11:48 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:11:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:11:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:11:48 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:11:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:11:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:11:48 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:11:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:11:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:11:48 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:11:48 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:41:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:41:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:12:00 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:12:00 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:42:00 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:12:00 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:00 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:00 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:12:00 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:00 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:00 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:12:00 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:00 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:00 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:12:00 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:00 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:00 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:42:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:42:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:42:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:42:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:42:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:42:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:02 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:02 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:02 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:02 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:12:02 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:46:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:46:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:16:31 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3884
ERROR - 2023-11-06 07:46:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:46:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:16:58 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3884
ERROR - 2023-11-06 07:48:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:18:15 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3884
ERROR - 2023-11-06 18:18:15 --> Severity: Notice  --> Undefined index: paid_installments /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3985
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:18:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:18:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 18:18:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:18:22 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 18:18:22 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:22 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:22 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:18:22 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:22 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:22 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:18:22 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:22 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:22 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:18:22 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:22 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:22 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:18:35 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:18:35 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:18:35 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:35 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:35 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:18:35 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:35 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:35 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:18:35 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:35 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:35 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:18:35 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:35 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:35 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:48:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:48:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:48:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:37 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:37 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:37 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:37 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:18:37 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:19:12 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3884
ERROR - 2023-11-06 18:19:12 --> Severity: Notice  --> Undefined index: paid_installments /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3985
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:19:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:19:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:19:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:19:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:19:24 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:24 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:24 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:19:24 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:24 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:24 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:19:24 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:24 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:24 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:19:24 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:24 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:24 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:19:31 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:19:31 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:49:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:19:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:32 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:19:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:32 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:19:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:32 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:19:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:32 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:32 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 07:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 07:49:33 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:33 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:33 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:33 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:33 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:19:33 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:50:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:50:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:20:03 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3884
ERROR - 2023-11-06 18:20:03 --> Severity: Notice  --> Undefined index: paid_installments /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3985
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:22:19 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:22:19 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 18:22:19 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:22:19 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 18:22:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:22:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:22:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:22:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:22:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:22:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:22:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:22:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:22:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:22:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:22:19 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:22:19 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:52:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:52:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:22:42 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3884
ERROR - 2023-11-06 18:22:42 --> Severity: Notice  --> Undefined index: paid_installments /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3985
ERROR - 2023-11-06 07:53:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:23:31 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3884
ERROR - 2023-11-06 18:23:31 --> Severity: Notice  --> Undefined index: paid_installments /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3985
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:23:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:23:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:23:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:23:40 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 18:23:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:40 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:23:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:40 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:23:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:40 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:23:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:40 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:40 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:53:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:23:50 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:23:50 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 07:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:23:51 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:51 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:51 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:23:51 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:51 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:51 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:23:51 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:51 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:51 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:23:51 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:51 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:51 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:53:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 07:53:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:53:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:54 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:54 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:54 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:54 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:23:54 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 07:54:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:54:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:24:08 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3884
ERROR - 2023-11-06 18:24:08 --> Severity: Notice  --> Undefined index: paid_installments /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3985
ERROR - 2023-11-06 07:54:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:54:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:24:20 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3884
ERROR - 2023-11-06 18:24:20 --> Severity: Notice  --> Undefined index: paid_installments /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3985
ERROR - 2023-11-06 07:54:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:54:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:24:46 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3884
ERROR - 2023-11-06 18:24:46 --> Severity: Notice  --> Undefined index: paid_installments /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3985
ERROR - 2023-11-06 07:56:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 07:56:54 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:26:54 --> Severity: Notice  --> Undefined index: productinfo /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3884
ERROR - 2023-11-06 18:26:54 --> Severity: Notice  --> Undefined index: paid_installments /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3985
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:32:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:32:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:32:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:32:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 18:32:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:32:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:32:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:32:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:05 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:05 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:32:15 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:32:15 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:32:15 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:15 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:15 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:32:15 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:15 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:15 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:32:15 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:15 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:15 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:32:15 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:15 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:15 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 08:02:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 161
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:17 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:17 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:17 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:17 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:17 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:32:25 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 761
ERROR - 2023-11-06 18:32:25 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 764
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 18:32:25 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:25 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:25 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:32:25 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:25 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:25 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:32:25 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:25 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:25 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 18:32:25 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:25 --> Severity: Warning  --> Division by zero /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1525
ERROR - 2023-11-06 18:32:25 --> Severity: Notice  --> Undefined variable: metal_rates /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1606
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 08:02:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:04:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:04:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:04:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:04:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:04:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:04:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:05:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:05:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:27:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:27:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:27:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:27:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:27:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:27:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:27:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:27:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:27:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:29:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:29:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:30:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:30:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:30:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:30:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:30:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:30:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:30:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:30:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:33:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:34:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:34:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:34:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:34:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:34:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:34:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:15 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:36:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:36:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:37:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:37:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:38:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:38:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:41:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:41:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-11-06 23:46:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-11-06 23:46:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
