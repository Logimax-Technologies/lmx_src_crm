<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-05-19 00:46:50 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-05-19 00:46:50 --> Severity: Notice  --> Undefined index: new_arrivals_img_path /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 13
ERROR - 2025-05-19 00:46:50 --> Severity: Notice  --> Undefined index: new_arrivals_img_path /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 13
ERROR - 2025-05-19 00:46:50 --> Severity: Notice  --> Undefined index: name /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 18
ERROR - 2025-05-19 00:46:50 --> Severity: Notice  --> Undefined index: show_rate /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 19
ERROR - 2025-05-19 00:46:50 --> Severity: Notice  --> Undefined index: show_rate /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 21
ERROR - 2025-05-19 00:46:50 --> Severity: Notice  --> Undefined index:  /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 22
ERROR - 2025-05-19 00:46:50 --> Severity: Notice  --> Undefined index: product_description /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 26
ERROR - 2025-05-19 00:58:43 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-05-19 12:47:21 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-05-19 12:47:21 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-05-19 13:49:27 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-05-19 14:06:15 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
