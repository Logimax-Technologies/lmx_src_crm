<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2024-07-11 12:26:30 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2024-07-11 21:41:32 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2024-07-11 21:41:32 --> Severity: Notice  --> Undefined variable: profile /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/signup.php 37
