<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-01-21 01:51:53 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-01-21 01:51:53 --> Severity: Notice  --> Undefined index: new_arrivals_img_path /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 13
ERROR - 2025-01-21 01:51:53 --> Severity: Notice  --> Undefined index: new_arrivals_img_path /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 13
ERROR - 2025-01-21 01:51:53 --> Severity: Notice  --> Undefined index: name /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 18
ERROR - 2025-01-21 01:51:53 --> Severity: Notice  --> Undefined index: show_rate /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 19
ERROR - 2025-01-21 01:51:53 --> Severity: Notice  --> Undefined index: show_rate /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 21
ERROR - 2025-01-21 01:51:53 --> Severity: Notice  --> Undefined index:  /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 22
ERROR - 2025-01-21 01:51:53 --> Severity: Notice  --> Undefined index: product_description /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 26
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:03:35 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:04:02 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:48 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:06:53 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:04 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:13:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:05 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 08:16:14 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:12 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> Undefined index: igst /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 17064
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> Undefined property: stdClass::$HSNCode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18767
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18775
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18781
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18787
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18384
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18390
ERROR - 2025-01-21 09:51:21 --> Severity: Notice  --> A non well formed numeric value encountered /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 18396
ERROR - 2025-01-21 14:26:09 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-01-21 14:26:09 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-01-21 15:15:35 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-01-21 16:02:11 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-01-21 16:09:27 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-01-21 17:23:44 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
