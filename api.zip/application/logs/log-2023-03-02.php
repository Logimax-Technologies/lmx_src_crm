<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:10:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:40:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:40:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 17:40:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:40:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 17:40:46 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:40:46 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:11:05 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:41:05 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:41:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:41:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:41:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:41:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:41:06 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:41:06 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:41:06 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:11:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 07:11:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:11:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:11:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:11:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:41:09 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-03-02 07:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:41:12 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:41:12 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:41:12 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 17:41:12 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 17:41:12 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2001
ERROR - 2023-03-02 17:41:12 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2003
ERROR - 2023-03-02 17:41:12 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2007
ERROR - 2023-03-02 07:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:11:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:11:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:41:14 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3952
ERROR - 2023-03-02 17:41:14 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3998
ERROR - 2023-03-02 17:41:14 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3999
ERROR - 2023-03-02 17:41:14 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4034
ERROR - 2023-03-02 17:41:14 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4091
ERROR - 2023-03-02 17:41:14 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4092
ERROR - 2023-03-02 17:41:14 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4100
ERROR - 2023-03-02 17:41:14 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4125
ERROR - 2023-03-02 17:41:14 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4131
ERROR - 2023-03-02 17:41:14 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4135
ERROR - 2023-03-02 07:15:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:15:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:15:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:15:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:15:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:15:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:45:21 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:45:21 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:15:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:15:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:20 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:20 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:46:20 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:16:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:22 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:46:22 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:16:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:22 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:28 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:46:28 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 07:16:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:16:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:16:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:46:32 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-03-02 07:16:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:36 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:46:36 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:16:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:36 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 17:46:36 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 17:46:36 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2001
ERROR - 2023-03-02 17:46:36 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2003
ERROR - 2023-03-02 17:46:36 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2007
ERROR - 2023-03-02 07:16:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:16:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:16:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:46:43 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3952
ERROR - 2023-03-02 17:46:43 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3998
ERROR - 2023-03-02 17:46:43 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3999
ERROR - 2023-03-02 17:46:43 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4034
ERROR - 2023-03-02 17:46:43 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4091
ERROR - 2023-03-02 17:46:43 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4092
ERROR - 2023-03-02 17:46:43 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4100
ERROR - 2023-03-02 17:46:43 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4125
ERROR - 2023-03-02 17:46:43 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4131
ERROR - 2023-03-02 17:46:43 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4135
ERROR - 2023-03-02 07:20:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:20:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:20:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:20:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:20:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:20:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:20:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:20:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:20:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:20:55 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:50:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:50:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 17:50:55 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:50:55 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:20:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:20:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:20:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:20:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:20:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:20:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:50:58 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:50:58 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:51:43 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:51:44 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:51:44 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:21:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:52 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:21:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:51:52 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:51:52 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 17:51:52 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 17:51:52 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 17:51:52 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 17:51:52 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 17:51:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:51:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:51:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:51:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:51:53 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:51:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:51:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:21:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:21:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:21:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:21:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:51:58 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-03-02 07:22:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:22:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:52:05 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:52:05 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:22:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:22:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:22:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:22:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:22:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:22:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:22:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:22:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:22:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:22:06 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:22:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:22:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:42 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:54:42 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:24:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:47 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:54:47 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:47 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 07:24:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:24:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:24:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 17:54:48 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-03-02 07:24:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:51 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 17:54:51 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:24:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:51 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 17:54:51 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 17:54:51 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2001
ERROR - 2023-03-02 17:54:51 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2003
ERROR - 2023-03-02 17:54:51 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2007
ERROR - 2023-03-02 07:24:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:51 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:24:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:24:52 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 17:54:52 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3952
ERROR - 2023-03-02 17:54:52 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3998
ERROR - 2023-03-02 17:54:52 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3999
ERROR - 2023-03-02 17:54:52 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4034
ERROR - 2023-03-02 17:54:52 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4091
ERROR - 2023-03-02 17:54:52 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4092
ERROR - 2023-03-02 17:54:52 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4100
ERROR - 2023-03-02 17:54:52 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4125
ERROR - 2023-03-02 17:54:52 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4131
ERROR - 2023-03-02 17:54:52 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4135
ERROR - 2023-03-02 07:33:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:03:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:03:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:33:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:03:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:03:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:03:24 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:03:24 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:03:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:03:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:33:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:25 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:03:25 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:03:25 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:03:25 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:03:25 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:03:25 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:03:25 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:03:25 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:03:25 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:03:25 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:03:25 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:03:25 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:33:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:26 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:03:49 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:03:49 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:03:49 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:03:49 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:03:49 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:03:49 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:03:50 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:03:50 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:50 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:03:50 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:03:50 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:03:50 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:03:50 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:03:50 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:03:50 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:03:50 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:03:50 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:03:50 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:03:50 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:03:50 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:33:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:33:56 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:39:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:39:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:39:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:39:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:09:13 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:09:13 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:10:25 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:10:25 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 18:10:25 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:10:25 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:10:25 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:10:25 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:40:38 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:10:38 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:10:39 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:10:39 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:10:39 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 986
ERROR - 2023-03-02 18:10:39 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1018
ERROR - 2023-03-02 18:10:39 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:10:39 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:10:39 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:10:39 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:40:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:10:39 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:10:39 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:40:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:39 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:40:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:40:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:40 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 986
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1018
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:10:40 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-03-02 07:40:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:10:45 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:10:45 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:40:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:10:45 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 18:10:45 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 18:10:45 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2001
ERROR - 2023-03-02 18:10:45 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2003
ERROR - 2023-03-02 18:10:45 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2007
ERROR - 2023-03-02 07:40:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:40:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:10:46 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3952
ERROR - 2023-03-02 18:10:46 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3998
ERROR - 2023-03-02 18:10:46 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3999
ERROR - 2023-03-02 18:10:46 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4034
ERROR - 2023-03-02 18:10:46 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4091
ERROR - 2023-03-02 18:10:46 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4092
ERROR - 2023-03-02 18:10:46 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4100
ERROR - 2023-03-02 18:10:47 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4125
ERROR - 2023-03-02 18:10:47 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4131
ERROR - 2023-03-02 18:10:47 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4135
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:13:59 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:13:59 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:13:59 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:13:59 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:13:59 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:13:59 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:43:59 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 18:13:59 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:13:59 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:13:59 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:13:59 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:13:59 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:13:59 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:13:59 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:43:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:44:34 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 986
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1018
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:14:34 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:45:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:45:04 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 986
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1018
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:15:04 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:04 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:45:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 07:45:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:45:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 986
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1018
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:45:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:09 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:15:09 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-03-02 07:45:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:15:49 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:15:49 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:45:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:45:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:45:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:15:49 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 18:15:49 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 18:15:49 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2001
ERROR - 2023-03-02 18:15:49 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2003
ERROR - 2023-03-02 18:15:49 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2007
ERROR - 2023-03-02 07:45:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:49 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:45:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:50 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:45:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:45:59 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:15:59 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3952
ERROR - 2023-03-02 18:15:59 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3998
ERROR - 2023-03-02 18:15:59 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3999
ERROR - 2023-03-02 18:15:59 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4034
ERROR - 2023-03-02 18:15:59 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4091
ERROR - 2023-03-02 18:15:59 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4092
ERROR - 2023-03-02 18:15:59 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4100
ERROR - 2023-03-02 18:15:59 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4125
ERROR - 2023-03-02 18:15:59 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4131
ERROR - 2023-03-02 18:15:59 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4135
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:11 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 07:51:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:21:11 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:51:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:13 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:13 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:21:13 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:51:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:23 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:23 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:21:23 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:23 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:21:23 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:21:23 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:21:23 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:21:23 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:21:23 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:23 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:21:23 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:23 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:21:23 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:21:23 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:51:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:21:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:51:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:21:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:51:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 07:51:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:21:29 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-03-02 07:51:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:29 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:21:38 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:21:38 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:51:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:38 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:51:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:51:41 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:03 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:17 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 986
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1018
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:22:17 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:17 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:43 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:44 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 986
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1018
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:22:44 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 07:52:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:52:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:52:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:48 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 986
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1018
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 18:22:48 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-03-02 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:53 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:22:53 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:53 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 18:22:53 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 18:22:53 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2001
ERROR - 2023-03-02 18:22:53 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2003
ERROR - 2023-03-02 18:22:53 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2007
ERROR - 2023-03-02 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:52:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:52:57 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:22:57 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3952
ERROR - 2023-03-02 18:22:57 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3998
ERROR - 2023-03-02 18:22:57 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3999
ERROR - 2023-03-02 18:22:57 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4034
ERROR - 2023-03-02 18:22:57 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4091
ERROR - 2023-03-02 18:22:57 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4092
ERROR - 2023-03-02 18:22:57 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4100
ERROR - 2023-03-02 18:22:57 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4125
ERROR - 2023-03-02 18:22:57 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4131
ERROR - 2023-03-02 18:22:57 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4135
ERROR - 2023-03-02 07:53:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:53:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:53:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:53:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:23:37 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 18:23:37 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 07:56:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:56:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 07:57:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 07:57:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 18:27:32 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3952
ERROR - 2023-03-02 18:27:32 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3998
ERROR - 2023-03-02 18:27:32 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3999
ERROR - 2023-03-02 18:27:32 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4034
ERROR - 2023-03-02 18:27:32 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4091
ERROR - 2023-03-02 18:27:32 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4092
ERROR - 2023-03-02 18:27:32 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4100
ERROR - 2023-03-02 18:27:32 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4125
ERROR - 2023-03-02 18:27:32 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4131
ERROR - 2023-03-02 18:27:32 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4135
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:05:44 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:05:44 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:05:44 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:05:44 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:35:44 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:05:44 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:05:44 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:35:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:35:45 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:36:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:01 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:06:01 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 19:06:01 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 19:06:01 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 19:06:01 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 19:06:01 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:06:01 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:36:02 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 986
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1018
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:06:02 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:02 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:36:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 08:36:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:36:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 986
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1018
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:06:05 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-03-02 08:36:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:05 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:06:10 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:06:10 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:36:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:06:10 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 19:06:10 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 19:06:10 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2001
ERROR - 2023-03-02 19:06:10 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2003
ERROR - 2023-03-02 19:06:10 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2007
ERROR - 2023-03-02 08:36:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:11 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:36:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:36:12 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:06:12 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3952
ERROR - 2023-03-02 19:06:12 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3998
ERROR - 2023-03-02 19:06:12 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3999
ERROR - 2023-03-02 19:06:12 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4034
ERROR - 2023-03-02 19:06:12 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4091
ERROR - 2023-03-02 19:06:12 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4092
ERROR - 2023-03-02 19:06:12 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4100
ERROR - 2023-03-02 19:06:12 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4125
ERROR - 2023-03-02 19:06:12 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4131
ERROR - 2023-03-02 19:06:12 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4135
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 986
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1018
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:24 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:24 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:25 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:30 --> Severity: Notice  --> Undefined property: CI_Loader::$login_model /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 9
ERROR - 2023-03-02 08:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:14:30 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:14:30 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:14:30 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 754
ERROR - 2023-03-02 19:14:30 --> Severity: Notice  --> Undefined index: token /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 757
ERROR - 2023-03-02 19:14:30 --> Severity: Notice  --> Undefined index: uuid /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 758
ERROR - 2023-03-02 19:14:30 --> Severity: Notice  --> Undefined index: device_type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 759
ERROR - 2023-03-02 19:14:30 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:14:30 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:30 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:14:31 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:14:31 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:44:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:14:31 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:31 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:31 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 986
ERROR - 2023-03-02 19:14:31 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1018
ERROR - 2023-03-02 19:14:31 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:31 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:31 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:31 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 08:44:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined index: goldrate_22ct /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 157
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:44:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 986
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined variable: current_installments /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1018
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined property: stdClass::$restrict_payment /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 1361
ERROR - 2023-03-02 19:14:32 --> Severity: Notice  --> Undefined index: branch_code /home/retaillogimaxind/public_html/etail_v3/application/models/registration_model.php 724
ERROR - 2023-03-02 08:44:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:32 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:14:35 --> Severity: Notice  --> Undefined index: showDirectpay /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 96
ERROR - 2023-03-02 19:14:35 --> Severity: Notice  --> Undefined index: showGmail /home/retaillogimaxind/public_html/etail_v3/application/models/mobileapi_model.php 98
ERROR - 2023-03-02 08:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:14:35 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 19:14:35 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 1999
ERROR - 2023-03-02 19:14:35 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2001
ERROR - 2023-03-02 19:14:35 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2003
ERROR - 2023-03-02 19:14:35 --> Severity: Notice  --> Undefined index: param_2 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 2007
ERROR - 2023-03-02 08:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:36 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 08:44:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-03-02 08:44:37 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-03-02 19:14:37 --> Severity: Notice  --> Undefined index: pg_name /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3952
ERROR - 2023-03-02 19:14:37 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3998
ERROR - 2023-03-02 19:14:37 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 3999
ERROR - 2023-03-02 19:14:37 --> Severity: Notice  --> Undefined index: type /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4034
ERROR - 2023-03-02 19:14:37 --> Severity: Notice  --> Undefined index: param_1 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4091
ERROR - 2023-03-02 19:14:37 --> Severity: Notice  --> Undefined index: param_3 /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4092
ERROR - 2023-03-02 19:14:37 --> Severity: Notice  --> Undefined index: api_url /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4100
ERROR - 2023-03-02 19:14:37 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4125
ERROR - 2023-03-02 19:14:37 --> Severity: Notice  --> Trying to get property of non-object /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4131
ERROR - 2023-03-02 19:14:37 --> Severity: Notice  --> Undefined variable: result /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 4135
