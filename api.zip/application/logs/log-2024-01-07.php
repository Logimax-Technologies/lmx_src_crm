<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2024-01-07 05:38:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 05:38:58 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 05:41:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 05:41:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 16:11:08 --> Query error: Unknown column 'b.ispurtransfered' in 'where clause'
ERROR - 2024-01-07 06:43:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 06:43:10 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 17:13:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''') as brgst 

                                FROM `ret_purchase_return` as ...' at line 23
ERROR - 2024-01-07 06:48:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 06:48:21 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 06:50:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 06:50:23 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 06:50:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 06:50:35 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 06:50:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 06:50:46 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 06:51:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 06:51:07 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 06:51:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 06:51:19 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 06:52:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 06:52:16 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 07:23:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 07:23:31 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 07:26:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 07:26:08 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 17:56:08 --> Severity: Notice  --> Undefined property: stdClass::$VOUCHERTYPE /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16481
ERROR - 2024-01-07 17:56:08 --> Severity: Notice  --> Undefined property: stdClass::$VOUCHERTYPE /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16483
ERROR - 2024-01-07 17:56:08 --> Severity: Notice  --> Undefined property: stdClass::$LedgerParent /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16487
ERROR - 2024-01-07 17:56:08 --> Severity: Notice  --> Undefined property: stdClass::$pan_no /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16501
ERROR - 2024-01-07 17:56:08 --> Severity: Notice  --> Undefined property: stdClass::$bill_id /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16505
ERROR - 2024-01-07 17:56:08 --> Severity: Notice  --> Undefined property: stdClass::$CostCentre /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16513
ERROR - 2024-01-07 17:56:08 --> Severity: Notice  --> Undefined property: stdClass::$cusdeladdress /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16583
ERROR - 2024-01-07 17:56:08 --> Severity: Notice  --> Undefined property: stdClass::$cusdelpincode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16593
ERROR - 2024-01-07 07:26:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 07:26:14 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 17:56:14 --> Severity: Notice  --> Undefined property: stdClass::$VOUCHERTYPE /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16481
ERROR - 2024-01-07 17:56:14 --> Severity: Notice  --> Undefined property: stdClass::$VOUCHERTYPE /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16483
ERROR - 2024-01-07 17:56:14 --> Severity: Notice  --> Undefined property: stdClass::$LedgerParent /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16487
ERROR - 2024-01-07 17:56:14 --> Severity: Notice  --> Undefined property: stdClass::$pan_no /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16501
ERROR - 2024-01-07 17:56:14 --> Severity: Notice  --> Undefined property: stdClass::$bill_id /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16505
ERROR - 2024-01-07 17:56:14 --> Severity: Notice  --> Undefined property: stdClass::$CostCentre /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16513
ERROR - 2024-01-07 17:56:14 --> Severity: Notice  --> Undefined property: stdClass::$cusdeladdress /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16583
ERROR - 2024-01-07 17:56:14 --> Severity: Notice  --> Undefined property: stdClass::$cusdelpincode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16593
ERROR - 2024-01-07 07:29:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2024-01-07 07:29:53 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2024-01-07 17:59:53 --> Severity: Notice  --> Undefined property: stdClass::$VOUCHERTYPE /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16481
ERROR - 2024-01-07 17:59:53 --> Severity: Notice  --> Undefined property: stdClass::$VOUCHERTYPE /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16483
ERROR - 2024-01-07 17:59:53 --> Severity: Notice  --> Undefined property: stdClass::$LedgerParent /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16487
ERROR - 2024-01-07 17:59:53 --> Severity: Notice  --> Undefined property: stdClass::$pan_no /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16501
ERROR - 2024-01-07 17:59:53 --> Severity: Notice  --> Undefined property: stdClass::$bill_id /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16505
ERROR - 2024-01-07 17:59:53 --> Severity: Notice  --> Undefined property: stdClass::$CostCentre /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16513
ERROR - 2024-01-07 17:59:53 --> Severity: Notice  --> Undefined property: stdClass::$cusdeladdress /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16583
ERROR - 2024-01-07 17:59:53 --> Severity: Notice  --> Undefined property: stdClass::$cusdelpincode /home/retaillogimaxind/public_html/etail_v3/application/models/ret_tally_api_model.php 16593
ERROR - 2024-01-07 17:59:53 --> Query error: Unknown column 'pur_ret_id' in 'where clause'
