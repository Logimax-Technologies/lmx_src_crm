<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-08-15 12:30:27 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-08-15 22:00:27 --> Severity: Warning  --> mkdir(): File exists /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 61
ERROR - 2023-08-15 22:00:27 --> Severity: Warning  --> mkdir(): File exists /home/retaillogimaxind/public_html/etail_v3/application/controllers/mobile_api.php 61
ERROR - 2023-08-15 12:30:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-08-15 12:30:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
ERROR - 2023-08-15 12:30:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 133
ERROR - 2023-08-15 12:30:28 --> Severity: Warning  --> Creating default object from empty value /home/retaillogimaxind/public_html/etail_v3/application/libraries/REST_Controller.php 322
