<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2025-04-26 10:16:31 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-04-26 12:28:23 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-04-26 12:28:23 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-04-26 12:45:31 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-04-26 12:45:31 --> Severity: Notice  --> Undefined index: new_arrivals_img_path /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 13
ERROR - 2025-04-26 12:45:31 --> Severity: Notice  --> Undefined index: new_arrivals_img_path /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 13
ERROR - 2025-04-26 12:45:31 --> Severity: Notice  --> Undefined index: name /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 18
ERROR - 2025-04-26 12:45:31 --> Severity: Notice  --> Undefined index: show_rate /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 19
ERROR - 2025-04-26 12:45:31 --> Severity: Notice  --> Undefined index: show_rate /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 21
ERROR - 2025-04-26 12:45:31 --> Severity: Notice  --> Undefined index:  /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 22
ERROR - 2025-04-26 12:45:31 --> Severity: Notice  --> Undefined index: product_description /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 26
ERROR - 2025-04-26 13:40:51 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-04-26 13:40:51 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-04-26 13:52:18 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-04-26 13:52:18 --> Severity: Notice  --> Undefined index: new_arrivals_img_path /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 13
ERROR - 2025-04-26 13:52:18 --> Severity: Notice  --> Undefined index: new_arrivals_img_path /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 13
ERROR - 2025-04-26 13:52:18 --> Severity: Notice  --> Undefined index: name /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 18
ERROR - 2025-04-26 13:52:18 --> Severity: Notice  --> Undefined index: show_rate /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 19
ERROR - 2025-04-26 13:52:18 --> Severity: Notice  --> Undefined index: show_rate /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 21
ERROR - 2025-04-26 13:52:18 --> Severity: Notice  --> Undefined index:  /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 22
ERROR - 2025-04-26 13:52:18 --> Severity: Notice  --> Undefined index: product_description /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/newarrivals_description.php 26
ERROR - 2025-04-26 15:00:59 --> Severity: Notice  --> Undefined variable: data /home/retaillogimaxind/public_html/etail_v3/application/views/layout/header.php 191
ERROR - 2025-04-26 15:00:59 --> Severity: Notice  --> Undefined variable: profile /home/retaillogimaxind/public_html/etail_v3/application/views/chitscheme/signup.php 37
